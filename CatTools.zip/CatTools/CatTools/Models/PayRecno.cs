﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    /// <summary>
    /// 支付记录
    /// </summary>
    public class PayRecno : Core, IAggregateRoot
    {
        /// <summary>
        /// 支付订单id
        /// </summary>
        [BsonElement("PayId")]
        public string PayId { get; set; }
        /// <summary>
        /// 最后订单序号
        /// </summary>
        [BsonElement("LastNo")]
        public int LastNo { get; set; }
        /// <summary>
        /// 时间
        /// </summary>
        [BsonElement("Time")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime Time { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public PayRecno()
        {

        }
        /// <summary>
        /// 新记录
        /// </summary>
        /// <param name="id"></param>
        public PayRecno(string id)
        {
            this.PayId = id;
            this.LastNo = 0;
            this.Time = DateTime.Now;
        }
    }
}
