﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    #region 创业者 Entrepreneur
    /// <summary>
    /// 创业者
    /// </summary>
    public class Entrepreneur : Core, IAggregateRoot
    {
        /// <summary>
        /// 创业者编号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 创业者级别
        /// </summary>
        [BsonElement("Level")]
        public EntrepreneurLevel Level { get; set; }
        /// <summary>
        /// 基础版数量
        /// </summary>
        [BsonElement("ServiceBase")]
        public int ServiceBase { get; set; }
        /// <summary>
        /// 标准版数量
        /// </summary>
        [BsonElement("ServiceStandard")]
        public int ServiceStandard { get; set; }
        /// <summary>
        /// 尊享版数量
        /// </summary>
        [BsonElement("ServiceExclusive")]
        public int ServiceExclusive { get; set; }
        /// <summary>
        /// 基础版发放列表
        /// </summary>
        [BsonElement("TakeBase")]
        public List<int> TakeBase { get; set; }
        /// <summary>
        /// 标准版发放列表
        /// </summary>
        [BsonElement("TakeStandard")]
        public List<int> TakeStandard { get; set; }
        /// <summary>
        /// 尊享版发放列表
        /// </summary>
        [BsonElement("TaketExclusive")]
        public List<int> TaketExclusive { get; set; }
        /// <summary>
        /// 累计支付额
        /// </summary>
        public int TotalMoney { get; set; }
        /// <summary>
        /// 当前支付额
        /// </summary>
        public int CurrentMoney { get; set; }
        /// <summary>
        /// 是否已经支付
        /// </summary>
        public bool IsPay { get; set; }
        /// <summary>
        /// 建立日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public Entrepreneur()
        {

        }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="level"></param>
        /// <param name="userid"></param>
        /// <param name="id"></param>
        public Entrepreneur(EntrepreneurLevel level, int userid,int id)
        {
            this.Level = level;
            this.UserId = userid;
            this.IsPay = false;
            this.ID = id;
            switch (level)
            {
                case EntrepreneurLevel.Counselor:
                    this.ServiceBase = 60;
                    this.ServiceStandard = 3;
                    this.ServiceExclusive = 2;
                    this.CurrentMoney = 1000000;
                    this.TotalMoney = 1000000;
                    break;
                case EntrepreneurLevel.Dealer:
                    this.ServiceBase = 200;
                    this.ServiceStandard = 10;
                    this.ServiceExclusive = 6;
                    this.CurrentMoney = 2000000;
                    this.TotalMoney = 2000000;
                    break;
                case EntrepreneurLevel.OperationsCenter:
                    this.ServiceBase = 3000;
                    this.ServiceStandard = 150;
                    this.ServiceExclusive = 80;
                    this.CurrentMoney = 3000000;
                    this.TotalMoney = 3000000;
                    break;
                case EntrepreneurLevel.Partner:
                    //暂时设置
                    this.ServiceBase = 99999;
                    this.ServiceStandard = 999;
                    this.ServiceExclusive = 999;
                    this.CurrentMoney = 30000000;
                    this.TotalMoney = 30000000;
                    break;
            }
            this.CreateTime = DateTime.Now;
        }
        /// <summary>
        /// 升级
        /// </summary>
        /// <param name="level"></param>
        public void Upgrade(EntrepreneurLevel level)
        {
            this.Level = level;
            var current = this.TotalMoney;
            this.IsPay = false;
            switch (level)
            {
                case EntrepreneurLevel.Counselor:
                    this.ServiceBase = 60;
                    this.ServiceStandard = 3;
                    this.ServiceExclusive = 2;
                    this.CurrentMoney = 1000000 - current;
                    this.TotalMoney = 1000000;
                    break;
                case EntrepreneurLevel.Dealer:
                    this.ServiceBase = 200;
                    this.ServiceStandard = 10;
                    this.ServiceExclusive = 6;
                    this.CurrentMoney = 2000000- current;
                    this.TotalMoney = 2000000;
                    break;
                case EntrepreneurLevel.OperationsCenter:
                    this.ServiceBase = 3000;
                    this.ServiceStandard = 150;
                    this.ServiceExclusive = 80;
                    this.CurrentMoney = 3000000 - current;
                    this.TotalMoney = 3000000;
                    break;
                case EntrepreneurLevel.Partner:
                    //暂时设置
                    this.ServiceBase = 99999;
                    this.ServiceStandard = 999;
                    this.ServiceExclusive = 999;
                    this.CurrentMoney = 30000000-current;
                    this.TotalMoney = 30000000;
                    break;
            }
            this.CreateTime = DateTime.Now;
        }
        /// <summary>
        /// 发放
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="element"></param>
        public bool Take(TakeKind kind, int element)
        {
            var result = false;
            switch (kind)
            {
                case TakeKind.ServiceBase:

                    if (this.TakeBase == null)
                    {
                        this.TakeBase = new List<int> { element };
                        result = true;
                    }
                    else
                    {
                        if (this.TakeBase.Count < this.ServiceBase)
                        {
                            this.TakeBase.Add(element);
                            result = true;
                        }

                    }
                    break;
                case TakeKind.ServiceStandard:

                    if (this.TakeStandard == null)
                    {
                        this.TakeStandard = new List<int> { element };
                        result = true;
                    }
                    else
                    {
                        if (this.TakeStandard.Count < this.ServiceStandard)
                        {
                            this.TakeStandard.Add(element);
                            result = true;
                        }

                    }
                    break;
                case TakeKind.ServiceExclusive:
                    
                    if (this.TaketExclusive == null)
                    {
                        this.TaketExclusive = new List<int> { element };
                        result = true;
                    }
                    else
                    {
                        if (TaketExclusive.Count < this.ServiceExclusive)
                        {
                            this.TaketExclusive.Add(element);
                            result = true;
                        }
                    }
                    break;
                  
            }
            return result;
        }
    }
    #endregion
    /// <summary>
    /// 创业者级别
    /// </summary>
    public enum EntrepreneurLevel
    {
        /// <summary>
        /// 辅导员
        /// </summary>
        [Description("辅导员")]
        Counselor,
        /// <summary>
        /// 经销商
        /// </summary>
        [Description("经销商")]
        Dealer,
        /// <summary>
        /// 运营中心
        /// </summary>
        [Description("运营中心")]
        OperationsCenter,
        /// <summary>
        /// 合伙人
        /// </summary>
        [Description("合伙人")]
        Partner
    }
    /// <summary>
    /// 发放类别
    /// </summary>
    public enum TakeKind
    {
        /// <summary>
        /// 基础版
        /// </summary>
        [Description("基础版")]
        ServiceBase,
        /// <summary>
        /// 标准版
        /// </summary>
        [Description("标准版")]
        ServiceStandard,
        /// <summary>
        /// 尊享版
        /// </summary>
        [Description("尊享版")]
        ServiceExclusive
    }

    /// <summary>
    /// 分销领取
    /// </summary>
    public class TakeMarketing : Core, IAggregateRoot
    {
        /// <summary>
        /// 发放人ID
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 领取人uid
        /// </summary>
        [BsonElement("TakeId")]
        public int TakeId { get; set; }
        /// <summary>
        /// 领取类别
        /// </summary>
        [BsonElement("Kind")]
        public TakeKind Kind { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TakeMarketing()
        {

        }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="id"></param>
        /// <param name="takeid"></param>
        public TakeMarketing(TakeKind kind ,int id, int takeid)
        {
            this.TakeId = takeid;
            this.ID = id;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);

        }
    }

}
