﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    /// <summary>
    /// 掌联用户仓储
    /// </summary>
    public class User : Core, IAggregateRoot
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [BsonElement("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [BsonElement("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        [BsonElement("Portrait")]
        public string Portrait { get; set; }
     
        /// <summary>
        /// 用户构造
        /// </summary>
        public User()
        {
            ID = 0;
            Name = "无姓名";
            Phone = "电话号";
            Portrait = "头像地址";
        }
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="register"></param>
        public User(UserRegister register)
        {
            ID = register.ID;
            Name = register.Name;
            Phone = register.Phone;
            Portrait = register.Portrait;
        }
        /// <summary>
        /// 获取修改列表
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        #region  获取修改表 UpdateList
        public List<string> UpdateList(UserModi data)
        {
            var result = new List<string>();
            //姓名
            if (data.Name != null & this.Name != data.Name)
            {
                this.Name = data.Name;
                result.Add("Name");
            }
            //电话
            if (data.Phone != null & this.Phone != data.Phone)
            {
                this.Phone = data.Phone;
                result.Add("Phone");
            }
            //头像
            if (data.Portrait != null & this.Portrait != data.Portrait)
            {
                this.Portrait = data.Portrait;
                result.Add("Portrait");
            }
            return result;
        }
        #endregion
    }
    /// <summary>
    /// 用户注册
    /// </summary>
    #region  用户注册 UserRegister
    public class UserRegister
    {
        /// <summary>
        /// 用户编号
        /// </summary>
        [DisplayName("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [DisplayName("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [DisplayName("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        [DisplayName("Portrait")]
        public string Portrait { get; set; }
     }
    #endregion
    /// <summary>
    /// 用户修改
    /// </summary>
    #region  用户修改 UserModi
    public class UserModi
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [DisplayName("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [DisplayName("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        [DisplayName("Portrait")]
        public string Portrait { get; set; }
   
    }
    #endregion
    /// <summary>
    /// 用户验证表
    /// </summary>
    public class UserCheck
    {
        /// <summary>
        /// 用户id
        /// </summary>
        [DisplayName("ID")]
        public int ID { get; set; }
        /// <summary>
        /// session
        /// </summary>
        [DisplayName("Session")]
        public string Session { get; set; }
        /// <summary>
        /// Session截止时间
        /// </summary>
        [DisplayName("EndTime")]
        public DateTime EndTime { get; set; }
    }
}
