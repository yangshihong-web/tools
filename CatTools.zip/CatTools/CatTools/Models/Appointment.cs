﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;


namespace CatTools.Models
{
   
    /// <summary>
    /// 预约模板
    /// </summary>
    public class AappointmentModel : Core, IAggregateRoot
    {
        /// <summary>
        /// 商铺信息
        /// </summary>
        public Shop ShopMess { get; set; }
        /// <summary>
        /// 项目说明
        /// </summary>
        public AappointmentExplain Explain { get; set; }
        /// <summary>
        /// 时段
        /// </summary>
        public List<Times> Time { get; set; }
        /// <summary>
        /// 休息日
        /// </summary>
        public int[] RestDate { get; set; }
        /// <summary>
        /// 添加时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        public AappointmentModel()
        {

        }
        public AappointmentModel(Shop shop,AappointmentExplain explain)
        {
            this.Explain = explain;
            this.ShopMess = shop;
            this.Time = new List<Times>() { };
            this.RestDate = new int[] { };
            this.CreateTime = DateTime.Now;
        }
    }
    /// <summary>
    /// 商铺
    /// </summary>
    public class Shop
    {
        /// <summary>
        /// 商铺id
        /// </summary>
        public int ShopId { get; set; }
        /// <summary>
        /// 商铺名
        /// </summary>
        public string ShopName { get; set; }
        /// <summary>
        /// 商铺地址
        /// </summary>
        public string ShopAddress { get; set; }
        /// <summary>
        /// 商铺电话
        /// </summary>
        public string ShopPhone { get; set; }
    }
    /// <summary>
    /// 模板时间段设置
    /// </summary>
    public class Times : Core
    {
        /// <summary>
        /// 时间段说明
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 设置预约数量
        /// </summary>
        public int SetNum { get; set; }
    }
    /// <summary>
    /// 预约订单
    /// </summary>
    public class AppointmentOrder : Core, IAggregateRoot
    {
        /// <summary>
        /// 预约人数
        /// </summary>
        public int PersonsNum { get; set; }
        /// <summary>
        /// 预约人信息
        /// </summary>
        public AappointmentMan Man { get; set; }
        /// <summary>
        /// 订单金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 是否有效
        /// </summary>
        public bool IsValid { get; set; }
        /// <summary>
        /// 履行时间
        /// </summary>
        public string Fulfill { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        public string Date { get; set; }
        /// <summary>
        /// 预约表id
        /// </summary>
        public string TableId { get; set; }
        /// <summary>
        /// 时段id
        /// </summary>
        public string TimeId { get; set; }
        /// <summary>
        /// 商铺信息
        /// </summary>
        public Shop ShopMess { get; set; }
        /// <summary>
        /// 项目说明
        /// </summary>
        public AappointmentExplain Explain { get; set; }
        /// <summary>
        /// 订单日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateDate { get; set; }
    }
    /// <summary>
    /// 预约人信息
    /// </summary>
    public class AappointmentMan
    {
        /// <summary>
        /// 用户id
        /// </summary>
        public int Userid { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 用户电话
        /// </summary>
        public string Phone { get; set; }
    }
    /// <summary>
    /// 预约登记表
    /// </summary>
    public class AppointmentTable : Core, IAggregateRoot
    {
        /// <summary>
        /// 模板id
        /// </summary>
        public string ModelId { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        public string Date { get; set; }
        /// <summary>
        /// 商铺信息
        /// </summary>
        public Shop ShopMess { get; set; }
        /// <summary>
        /// 项目说明
        /// </summary>
        public AappointmentExplain Explain { get; set; }
        /// <summary>
        /// 安排
        /// </summary>
        public List<TimesArrange> Arrange { get; set; }
        /// <summary>
        /// 登记时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// 查询返回
        /// </summary>
        [BsonIgnore]
        public string Result { get; set; }
    }
    /// <summary>
    /// 时间段安排
    /// </summary>
    public class TimesArrange
    {
        /// <summary>
        /// 时段id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 时间段说明
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 设置预约数量
        /// </summary>
        public int SetNum { get; set; }
        /// <summary>
        /// 预约号列表
        /// </summary>
        public List<string> Aappointment { get; set; }
    }
    /// <summary>
    /// 预约项目说明
    /// </summary>
    public class AappointmentExplain 
    {
        /// <summary>
        /// 项目名
        /// </summary>
        public string ItemName { get; set; }
        /// <summary>
        /// 项目价格
        /// </summary>
        public int ItemPrice { get; set; }
        /// <summary>
        /// 项目图片
        /// </summary>
        public string ItemImage { get; set; }
    }


}
