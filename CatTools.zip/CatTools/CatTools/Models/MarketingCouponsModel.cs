﻿using CatTools.Shares;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    //营销券设计思路：
    //1.平台比例存储ScaleStack，保存平台设定的折扣类型和商户及平台的折扣比例，有平台进行数据维护，属性：客户优惠比例，表示让利的部分按100为免费，0不打折计算。
    //2.营销券存储MarketingCouponsStack ，保存平台发布的营销券的相关信息，有平台进行数据修改和添加
    //3.营销商品存储CommodityStack，保存商户商品的可折扣信息，由商户进行比例类别的选择和修改，数据添加由海派猫系统导入
    //4.客户券存储CustomerCouponsStack,保存客户券的领取和使用信息，在券领取时添加，在券使用修改。
    //5.比例计算对象Scale，计算对象的比例。
    //6.券使用对象CouponsUse，券使用的结构类型。
    //7.比例应用对象ScaleUse,比例应用的结构类型。
    /// <summary>
    /// 营销券仓储
    /// </summary>
    public class MarketingCouponsStack : Core, IAggregateRoot
    {
        /// <summary>
        /// 营销券说明内容
        /// </summary>
        [BsonElement("Content")]
        public string Content { get; set; }
        /// <summary>
        /// 营销券金额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 图片
        /// </summary>
        [BsonElement("Picture")]
        public string Picture { get; set; }
        /// <summary>
        /// 使用有效天数
        /// </summary>
        [BsonElement("UseDays")]
        public int UseDays { get; set; }
        /// <summary>
        /// 领取截止时间
        /// </summary>
        [BsonElement("TakeEndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime TakeEndTime { get; set; }
        /// <summary>
        /// 建立时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 是否有效
        /// </summary>
        [BsonElement("IsValid")]
        public bool IsValid { get; set; }
        /// <summary>
        /// 设定可以使用的折扣比例
        /// </summary>
        [BsonElement("SetScale")]
        public List<ScaleStack> SetScale { get; set; }
        public MarketingCouponsStack()
        {

        }
        /// <summary>
        /// 新建对象
        /// </summary>
        /// <param name="input"></param>
        public MarketingCouponsStack(MarketingCouponsInput input)
        {
            this.IsValid = true;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            //
            this.Money = input.Money;
            this.Picture = input.Picture;
            this.UseDays = input.UseDays;
            this.TakeEndTime = input.TakeEndTime;
            this.Content = input.Content;
            var setscale = new List<ScaleStack>();
            foreach (var i in input.SetNum)
            {
                var scale = Scale.Get(i);
                if (scale.CoustomerDis != 0)
                {
                    setscale.Add(scale);
                }
            }
            this.SetScale = setscale;
        }
       /// <summary>
       /// 修改对象
       /// </summary>
       /// <param name="input"></param>
        public void Update(MarketingCouponsInput input)
        {
            if (input.Money > 0)
            {
                this.Money = input.Money;
            }
            if (!string.IsNullOrEmpty(input.Picture))
            {
                this.Picture = input.Picture;
            }
            if (input.UseDays > 0)
            {
                this.UseDays = input.UseDays;
            }
            if (!input.TakeEndTime.Equals(this.TakeEndTime))
            {
                this.TakeEndTime = input.TakeEndTime;
            }
            if (!string.IsNullOrEmpty(input.Content))
            {
                this.Content = input.Content;
            }
            if (this.SetScale.Count() > 0)
            {
                var setscale = new List<ScaleStack>();
                foreach (var i in input.SetNum)
                {
                    var scale = Scale.Get(i);
                    if (scale.CoustomerDis != 0)
                    {
                        setscale.Add(scale);
                    }
                }
                this.SetScale = setscale;
            }
        }
    }
    /// <summary>
    /// 营销券输入，配合营销券仓储使用
    /// </summary>
    public class MarketingCouponsInput
    {
        /// <summary>
        /// 营销券说明内容
        /// </summary>
        [Display(Name = "营销券说明内容")]
        public string Content { get; set; }
        /// <summary>
        /// 营销券金额
        /// </summary>
        [Display(Name = "营销券金额")]
        public int Money { get; set; }
        /// <summary>
        /// 图片
        /// </summary>
        [Display(Name = "图片")]
        public string Picture { get; set; }
        /// <summary>
        /// 使用有效天数
        /// </summary>
        [Display(Name = "使用有效天数")]
        public int UseDays { get; set; }
        /// <summary>
        /// 领取截止时间
        /// </summary>
        [Display(Name = "领取截止时间")]
        [DataType(DataType.DateTime, ErrorMessage = "请输入日期时间格式")]
        public DateTime TakeEndTime { get; set; }
        /// <summary>
        /// 设定比例，对应ScaleModel客户优惠比例列表
        /// </summary>
        [Display(Name = "设定比例")]
        public int[] SetNum { get; set; }
    }

    /// <summary>
    /// 比例存储
    /// </summary>
    public class ScaleStack : Core, IAggregateRoot
    {
        /// <summary>
        /// 平台分担比例
        /// </summary>
        [BsonElement("Platform")]
        public int Platform { get; set; }
        /// <summary>
        /// 客户优惠比例
        /// </summary>
        [BsonElement("CoustomerDis")]
        public int CoustomerDis { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ScaleStack()
        {
            this.Platform = 0;
            this.CoustomerDis = 0;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="coustomer"></param>
        /// <param name="platform"></param>
        public ScaleStack(int coustomer, int platform=0)
        {
            if(coustomer > 100|| coustomer < 0)
            {
                this.Platform = 0;
                this.CoustomerDis = 0;
            }
            else
            {
                var scale = Scale.Get(coustomer);
                if (scale.CoustomerDis == 0)         //生成新记录
                {
                    this.CoustomerDis = coustomer;
                    if (platform < 0 | platform > coustomer)
                    {
                        this.Platform = 0;
                    }
                    else
                    {
                        this.Platform = platform;
                    }
                }
                else
                {
                    this.Platform = scale.Platform;
                    this.CoustomerDis = scale.CoustomerDis;
                }
            }
        }
    }
    /// <summary>
    /// 比例计算
    /// </summary>
    public static class Scale
    {
        private static List<ScaleStack> ScaleList { get; set; }
        /// <summary>
        /// 设置
        /// </summary>
        /// <param name="scalelist"></param>
        public static void SetScale(List<ScaleStack> scalelist)
        {
            ScaleList = scalelist;
        }
        /// <summary>
        /// 通过比例读取
        /// </summary>
        /// <param name="coustomer"></param>
        /// <returns></returns>
        public static ScaleStack Get(int coustomer)
        {
            try
            {
                var result = ScaleList.Find(o => o.CoustomerDis == coustomer);
                return result;
            }
            catch
            {
                return new ScaleStack() { CoustomerDis = 0 };
            }
        }
        /// <summary>
        /// 通过比例和价格计算折扣金额
        /// </summary>
        /// <param name="coustomer"></param>
        /// <param name="price"></param>
        /// <returns></returns>
        public static ScaleUse GetUse(int coustomer,int price)
        {
            try
            {
                var temp = ScaleList.Find(o => o.CoustomerDis == coustomer);
                var result = new ScaleUse() {  CoustomerDis=temp.CoustomerDis, CoustomerMoney=temp.CoustomerDis*price, PlatformMoney=temp.Platform*price};
                return result;
            }
            catch
            {
                return default(ScaleUse);
            }
        }
        /// <summary>
        /// 获取比例列表
        /// </summary>
        /// <returns></returns>
        public static List<ScaleStack> GetScales()
        {
            return ScaleList;
        }
    }
    /// <summary>
    /// 比例应用
    /// </summary>
    public class ScaleUse
    {
        /// <summary>
        /// 客户免除金额
        /// </summary>
        public int CoustomerMoney { get; set; }
        /// <summary>
        /// 平台承担金额
        /// </summary>
        public int PlatformMoney { get; set; }
        /// <summary>
        /// 商户优惠比例
        /// </summary>
        public int CoustomerDis { get; set; }
    }
    /// <summary>
    /// 营销商品输入
    /// </summary>
    public class CommodityInput
    {
        /// <summary>
        /// 商品Id 
        /// </summary>
        [Display(Name = "商品Id")]
        public int ProductID { get; set; }
        /// <summary>
        /// 设定比例级别
        /// </summary>
        [Display(Name = "设定比例级别")]
        public int SetNum { get; set; }
    }
    /// <summary>
    /// 营销商品仓储
    /// </summary>
    public class CommodityStack : Core, IAggregateRoot
    {
        /// <summary>
        /// 商品Id 
        /// </summary>
        [BsonElement("ProductID")]
        public int ProductID { get; set; }
        /// <summary>
        /// 所属商户id
        /// </summary>
        [BsonElement("BusinessId")]
        public int BusinessId { get; set; }
        /// <summary>
        /// 所属用户id
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 品名
        /// </summary>
        [BsonElement("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 价格
        /// </summary>
        [BsonElement("Price")]
        public int Price { get; set; }
        /// <summary>
        /// 比例
        /// </summary>
        [BsonElement("SetScale")]
        public ScaleUse SetScale { get; set; }
        /// <summary>
        /// 建立时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        public CommodityStack()
        {

        }
        public CommodityStack(Return_GetBusinessId goods,int costomerdis )
        {
            this.ProductID = goods.Id;
            this.UserId = goods.UserId;
            this.Name = goods.Name;
            this.BusinessId = goods.BusinessId;
            this.Price = goods.Price;
            this.SetScale = Scale.GetUse(costomerdis, goods.Price);
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
    }
    /// <summary>
    /// 客户券存储
    /// </summary>
    public class CustomerCouponsStack : Core, IAggregateRoot
    {
        /// <summary>
        /// 营销券id
        /// </summary>
        [BsonElement("CouponsId")]
        public string CouponsId { get; set; }
        /// <summary>
        /// 客户id
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 券说明内容
        /// </summary>
        [BsonElement("Content")]
        public string Content { get; set; }
        /// <summary>
        /// 客户券面额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 图片
        /// </summary>
        [BsonElement("Picture")]
        public string Picture { get; set; }
        /// <summary>
        /// 使用截止时间
        /// </summary>
        [BsonElement("UseEndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime UseEndTime { get; set; }
        /// <summary>
        /// 使用记录
        /// </summary>
        [BsonElement("UseRecno")]
        public List<CouponsUse> UseRecno { get; set; }
        /// <summary>
        /// 券余额
        /// </summary>
        [BsonElement("Balance")]
        public int Balance { get; set; }
        /// <summary>
        /// 建立时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        public CustomerCouponsStack()
        {

        }
        public CustomerCouponsStack(MarketingCouponsStack marketing, int userid)
        {
            this.CouponsId = marketing.Id;
            this.UserId = userid;
            this.Money = marketing.Money;
            this.Picture = marketing.Picture;
            this.Content = marketing.Content;
            this.UseEndTime = DateTime.Now.AddDays(marketing.UseDays);
            this.UseRecno = new List<CouponsUse>();
            this.Balance = marketing.Money;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
    }
    /// <summary>
    /// 券使用
    /// </summary>
    public class CouponsUse
    {
        /// <summary>
        /// 使用时间
        /// </summary>
        public DateTime UseTime { get; set; }
        /// <summary>
        /// 券使用金额
        /// </summary>
        public int UseMoney { get; set; }
        /// <summary>
        /// 商品Id 
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// 应用比例
        /// </summary>
        public ScaleUse SetScale { get; set; }
    }
}
