﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    /// <summary>
    /// 促销活动实体
    /// </summary>
    public class Activity : Core, IAggregateRoot
    {
        /// <summary>
        /// 工具类别
        /// </summary>
        [BsonElement("Kind")]
        public ActivityType Kind { get; set; }
        /// <summary>
        /// 活动主题
        /// </summary>
        [BsonElement("Title")]
        public string Title { get; set; }
        /// <summary>
        /// 活动说明
        /// </summary>
        [BsonElement("Instructions")]
        public string Instructions { get; set; }
        /// <summary>
        /// 面值 
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 活动图片
        /// </summary>
        [BsonElement("Picture")]
        public string Picture { get; set; }
        /// <summary>
        /// 图片列表
        /// </summary>
        [BsonElement("PictureList")]
        public string[] PictureList { get; set; }
        /// <summary>
        /// 套餐金额
        /// </summary>
        [BsonElement("SetMoney")]
        public int SetMoney { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        [BsonElement("Amount")]
        public int Amount { get; set; }
        /// <summary>
        /// 佣金比例
        /// </summary>
        [BsonElement("Proportion")]
        public double Proportion { get; set; }
        /// <summary>
        /// 商品列表
        /// </summary>
        [BsonElement("Goodses")]
        public int[] Goodses { get; set; }
        /// <summary>
        /// 发起人编号
        /// </summary>
        [BsonElement("UId")]
        public int UId { get; set; }
        /// <summary>
        /// 浏览人列表
        /// </summary>
        [BsonElement("BrowseList")]
        public int[] BrowseList { get; set; }
        /// <summary>
        /// 参与人列表
        /// </summary>
        [BsonElement("ParticipateList")]
        public int[] ParticipateList { get; set; }
        /// <summary>
        /// 购买次数
        /// </summary>
        [BsonElement("PayNumber")]
        public int PayNumber { get; set; }
        /// <summary>
        /// 嗨派猫商户id
        /// </summary>
        [BsonElement("BusinessId")]
        public int BusinessId { get; set; }
        /// <summary>
        /// 截止期
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 使用截止期
        /// </summary>
        [BsonElement("UseEndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime UseEndTime { get; set; }
        /// <summary>
        /// 是否有效
        /// </summary>
        [BsonElement("IsValid")]
        public bool IsValid { get; set; }
        /// <summary>
        /// 是否支付
        /// </summary>
        [BsonElement("IsPay")]
        public bool IsPay { get; set; }
        /// <summary>
        /// 活动发起时间
        /// </summary>
        [BsonElement("CreateTime")]
        //[BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Activity()
        {

        }
        /// <summary>
        /// 添加活动
        /// </summary>
        /// <param name="data"></param>
        /// <param name="uid"></param>
        /// <param name="businessid"></param>
        /// <returns></returns>
        public Activity(ActivityInput data,int uid,int businessid)
        {
            Kind = data.Kind;
            Title = data.Title;
            Instructions = data.Instructions;
            Money = data.Money;
            Picture = data.Picture;
            SetMoney = data.SetMoney;
            Amount = data.Amount;
            PictureList = data.PictureList;
            Proportion = data.Proportion;
            UId =uid;
            this.BusinessId = businessid; 
            EndTime = data.EndTime;
            UseEndTime = data.UseEndTime;
            this.Goodses =data.Goodses;
            this.PayNumber = data.PayNumber;
            //默认
            IsValid = true;
            BrowseList =new int[] {};
            ParticipateList = new int[] { };
            CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.IsPay = false;
        }
        /// <summary>
        /// 获取修改列表
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public List<string> UpdateList(ActivityInput data)
        {
            var result = new List<string>();
            //类别
            if (data.Kind != 0 & this.Kind != data.Kind)
            {
                this.Kind = data.Kind;
                result.Add("Kind");
            }
            //主题
            if (data.Title != null & this.Title != data.Title)
            {
                this.Title = data.Title;
                result.Add("Title");
            }
            //说明
            if (data.Instructions != null & this.Instructions != data.Instructions)
            {
                this.Instructions = data.Instructions;
                result.Add("Instructions");
            }
            //面值
            if (data.Money != 0 & this.Money != data.Money)
            {
                this.Money = data.Money;
                result.Add("Money");
            }
            //图片
            if (data.Picture != null & this.Picture != data.Picture)
            {
                this.Picture = data.Picture;
                result.Add("Picture");
            }
            //图片列表
            if (this.PictureList != data.PictureList)
            {
                this.PictureList = data.PictureList;
                result.Add("PictureList");
            }
            //套餐
            if (data.SetMoney != 0 & this.SetMoney != data.SetMoney)
            {
                this.SetMoney = data.SetMoney;
                result.Add("SetMoney");
            }
            //商品id表
            if (this.Goodses != data.Goodses)
            {
                this.Goodses = data.Goodses;
                result.Add("Goodses");
            }
            //数量
            if (data.Amount != 0 & this.Amount != data.Amount)
            {
                this.Amount = data.Amount;
                result.Add("Amount");
            }
            //次数
            if (data.PayNumber != 0 & this.PayNumber != data.PayNumber)
            {
                this.PayNumber = data.PayNumber;
                result.Add("PayNumber");
            }
            //佣金比例
            if (data.Proportion != 0 & this.Proportion != data.Proportion)
            {
                this.Proportion = data.Proportion;
                result.Add("Proportion");
            }
            //截止期
            if (data.EndTime !=this.EndTime )
            {
                this.EndTime = data.EndTime;
                result.Add("EndTime");
            }
            //使用截止期
            if (data.UseEndTime != this.UseEndTime)
            {
                this.UseEndTime = data.UseEndTime;
                result.Add("UseEndTime");
            }
            return result;
        }
    }
    /// <summary>
    /// 活动工具类别
    /// </summary>
    public enum ActivityType
    {
        /// <summary>
        /// 活动智能套框
        /// </summary>
        [Description("活动智能套框")]
        FirstTool,
        /// <summary>
        /// 带现金支付，分享红包分利的智能卡
        /// </summary>
        [Description("带现金支付，分享红包分利的智能卡")]
        SecondTool
    }
    /// <summary>
    /// 活动输入
    /// </summary>
    public class ActivityInput
    {
        /// <summary>
        /// 活动主题
        /// </summary>
        [Display(Name = "活动主题")]
        [DefaultValue("活动主题")]
        public string Title { get; set; }
        /// <summary>
        /// 活动说明
        /// </summary>
        [Display(Name = "活动说明")]
        [DefaultValue("活动说明")]
        public string Instructions { get; set; }
        /// <summary>
        /// 工具类别
        /// </summary>
        [Display(Name ="工具类别")]
        [DefaultValue(ActivityType.FirstTool)]
        public ActivityType Kind { get; set; }
        /// <summary>
        /// 面值 
        /// </summary>
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "面值:非零的正整数")]
        [Display(Name = "面值")]
        [DefaultValue(100)]
        public int Money { get; set; }
        /// <summary>
        /// 截止日期
        /// </summary>
        [Display(Name = " 截止日期")]
        [DefaultValue(typeof(DateTime))]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 使用截止日期
        /// </summary>
        [Display(Name = " 使用截止日期")]
        [DefaultValue(typeof(DateTime))]
        public DateTime UseEndTime { get; set; }
        /// <summary>
        /// 活动图片
        /// </summary>
        [Display(Name = "活动图片")]
        public string Picture { get; set; }
        /// <summary>
        /// 图片列表
        /// </summary>
        [Display(Name = "图片列表")]
        public string[] PictureList { get; set; }
        /// <summary>
        /// 套餐金额
        /// </summary>
        [RegularExpression(@"(0|[1-9][0-9]*)$", ErrorMessage = "套餐金额:零或者非零开头的数字")]
        [Display(Name = "套餐金额")]
        public int SetMoney { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        [Display(Name = "数量")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "数量:非零的正整数")]
        public int Amount { get; set; }
        /// <summary>
        /// 佣金比例
        /// </summary>
        [Display(Name = "佣金比例")]
        public double Proportion { get; set; }
        /// <summary>
        /// 商品id列表
        /// </summary>
        [Display(Name = "商品id列表")]
        public int[] Goodses { get; set; }
        /// <summary>
        /// 购买次数
        /// </summary>
        [Display(Name = "购买次数")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "单人购买次数:非零的正整数")]
        public int PayNumber { get; set; }
    }
    /// <summary>
    ///活动购买存储
    /// </summary>
    public class PurchaseActivity : Core, IAggregateRoot
    {
        /// <summary>
        /// 活动id
        /// </summary>
        [BsonElement("ActivityId")]
        public string ActivityId { get; set; }
        /// <summary>
        /// 发起人id
        /// </summary>
        [BsonElement("UId")]
        public int UId { get; set; }
        /// <summary>
        /// 购买人id
        /// </summary>
        [BsonElement("PurchaseId")]
        public int PurchaseId { get; set; }
        /// <summary>
        /// 活动券价值
        /// </summary>
        [BsonElement("Price")]
        public int Price { get; set; }
        /// <summary>
        /// 分享人
        /// </summary>
        [BsonElement("ShareID")]
        public int ShareID { get; set; }
        /// <summary>
        /// 是否使用
        /// </summary>
        [BsonElement("IsUsed")]
        public bool IsUsed { get; set; }
        /// <summary>
        /// 是否支付
        /// </summary>
        [BsonElement("IsPay")]
        public bool IsPay { get; set; }
        /// <summary>
        /// 分享金额
        /// </summary>
        [BsonElement("ShareMoney")]
        public int ShareMoney { get; set; }
        /// <summary>
        /// 订单时间
        /// </summary>
        [BsonElement("CreateTime")]
        //[BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 截止期
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 商品列表
        /// </summary>
        [BsonElement("Goodses")]
        public int[] Goodses { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public PurchaseActivity() { }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="order"></param>
        /// <param name="shareid"></param>
        /// <param name="purchaseid"></param>
        public PurchaseActivity(Activity order, int shareid,int purchaseid)
        {
            this.ActivityId =order.Id;
            this.Price = order.SetMoney;
            this.ShareID = shareid;
            this.UId = order.UId;
            this.PurchaseId = purchaseid;
            this.Goodses = order.Goodses;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.IsUsed = false;
            this.IsPay = false;
            //有分享，计算分享额
            if (shareid != 0)
            {
                this.ShareMoney = (int)(this.Price * order.Proportion);
            }
            else
            {
                this.ShareMoney = 0;
            }
            this.EndTime = order.UseEndTime;
        }
    }
    /// <summary>
    /// 活动购买显示
    /// </summary>
    public class PurchaseActivityModel
    {
        /// <summary>
        /// 活动购买id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 活动id
        /// </summary>
        public string ActivityId { get; set; }
        /// <summary>
        /// 活动主题
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 活动说明
        /// </summary>
        public string Instructions { get; set; }
        /// <summary>
        /// 活动图片
        /// </summary>
        public string Picture { get; set; }
        /// <summary>
        /// 发起人id
        /// </summary>
        public int UId { get; set; }
        /// <summary>
        /// 购买人id
        /// </summary>
        public int PurchaseId { get; set; }
        /// <summary>
        /// 活动券价值
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        /// 分享人
        /// </summary>
        public int ShareID { get; set; }
        /// <summary>
        /// 是否使用
        /// </summary>
        public bool IsUsed { get; set; }
        /// <summary>
        /// 是否支付
        /// </summary>
        public bool IsPay { get; set; }
        /// <summary>
        /// 分享金额
        /// </summary>
        public int ShareMoney { get; set; }
        /// <summary>
        /// 订单时间
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 截止期
        /// </summary>
        public DateTime EndTime { get; set; }
    }
    /// <summary>
    ///  活动购买记录输入
    /// </summary>
    public class PurchaseActivityInput
    {
        /// <summary>
        /// 活动id
        /// </summary>
        public string ActivityId { get; set; }
        /// <summary>
        /// 分享人
        /// </summary>
        public int ShareId { get; set; }
    }
    /// <summary>
    /// 活动领取存储
    /// </summary>
    public class ActivityTake : Core, IAggregateRoot
    {
        /// <summary>
        /// 活动id
        /// </summary>
        [BsonElement("ActivityId")]
        public string ActivityId { get; set; }
        /// <summary>
        /// 发起人id
        /// </summary>
        [BsonElement("UId")]
        public int UId { get; set; }
        /// <summary>
        /// 领取人id
        /// </summary>
        [BsonElement("TakeId")]
        public int TakeId { get; set; }
        /// <summary>
        /// 活动券价值
        /// </summary>
        [BsonElement("Price")]
        public int Price { get; set; }
        /// <summary>
        /// 是否支付定金
        /// </summary>
        [BsonElement("IsPay")]
        public bool IsPay { get; set; }
        /// <summary>
        /// 是否使用
        /// </summary>
        [BsonElement("IsUsed")]
        public bool IsUsed { get; set; }
        /// <summary>
        /// 领取日期
        /// </summary>
        [BsonElement("CreateTime")]
        //[BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 截止期
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 商品列表
        /// </summary>
        [BsonElement("Goodses")]
        public int[] Goodses { get; set; }
        public ActivityTake()
        {

        }
        public ActivityTake(Activity order,int takeid)
        {
            this.ActivityId = order.Id;
            this.Price = order.Money;
            this.UId = order.UId;
            this.TakeId = takeid;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.IsUsed = false;
            this.Goodses = order.Goodses;
            this.EndTime = order.UseEndTime;
        }
    }
    /// <summary>
    /// 用户待收款账单
    /// </summary>
    public class Receipt : Core, IAggregateRoot
    {
        /// <summary>
        /// 原始单据编码
        /// </summary>
        [BsonElement("Code")]
        public string Code { get; set; }
        /// <summary>
        /// 账单类别，申请人/分享人
        /// </summary>
        [BsonElement("Kind")]
        public string Kind { get; set; }
        /// <summary>
        /// 说明
        /// </summary>
        [BsonElement("Body")]
        public string Body { get; set; }
        /// <summary>
        /// 用户Id
        /// </summary>
        [BsonElement("Uid")]
        public int Uid { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 记账时间
        /// </summary>
        [BsonElement("CreateTime")]
        //[BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 是否转出
        /// </summary>
        [BsonElement("IsTransfer")]
        public bool IsTransfer { get; set; }
        public Receipt() { }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="code"></param>
        /// <param name="body"></param>
        /// <param name="uid"></param>
        /// <param name="monry"></param>
        /// <param name="kind"></param>
        public Receipt(string code ,string body, int uid, int monry,string kind)
        {
            this.Code = code;
            this.Body = body;
            this.Kind = kind;
            this.Money = monry;
            this.Uid = uid;
            this.IsTransfer = false;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
    }
    /// <summary>
    /// 用户待收款账单显示
    /// </summary>
    public class ReceiptModel
    {
        /// <summary>
        /// 原始编码
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 说明
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 记账时间
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 是否转出
        /// </summary>
        public bool IsTransfer { get; set; }
        /// <summary>
        /// 自动转账，剩余天数
        /// </summary>
        public int Days { get; set; }
    }
    /// <summary>
    /// 购买人显示
    /// </summary>
    public class UserShow
    {
        /// <summary>
        /// id
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        public string Portrait { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        /// 购买时间
        /// </summary>
        public DateTime CreateTime { get; set; }
    }

}

