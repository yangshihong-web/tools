﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    /// <summary>
    /// 礼品预采购单
    /// </summary>
    public class GoodsOrders : Core, IAggregateRoot
    {
        /// <summary>
        /// 描述内容
        /// </summary>
        [BsonElement("Content")]
        public string Content { get; set; }
        /// <summary>
        /// 商品Id 
        /// </summary>
        [BsonElement("ProductID")]
        public int ProductID { get; set; }
        /// <summary>
        /// 商品规格Id 
        /// </summary>
        [BsonElement("ProductSpaceID")]
        public int ProductSpaceID { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        [BsonElement("Amount")]
        public int Amount { get; set; }
        /// <summary>
        /// 购买类型
        /// </summary>
        [BsonElement("PurchaseType")]
        public string PurchaseType { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        [BsonElement("OrderId")]
        public int OrderId { get; set; }
        /// <summary>
        /// 领取单号列表
        /// </summary>
        [BsonElement("TakeList")]
        public string[] TakeList { get; set; }
        /// <summary>
        /// 建立时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 是否有效
        /// </summary>
        [BsonElement("IsValid")]
        public bool IsValid { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public GoodsOrders(){ }
        /// <summary>
        /// 有参数的构造
        /// </summary>
        /// <param name="view"></param>
        public GoodsOrders(GoodsOrdersInput view)
        {
            this.UserId = view.UserId;
            this.Amount = view.Amount;
            this.Content = view.Content;
            this.OrderId = view.OrderId;
            this.ProductID = view.ProductID;
            this.ProductSpaceID = view.ProductSpaceID;
            this.PurchaseType = view.PurchaseType;
            this.TakeList = new string[] {"0"};
            this.Content = view.Content;
            this.IsValid = true;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
        /// <summary>
        /// 判断可否领取
        /// </summary>
        /// <returns></returns>
        public bool IsCanTake()
        {
            //是否终止
            if (!this.IsValid)
            {
                return false;
            }
            //判断剩余数量

            if (this.TakeList.Count() > this.Amount)
            {
                return false;
            }
            return true;
        }
    }
    /// <summary>
    /// 礼品预采购输入
    /// </summary>
    public class GoodsOrdersInput
    {
        /// <summary>
        /// 活动内容
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        /// 商品Id 
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// 商品规格Id 
        /// </summary>
        public int ProductSpaceID { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Amount { get; set; }
        /// <summary>
        /// 购买类型
        /// </summary>
        public string PurchaseType { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public int OrderId { get; set; }
    }
    /// <summary>
    /// 礼品领取单
    /// </summary>
    public class GoodsTakeOrders : Core, IAggregateRoot
    {
        ///// <summary>
        ///// Id
        ///// </summary>
        //[BsonId]
        //[BsonRepresentation(BsonType.ObjectId)]
        //public string Id { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        [BsonElement("OrdersId")]
        public int OrdersId { get; set; }
        /// <summary>
        /// 采购用户编号
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 商品Id 
        /// </summary>
        [BsonElement("ProductID")]
        public int ProductID { get; set; }
        /// <summary>
        /// 商品规格Id 
        /// </summary>
        [BsonElement("ProductSpaceID")]
        public int ProductSpaceID { get; set; }
        /// <summary>
        /// 购买类型
        /// </summary>
        [BsonElement("PurchaseType")]
        public string PurchaseType { get; set; }
        /// <summary>
        /// 领取用户id
        /// </summary>
        [BsonElement("TakeUserId")]
        public int TakeUserId { get; set; }
        /// <summary>
        /// 领取类别
        /// </summary>
        [BsonElement("Kind")]
        public TakeType Kind { get; set; }
        /// <summary>
        /// 发货地址
        /// </summary>
        [BsonElement("Address")]
        public int Address { get; set; }
        /// <summary>
        /// 是否发货
        /// </summary>
        [BsonElement("IsDelivered")]
        public bool IsDelivered { get; set; }
        /// <summary>
        /// 建立时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public GoodsTakeOrders() { }
        /// <summary>
        /// 有参数的构造
        /// </summary>
        /// <param name="order">采购单</param>
        /// <param name="takeuser">领取人信息</param>
        public GoodsTakeOrders(GoodsOrders order, GoodsTakeOrdersInput takeuser)
        {
            this.OrdersId = takeuser.OrdersId;
            this.ProductID = order.ProductID;
            this.ProductSpaceID = order.ProductSpaceID;
            this.PurchaseType = order.PurchaseType;
            this.Kind = takeuser.Kind;
            this.TakeUserId = takeuser.TakeUserId;
            this.UserId = order.UserId;
            this.Address = takeuser.Address;
            this.IsDelivered = false;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }

    }
    /// <summary>
    /// 礼品领取输入
    /// </summary>
    public class GoodsTakeOrdersInput
    {
        /// <summary>
        /// 采购单号
        /// </summary>
        public int OrdersId { get; set; }
        /// <summary>
        /// 领取用户id
        /// </summary>
        public int TakeUserId { get; set; }
        /// <summary>
        /// 发货地址
        /// </summary>
        public int Address { get; set; }
        /// <summary>
        /// 领取类别
        /// </summary>
        public TakeType Kind { get; set; }
    }
    /// <summary>
    /// 商品下单
    /// </summary>
    public  class PlaceOrderInputDto
    {
        /// <summary>
        /// 推荐人
        /// </summary>
        public int RefID { get; set; }
        /// <summary>
        /// 商品Id 
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// 商品规格Id 
        /// </summary>
        public int ProductSpaceID { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Amount { get; set; }
        /// <summary>
        /// 购买类型
        /// </summary>
        public string PurchaseType { get; set; }
        /// <summary>
        /// 购物车
        /// </summary>
        public int ShopCartID { get; set; }
    }
    /// <summary>
    /// 商品订单下单返回
    /// </summary>
    public class BatchPlaceOrderOutputDto
    {
        /// <summary>
        /// 支付号
        /// </summary>
        public string PayCode { get; set; }
        /// <summary>
        /// 订单ID
        /// </summary>
        public int[] IDs { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// 手续费
        /// </summary>
        public double Fee { get; set; }
        /// <summary>
        /// 使用积分
        /// </summary>
        public double Point { get; set; }
        /// <summary>
        /// 获得积分
        /// </summary>
        public double GetPoint { get; set; }
        /// <summary>
        /// 换货代金券
        /// </summary>
        public double SwitchPoint { get; set; }
        /// <summary>
        /// 支付金额
        /// </summary>
        public double PayMoney { get; set; }
        /// <summary>
        /// 使用优惠券
        /// </summary>
        public double Ecoupon { get; set; }
    }
}
