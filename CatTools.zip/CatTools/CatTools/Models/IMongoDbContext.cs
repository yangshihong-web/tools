﻿using MongoDB.Driver;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Linq.Expressions;
using CatTools.Shares;
using MongoDB.Bson;

namespace CatTools.Models
{
    public interface ICore
    {
        string Id { set; get; }
    }

    /// <summary>
    /// 聚合根
    /// </summary>
    public interface IAggregateRoot
    {
        string Id { set; get; }
    }

    /// <summary>
    /// 实体
    /// </summary>
    public abstract class Core : ICore
    {
        public string Id { set; get; } = IdWorkerHelper.GenId64().ToString();
    }
  
   
    public class MongoDBContext<T> 
    {
        private string _dataName = "ToolsDb";
        private string connstr = "mongodb://localhost:27017";
        //
        private MongoClient client { get; set; }
        private IMongoDatabase database { get; set; }
     
        public MongoDBContext()
        {
            client = new MongoClient(connstr);
            database = client.GetDatabase(_dataName);
            Db = database.GetCollection<T>(typeof(T).Name);
        }
        public MongoDBContext(string dataName)
        {
            client = new MongoClient(connstr);
            database = client.GetDatabase(dataName);
            Db = database.GetCollection<T>(typeof(T).Name);
        }
        public MongoDBContext(string dataName,string mongostr)
        {
            client = new MongoClient(mongostr);
            database = client.GetDatabase(dataName);
            Db = database.GetCollection<T>(typeof(T).Name);
        }
        public IMongoCollection<T> Db;
    }

    public static class MongodbExpansion
    {
        /// <summary>
        /// 单个对象添加
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        public static void Add<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
            => collection.InsertOne(entity);
        /// <summary>
        /// 单个对象添加,异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static async Task AddAsync<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
            => await collection.InsertOneAsync(entity);
        /// <summary>
        /// 集合添加
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entitys"></param>
        public static void AddRange<T>(this IMongoCollection<T> collection, List<T> entitys) where T : IAggregateRoot
            => collection.InsertMany(entitys);
        /// <summary>
        /// 集合添加,异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entitys"></param>
        /// <returns></returns>
        public static async Task AddRangeAsync<T>(this IMongoCollection<T> collection, List<T> entitys) where T : IAggregateRoot
            => await collection.InsertManyAsync(entitys);

        /// <summary>
        /// entity mongodb需要更新的实体 properts需要更新的集合属性,大小写不限 默认更新整个对象 replace 默认空属性不修改
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity">mongodb需要更新的实体</param>
        /// <param name="properts">需要更新的集合属性,大小写不限 默认更新整个对象 </param>
        /// <param name="replace">默认对象属性为空时不替换当前值</param>
        public static async Task Update<T>(this IMongoCollection<T> collection, T entity, List<string> properts = null, bool replace = false) where T : IAggregateRoot
        {
            if (entity == null)
                throw new NullReferenceException();

            var type = entity.GetType();
            //修改的属性集合
            var list = new List<UpdateDefinition<T>>();

            foreach (var propert in type.GetProperties())
            {
                if (propert.Name.ToLower() != "id")
                {
                    if (properts == null || properts.Count < 1 || properts.Any(o => o.ToLower() == propert.Name.ToLower()))
                    {
                        var replaceValue = propert.GetValue(entity);
                        if (replaceValue != null)
                        {
                            list.Add(Builders<T>.Update.Set(propert.Name, replaceValue));
                        }
                        else if (replace)
                            list.Add(Builders<T>.Update.Set(propert.Name, replaceValue));
                    }
                }
            }
            #region 有可修改的属性
            if (list.Count > 0)
            {
                //合并多个修改//new List<UpdateDefinition<T>>() { Builders<T>.Update.Set("Name", "111") }
                var builders = Builders<T>.Update.Combine(list);
                //执行提交修改
                await collection.UpdateManyAsync(o => o.Id == entity.Id, builders);
            }
            #endregion

        }
        /// <summary>
        /// 按条件更改实体个别信息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="filter"></param>
        /// <param name="entity"></param>
        public static void UpdateSub<T>(this IMongoCollection<T> collection, FilterDefinition<T> filter, UpdateDefinition<T> entity) where T : IAggregateRoot
        => collection.UpdateOne(filter, entity);
        /// <summary>
        /// 按条件更改实体个别信息，异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="filter"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static async Task UpdateSubAsync<T>(this IMongoCollection<T> collection, FilterDefinition<T> filter, UpdateDefinition<T> entity) where T : IAggregateRoot
        => await collection.UpdateOneAsync(filter, entity);
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        public static void Update<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
        => collection.ReplaceOne(Builders<T>.Filter.Eq("Id", entity.Id), entity);
        /// <summary>
        /// 更新实体,异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static async Task UpdateAsync<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
        => await collection.ReplaceOneAsync(Builders<T>.Filter.Eq("Id", entity.Id), entity);
        /// <summary>
        /// 移除依据ID
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        public static void Remove<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
        => collection.DeleteOne(o => o.Id == entity.Id);
        /// <summary>
        /// 移除依据ID，异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static async Task RemoveAsync<T>(this IMongoCollection<T> collection, T entity) where T : IAggregateRoot
        => await collection.DeleteOneAsync(o => o.Id == entity.Id);
        /// <summary>
        /// 移除表达式
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="expression"></param>
        public static void Remove<T>(this IMongoCollection<T> collection, Expression<Func<T, bool>> expression) where T : IAggregateRoot
        => collection.DeleteOne(expression);
        /// <summary>
        /// 移除表达式,异步
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static async Task RemoveAsync<T>(this IMongoCollection<T> collection, Expression<Func<T, bool>> expression) where T : IAggregateRoot
        => await collection.DeleteOneAsync(expression);
        /// <summary>
        /// 获取表达式内容
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static IFindFluent<T, T> Where<T>(this IMongoCollection<T> collection, Expression<Func<T, bool>> expression)
        => expression == null ? collection.Find(Builders<T>.Filter.Empty) : collection.Find(expression);

        /// <summary>
        /// MongoDB里面是没有实现IQueryable的 所以想要使用习惯的SELECT我们只能自己封装一下
        /// </summary>
        /// <typeparam name="TDocument"></typeparam>
        /// <typeparam name="TProjection"></typeparam>
        /// <typeparam name="TNewProjection">返回新的数据类型</typeparam>
        /// <param name="IQueryable"></param>
        /// <param name="projection"></param>
        /// <returns></returns>
        public static IFindFluent<TDocument, TNewProjection> Select<TDocument, TProjection, TNewProjection>(this IFindFluent<TDocument, TProjection> IQueryable, Expression<Func<TDocument, TNewProjection>> projection)
        => IQueryable.Project(projection);
        /// <summary>
        /// 获得筛选后的首个元素
        /// </summary>
        /// <typeparam name="TDocument"></typeparam>
        /// <typeparam name="T"></typeparam>
        /// <param name="IQueryable"></param>
        /// <returns></returns>
        public static T FirstOrDefault<TDocument, T>(this IFindFluent<TDocument, T> IQueryable)
        {
            try
            {
                return IQueryable.First();
            }
            catch
            {
                return default(T);
            }
        }
        /// <summary>
        /// 直接支持表达式树后的首个满足对象
        /// </summary>
        /// <typeparam name="TDocument"></typeparam>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static T FirstOrDefault<TDocument, T>(this IMongoCollection<T> collection, Expression<Func<T, bool>> expression = null)
        => expression == null ? collection.Find(Builders<T>.Filter.Empty).First() : collection.Find(expression).First();
    }
    /// <summary>
    /// 数据操作接口
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IRepository<T> where T : IAggregateRoot
    {
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task AddAsync(T entity);
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="properts"></param>
        /// <param name="replace"></param>
        /// <returns></returns>
        Task UpdateAsync(T entity, List<string> properts = null, bool replace = false);
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task UpdateAsync(T entity);
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task UpdateAsync(FilterDefinition<T> filter, UpdateDefinition<T> entity);
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task RemoveAsync(T entity);
        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <returns></returns>
        T Get(Expression<Func<T, bool>> seachdefinition);
        /// <summary>
        /// 获取列表,有条件(时间排序)
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <param name="orderdefinition">时排序</param>
        /// <returns></returns>
        List<T> GetList(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, DateTime>> orderdefinition);
        /// <summary>
        /// 获取列表,有条件(数值排序)
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="orderdefinition"></param>
        /// <returns></returns>
        List<T> GetList(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, int>> orderdefinition);
        /// <summary>
        /// 获取列表,有条件(不排序)
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <returns></returns>
        List<T> GetList(Expression<Func<T, bool>> seachdefinition);
        /// <summary>
        /// 获取条件分页列表(按时间排序)
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <param name="orderdefinition">时间排序</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录</param>
        /// <returns></returns>
        List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, DateTime>> orderdefinition, int PageIndex, int PageSize);
        /// <summary>
        /// 获取条件分页列表(按数值排序)
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <param name="orderdefinition">数值排序</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录</param>
        /// <returns></returns>
        List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, int>> orderdefinition, int PageIndex, int PageSize);
        /// <summary>
        /// 获取条件分页列表
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录</param>
        /// <returns></returns>
        List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, int PageIndex, int PageSize);
        /// <summary>
        /// 获取条件分页总页数
        /// </summary>
        /// <param name="seachdefinition">条件</param>
        /// <param name="pagesize">记录数</param>
        /// <returns></returns>
        int GetTotalPage(Expression<Func<T, bool>> seachdefinition, int pagesize);
        /// <summary>
        /// 基础查询模式
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        IFindFluent<T, T> GetQueryable(Expression<Func<T, bool>> expression = null);
    }
    /// <summary>
    /// 数据操作
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Repository<T> : IRepository<T> where T : IAggregateRoot
    {
        private MongoDBContext<T> _context;
        public Repository() { }
        public Repository(MongoDBContext<T> context)
        {
            this._context = context;
        }
        /// <summary>
        ///  添加,异步
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task AddAsync(T entity)
        {
            await _context.Db.AddAsync(entity);
        }
        /// <summary>
        /// 添加index
        /// </summary>
        /// <param name="couponIndexModel"></param>
        /// <returns></returns>
        public async Task IndexAsync(CreateIndexModel<T> couponIndexModel)
        {
            //var couponIndex = new IndexKeysDefinitionBuilder<T>().Ascending(c => c.CouponNumber);
            //var couponIndexModel = new CreateIndexModel<T>(couponIndex);
            await _context.Db.Indexes.CreateOneAsync(couponIndexModel);//Exception happens at this line
        }
        /// <summary>
        /// 修改，提供实体和字段列表名
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="properts"></param>
        /// <param name="replace"></param>
        public async Task UpdateAsync(T entity, List<string> properts = null, bool replace = false)
        {
            await _context.Db.Update(entity, properts, replace);
        }
        /// <summary>
        /// 更新实体
        /// </summary>
        /// <param name="entity"></param>
        public async Task UpdateAsync(T entity)
        {
            await _context.Db.UpdateAsync(entity);
        }
        /// <summary>
        /// 修改，任意条件修改任意字段内容
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="entity"></param>
        public async Task UpdateAsync(FilterDefinition<T> filter, UpdateDefinition<T> entity)
        {
            await _context.Db.UpdateSubAsync(filter, entity);
        }
        /// <summary>
        ///  移除,异步
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task RemoveAsync(T entity)
        {
            await _context.Db.RemoveAsync(entity);
        }
        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <returns></returns>
        public T Get(Expression<Func<T, bool>> seachdefinition)
        {
            try
            {
                return _context.Db.Find<T>(seachdefinition).First();
            }
            catch
            {
                return default(T);
            }
        }
        /// <summary>
        /// 获取条件列表（时间排序）
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="orderdefinition"></param>
        /// <returns></returns>
        public List<T> GetList(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, DateTime>> orderdefinition)
        {
            return _context.Db.AsQueryable<T>().OrderByDescending(orderdefinition).Where(seachdefinition).ToList();
        }
        /// <summary>
        ///  获取条件列表（数值排序）
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="orderdefinition"></param>
        /// <returns></returns>
        public List<T> GetList(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, int>> orderdefinition)
        {
            return _context.Db.AsQueryable<T>().OrderByDescending(orderdefinition).Where(seachdefinition).ToList();
        }
        /// <summary>
        /// 获取条件列表（时间排序）
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <returns></returns>
        public List<T> GetList(Expression<Func<T, bool>> seachdefinition)
        {
           
              return _context.Db.AsQueryable<T>().Where(seachdefinition).ToList();
      
        }
        /// <summary>
        /// 获取分页列表（时间排序）
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="orderdefinition"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, DateTime>> orderdefinition, int PageIndex, int PageSize)
        {
            return _context.Db.AsQueryable<T>().OrderByDescending(orderdefinition).Skip(PageIndex * PageSize - PageSize).Take(PageSize).Where(seachdefinition).ToList();
        }
        /// <summary>
        /// 获取分页列表(数值排序)
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="orderdefinition"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, int>> orderdefinition, int PageIndex, int PageSize)
        {
            return _context.Db.AsQueryable<T>().OrderByDescending(orderdefinition).Skip(PageIndex * PageSize - PageSize).Take(PageSize).Where(seachdefinition).ToList();
        }
        /// <summary>
        /// 获取分页总页数
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetTotalPage(Expression<Func<T, bool>> seachdefinition, int pagesize)
        {
            var query = _context.Db.AsQueryable<T>().Where(seachdefinition).Count();
            return CommonClass.GetPages(query, pagesize);
        }
        /// <summary>
        /// 查询，列表
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public IFindFluent<T, T> GetQueryable(Expression<Func<T, bool>> expression = null)
        {
            try
            {
                var temp = _context.Db.Where(expression);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取分页列表
        /// </summary>
        /// <param name="seachdefinition">统计条件</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录数</param>
        /// <returns></returns>
        public List<T> GetListPage(Expression<Func<T, bool>> seachdefinition, int PageIndex, int PageSize)
        {
            return _context.Db.AsQueryable<T>().Skip(PageIndex * PageSize - PageSize).Take(PageSize).Where(seachdefinition).ToList();
        }
    }
    /// <summary>
    /// Mongo数据操作
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class MongoRespository<T> : Repository<T> where T : IAggregateRoot
    {
        public MongoRespository():base()
        {

        }
        public MongoRespository(MongoDBContext<T> context) : base(context)
        {

        }
    }
}
