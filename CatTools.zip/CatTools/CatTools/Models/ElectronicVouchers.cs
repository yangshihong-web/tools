﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;


namespace CatTools.Models
{
    /// <summary>
    /// 电子券
    /// </summary>
    public class ElectronicVouchers : Core, IAggregateRoot
    {
        /// <summary>
        /// 电子券说明内容
        /// </summary>
        [BsonElement("Content")]
        public string Content { get; set; }
        /// <summary>
        /// 掌联商家编号
        /// </summary>
        [BsonElement("ZLUId")]
        public int ZLUId { get; set; }
        /// <summary>
        /// 掌联商品Id列表 
        /// </summary>
        [BsonElement("ZLProductID")]
        public int[] ZLProductID { get; set; }
        /// <summary>
        /// 嗨派猫商家编号
        /// </summary>
        [BsonElement("HPUId")]
        public int HPUId { get; set; }
        /// <summary>
        /// 嗨派猫商品Id列表 
        /// </summary>
        [BsonElement("HPProductID")]
        public int[] HPProductID { get; set; }
        /// <summary>
        /// 电子券金额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 图片
        /// </summary>
        [BsonElement("Picture")]
        public string Picture { get; set; }
        /// <summary>
        /// 电子券数量
        /// </summary>
        [BsonElement("Amount")]
        public int Amount { get; set; }
        /// <summary>
        /// 截止时间
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 是否有效
        /// </summary>
        [BsonElement("IsValid")]
        public bool IsValid { get; set; }
        /// <summary>
        /// 领取人的列表
        /// </summary>
        [BsonElement("TakeList")]
        public int[] TakeList { get; set; }
        /// <summary>
        /// 建立日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public ElectronicVouchers() { }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="input"></param>
        public ElectronicVouchers(ElectronicVouchersInput input)
        {
            this.Content = input.Content;
            this.Amount = input.Amount;
            this.EndTime = input.EndTime;
            this.HPProductID = input.HPProductID;
            this.HPUId = input.HPUId;
            this.ZLProductID = input.ZLProductID;
            this.ZLUId = input.ZLUId;
            this.Money = input.Money;
            this.Picture = input.Picture;
            //
            this.TakeList = new int[] { };
            this.IsValid = true;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
        /// <summary>
        /// 获取修改列表
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public List<string> UpdateList(ElectronicVouchersModi data)
        {
            var result = new List<string>();
            //主题
            if (data.Content != null & this.Content != data.Content)
            {
                this.Content = data.Content;
                result.Add("Content");
            }
            //面值
            if (data.Money != 0 & this.Money != data.Money)
            {
                this.Money = data.Money;
                result.Add("Money");
            }
            //嗨派猫商家
            if (data.HPUId != 0 & this.HPUId != data.HPUId)
            {
                this.HPUId = data.HPUId;
                result.Add("HPUId");
            }
            //嗨派猫产品列表
            if (data.HPProductID != null & this.HPProductID != data.HPProductID)
            {
                this.HPProductID = data.HPProductID;
                result.Add("HPProductID");
            }
            //数量
            if (data.Amount != 0 & this.Amount != data.Amount)
            {
                this.Amount = data.Amount;
                result.Add("Amount");
            }
            //掌联商家
            if (data.ZLUId != 0 & this.ZLUId != data.ZLUId)
            {
                this.ZLUId = data.ZLUId;
                result.Add("ZLUId ");
            }
            //掌联产品列表
            if (data.ZLProductID != null & this.ZLProductID != data.ZLProductID)
            {
                this.ZLProductID = data.ZLProductID;
                result.Add("ZLProductID");
            }
            //截止期
            if (data.EndTime != null & this.EndTime != data.EndTime)
            {
                this.EndTime = data.EndTime;
                result.Add("EndTime");
            }
            //图片
            if (data.Picture!= null & this.Picture != data.Picture)
            {
                this.Picture = data.Picture;
                result.Add("Picture");
            }
            return result;
        }
    }
    /// <summary>
    /// 电子券输入
    /// </summary>
    public class ElectronicVouchersInput
    {
        /// <summary>
        /// 电子券说明内容
        /// </summary>
        [Required(ErrorMessage = "电子券说明内容需要输入")]
        [StringLength(200, ErrorMessage = "电子券说明内容需要小于200字符")]
        [Display(Name = "电子券说明内容")]
        public string Content { get; set; }
        /// <summary>
        /// 掌联商户ID
        /// </summary>
        [Required(ErrorMessage = "掌联商户编号需要输入")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "掌联商户ID:非零的正整数")]
        [Display(Name = "掌联商户ID")]
        public int ZLUId { get; set; }
        /// <summary>
        /// 掌联商品Id列表 
        /// </summary>
        [Display(Name = "掌联商品Id列表")]
        public int[] ZLProductID { get; set; }
        /// <summary>
        /// 嗨派猫商家编号
        /// </summary>
        [Required(ErrorMessage = "嗨派猫商家编号需要输入")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "掌联商户ID:非零的正整数")]
        [Display(Name = "嗨派猫商家编号")]
        public int HPUId { get; set; }
        /// <summary>
        /// 嗨派猫商品Id列表 
        /// </summary>
        [Display(Name = "嗨派猫商品Id列表")]
        public int[] HPProductID { get; set; }
        /// <summary>
        /// 电子券金额
        /// </summary>
        [Required(ErrorMessage = "电子券金额需要输入")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "电子券金额:非零的正整数")]
        [Display(Name = "电子券金额")]
        public int Money { get; set; }
        /// <summary>
        /// 电子券数量
        /// </summary>
        [Required(ErrorMessage = "电子券数量需要输入")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "电子券数量:非零的正整数")]
        [DisplayName("电子券数量")]
        public int Amount { get; set; }
        /// <summary>
        /// 截止时间
        /// </summary>
        [Required(ErrorMessage = "截止时间需要输入")]
        [DataType(DataType.DateTime, ErrorMessage = "请输入日期时间格式")]
        [Display(Name = "截止时间")]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 图片·
        /// </summary>
        [Display(Name = "图片")]
        public string Picture { get; set; }
    }
    /// <summary>
    /// 电子券修改
    /// </summary>
    public class ElectronicVouchersModi
    {
        /// <summary>
        /// 电子券说明内容
        /// </summary>
        [Display(Name = "电子券说明内容")]
        public string Content { get; set; }
        /// <summary>
        /// 掌联商户ID
        /// </summary>
        [Display(Name = "掌联商户ID")]
        public int ZLUId { get; set; }
        /// <summary>
        /// 掌联商品Id列表 
        /// </summary>
        [Display(Name = "掌联商品Id列表")]
        public int[] ZLProductID { get; set; }
        /// <summary>
        /// 嗨派猫商家编号
        /// </summary>
        [Display(Name = "嗨派猫商家编号")]
        public int HPUId { get; set; }
        /// <summary>
        /// 嗨派猫商品Id列表 
        /// </summary>
        [Display(Name = "嗨派猫商品Id列表")]
        public int[] HPProductID { get; set; }
        /// <summary>
        /// 电子券金额
        /// </summary>
        [Display(Name = "电子券金额")]
        public int Money { get; set; }
        /// <summary>
        /// 电子券数量
        /// </summary>
        [Display(Name = "电子券数量")]
        public int Amount { get; set; }
        /// <summary>
        /// 截止时间
        /// </summary>
        [Display(Name = "截止时间")]
        [DataType(DataType.DateTime, ErrorMessage = "请输入日期时间格式")]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 图片·
        /// </summary>
        [Display(Name = "图片")]
        public string Picture { get; set; }
    }
    /// <summary>
    /// 电子券领取记录
    /// </summary>
    public class TakeVouchers : Core, IAggregateRoot
    {
        /// <summary>
        /// 电子券id
        /// </summary>
        [BsonElement("VouchersId")]
        public string VouchersId { get; set; }
        /// <summary>
        /// 领取人id
        /// </summary>
        [BsonElement("TakeId")]
        public int TakeId { get; set; }
        /// <summary>
        /// 电子券面额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 截止期
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 使用额
        /// </summary>
        [BsonElement("UseMoney")]
        public int UseMoney { get; set; }
        /// <summary>
        /// 派发类别
        /// </summary>
        [BsonElement("Kind")]
        public VouchersSendKind Kind { get; set; }
        /// <summary>
        /// 领取日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public TakeVouchers() { }
        /// <summary>
        /// 带参数的构造
        /// </summary>
        /// <param name="order"></param>
        /// <param name="input"></param>
        public TakeVouchers(ElectronicVouchers order,TakeVouchersInput input)
        {
            this.VouchersId = input.VouchersId;
            this.Money = order.Money;
            this.TakeId = input.TakeId;
            this.Kind = input.Kind;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.EndTime = order.EndTime;
            this.UseMoney= 0;
        }
    }
    /// <summary>
    ///  电子券领取记录输入
    /// </summary>
    public class TakeVouchersInput
    {
        /// <summary>
        /// 电子券id
        /// </summary>
        [Required(ErrorMessage = "电子券ID需要输入")]
        [Display(Name = "电子券ID")]
        public string VouchersId { get; set; }
        /// <summary>
        /// 领取人id
        /// </summary>
        [Required(ErrorMessage = "领取人ID需要输入")]
        [RegularExpression(@"\+?[1-9][0-9]*$", ErrorMessage = "领取人ID:非零的正整数")]
        [Display(Name = "领取人ID")]
        public int TakeId { get; set; }
        /// <summary>
        /// 派发类别
        /// </summary>
        [Required(ErrorMessage = "派发类别需要输入")]
        [EnumDataType(typeof(VouchersSendKind),ErrorMessage = "请输入类别格式0-无类别，1-送好友，2-转发微信群，3-转发电话群，4-转发名片用户")]
        [Display(Name = "派发类别")]
        public VouchersSendKind Kind { get; set; }
    }
    /// <summary>
    /// 电子券派发类别
    /// </summary>
    public enum VouchersSendKind
    {
        /// <summary>
        /// 无类别
        /// </summary>
        [Description("无类别")]
        UnKind = 0,
        /// <summary>
        /// 送好友
        /// </summary>
        [Description("送好友")]
        SendFriend=1,
        /// <summary>
        /// 转发微信群
        /// </summary>
        [Description("转发微信群")]
        RepostWeChat =2,
        /// <summary>
        /// 转发电话群
        /// </summary>
        [Description("转发电话群")]
        RepostPhoneGroup = 3,
        /// <summary>
        /// 转发名片用户
        /// </summary>
        [Description("转发名片用户")]
        RepostCardGroup = 4
    }
  
}
