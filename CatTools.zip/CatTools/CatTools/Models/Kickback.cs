﻿using CatTools.Shares;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.ComponentModel;


namespace CatTools.Models
{
    /// <summary>
    /// 红包Kickback
    /// </summary>
    public class Kickback : Core, IAggregateRoot
    {
        ///// <summary>
        ///// 红包编号
        ///// </summary>
        //[BsonId]
        //[BsonRepresentation(BsonType.ObjectId)]
        //public string Id { get; set; }
        /// <summary>
        /// 红包发送人id
        /// </summary>
        public int SendManId { get; set; }
        /// <summary>
        /// 红包发送人姓名
        /// </summary>
        public string SendManName { get; set; }
        /// <summary>
        /// 客户电话
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 发送人头像
        /// </summary>
        public string Portrait { get; set; }
        /// <summary>
        /// 红包总金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 红包总人数
        /// </summary>
        public int People { get; set; }
        /// <summary>
        /// 单笔红包领取金额
        /// </summary>
        public int SingleMoney { get; set; }
        /// <summary>
        /// 红包截止时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 红包发放时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 红包是否有效
        /// </summary>
        public bool IsValid { get; set; }
        /// <summary>
        /// 已领取总金额
        /// </summary>
        public int TakeMoney { get; set; }
        /// <summary>
        /// 已领取总人数
        /// </summary>
        public int TakePeople { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public Kickback()
        {

        }
        /// <summary>
        /// 带参数的构造，生成新红包
        /// </summary>
        /// <param name="input"></param>
        public Kickback(KickbackDistribute input)
        {
            //设置输入值
            this.SendManId = input.SendManId;
            this.SendManName = input.SendManName;
            this.Money = input.Money;
            this.People = input.People;
            this.SingleMoney = input.SingleMoney;
            this.Phone = input.Phone;
            this.Portrait = input.Portrait;
            //设置默认值
            this.EndTime = DateTime.Now.AddDays(input.ValidTime);
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.TakeMoney = 0;
            this.TakePeople = 0;
            this.IsValid = true;
        }
    }
    /// <summary>
    /// 红包发放
    /// </summary>
    public class KickbackDistribute
    {
        /// <summary>
        /// 红包发送人id
        /// </summary>
        public int SendManId { get; set; }
        /// <summary>
        /// 红包发送人姓名
        /// </summary>
        public string SendManName { get; set; }
        /// <summary>
        /// 客户电话
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 发送人头像
        /// </summary>
        public string Portrait { get; set; }
        /// <summary>
        /// 红包总金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 红包总人数
        /// </summary>
        public int People { get; set; }
        /// <summary>
        /// 单笔红包领取金额
        /// </summary>
        public int SingleMoney { get; set; }
        /// <summary>
        /// 红包有效时间
        /// </summary>
        public int ValidTime { get; set; }
    }
    /// <summary>
    /// 新红包输入数据
    /// </summary>
    public class NewKickbackInput
    {
        /// <summary>
        /// 用户电话
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 红包总金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 红包总人数
        /// </summary>
        public int People { get; set; }
        /// <summary>
        /// 单笔红包领取金额
        /// </summary>
        public int SingleMoney { get; set; }
    }
    /// <summary>
    /// 红包领取记录
    /// </summary>
    public class TakeKickback : Core, IAggregateRoot
    {
        ///// <summary>
        ///// 红包领取编号
        ///// </summary>
        //[BsonId]
        //[BsonRepresentation(BsonType.ObjectId)]
        //public string Id { get; set; }
        /// <summary>
        /// 对应的红包id
        /// </summary>
        public string KickbackId { get; set; }
        /// <summary>
        /// 红包领取人id
        /// </summary>
        public int TakeManId { get; set; }
        /// <summary>
        /// 红包领取人姓名
        /// </summary>
        public string TakeManName { get; set; }
        /// <summary>
        /// 客户电话
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 领取人头像
        /// </summary>
        public string Portrait { get; set; }
        /// <summary>
        /// 领取类别
        /// </summary>
        public TakeType Kind { get; set; }
        /// <summary>
        /// 领取金额
        /// </summary>
        public int TakeMoney { get; set; }
        /// <summary>
        /// 领取时间
        /// </summary>
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime TakeTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public TakeKickback()
        {

        }
        /// <summary>
        /// 带参数构造,生成领取人
        /// </summary>
        /// <param name="view"></param>
        /// <param name="user"></param>
        /// <param name="takemoney"></param>
        public TakeKickback(TakeKickbackInput view, UserOutputDto user,int takemoney)
        {
            this.KickbackId = view.KickbackId;
            this.TakeManId = user.Id;
            this.TakeManName = user.Name;
            this.TakeMoney = takemoney;
            this.Kind = view.Kind;
            this.Phone = view.Phone;
            this.Portrait = user.Portrait;
            this.TakeTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
    }
    /// <summary>
    /// 红包领取数据提交
    /// </summary>
    public class TakeKickbackInput
    {
        /// <summary>
        /// 对应的红包id
        /// </summary>
        public string KickbackId { get; set; }
        /// <summary>
        /// 红包领取人手机
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 领取类别
        /// </summary>
        public TakeType Kind { get; set; }
    }
    /// <summary>
    /// 红包领取类别
    /// </summary>
    public enum TakeType
    {
        /// <summary>
        /// 好友领取
        /// </summary>
        [Description("好友领取")]
        Friend,
        /// <summary>
        /// 群发领取
        /// </summary>
        [Description("群发领取")]
        Group,
        /// <summary>
        /// 名片用户
        /// </summary>
        [Description("名片用户")]
        Card
    }
   
    /// <summary>
    /// 用户代金券修改
    /// </summary>
    public class IncreaseCouponInputDto
    {
        /// <summary>
        /// 用户id
        /// </summary>
       public int UserId { get; set; }
        /// <summary>
        /// 用户更改
        /// </summary>
       public int Coupon { get; set; }
    }
  }
