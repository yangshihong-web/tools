﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    /// <summary>
    /// 嗨派猫商品
    /// </summary>
    public class HPMGoods : Core, IAggregateRoot
    {
        /// <summary>
        /// GoodId 
        /// </summary>
        [BsonElement("GoodId")]
        public int GoodId { get; set; }
        /// <summary>
        /// 商品名称 
        /// </summary>
        [BsonElement("Name")]
        public string Name { get; set; }
        /// <summary>
        ///  价格 
        /// </summary>
        [BsonElement("Price")]
        public int Price { get; set; }
        /// <summary>
        /// 商户id
        /// </summary>
        [BsonElement("BusinessId")]
        public int BusinessId { get; set; }
        /// <summary>
        /// 用户id
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 折扣价
        /// </summary>
        [BsonElement("DisPrice")]
        public int DisPrice { get; set; }
        /// <summary>
        /// 折扣截止期
        /// </summary>
        [BsonElement("EndTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime EndTime { get; set; }
        public HPMGoods()
        {

        }
        public HPMGoods(int id,string name,int price,int businessid,int uid,int disprice,DateTime time)
        {
            this.GoodId = id;
            this.Name = name;
            this.Price = price;
            this.BusinessId = businessid;
            this.UserId = uid;
            this.DisPrice = disprice;
            this.EndTime = time;
        }
    }
}
