﻿using CatTools.Shares;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Models
{
    //****************************************************************************
    #region 海派猫骑手存储
    /// <summary>
    /// 嗨哌猫骑手仓储
    /// </summary>
    public class Rider : Core, IAggregateRoot
    {
        /// <summary>
        /// 骑手编号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [BsonElement("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [BsonElement("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 掌联用户Id
        /// </summary>
        [BsonElement("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 星级
        /// </summary>
        [BsonElement("JudgeStar")]
        public StarKind JudgeStar { get; set; }
        /// <summary>
        /// 评分
        /// </summary>
        [BsonElement("Score")]
        public double Score { get; set; }
        /// <summary>
        /// 评价人数
        /// </summary>
        [BsonElement("Num")]
        public int Num { get; set; }
        /// <summary>
        /// 意向城市
        /// </summary>
        [BsonElement("City")]
        public string City { get; set; }
        /// <summary>
        /// 意向地点
        /// </summary>
        [BsonElement("Area")]
        public string Area { get; set; }
        /// <summary>
        /// 用户坐标
        /// </summary>
        [BsonElement("UserPoint")]
        public double[] UserPoint { get; set; }
        /// <summary>
        /// 是否审核通过
        /// </summary>
        [BsonElement("IsAccept")]
        public bool IsAccept { get; set; }
        /// <summary>
        /// 邀请商户id
        /// </summary>
        [BsonElement("InViteBusinessID")]
        public int InViteBusinessID { get; set; }
        /// <summary>
        /// 邀请商户派单次数
        /// </summary>
        [BsonElement("InViteBusinessTime")]
        public int InViteBusinessTime { get; set; }
        /// <summary>
        /// 注册时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 骑手构造
        /// </summary>
        public Rider()
        {

        }
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="register"></param>
        /// <param name="riderid"></param>
        /// <param name="uid"></param>
        public Rider(RiderApplyDto register,int riderid,int uid)
        {
            this.ID = riderid;
            this.Name = register.Name;
            this.Phone = register.Phone;
            this.UserId = uid;
            this.InViteBusinessID = register.BusinessID;
            this.JudgeStar= StarKind.FiveStar;                  //默认5星
            this.Score = 5.0;                                  //默认5分
            this.Num = 1;                                 //默认1人
            this.InViteBusinessTime = 0;
            if (register.BusinessID > 0)
            {
                this.IsAccept = true;              //如果有邀请商户，则免平台审核
            }
            else
            {
                this.IsAccept = false;
            }
            this.UserPoint = new double[] {0,0};
            this.City = register.City;
            this.Area = register.Area;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }

        /// <summary>
        /// 获取修改列表
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        #region  获取修改表 UpdateList
        public List<string> UpdateList(RiderModi data)
        {
            var result = new List<string>();
            //姓名
            if (data.Name != null & this.Name != data.Name)
            {
                this.Name = data.Name;
                result.Add("Name");
            }
            //电话
            if (data.Phone != null & this.Phone != data.Phone)
            {
                this.Phone = data.Phone;
                result.Add("Phone");
            }
            //推荐商户未使用免单权，可以修改
            if (this.InViteBusinessTime < 1)
            {
                //邀请商户id
                if (this.InViteBusinessID != data.BusinessID)
                {
                    this.InViteBusinessID = data.BusinessID;
                    result.Add("InViteBusinessID");
                }
            }
            //意向城市
            if (data.City != null & this.City != data.City)
            {
                this.City = data.City;
                result.Add("City");
            }
            //意向地点
            if (data.Area != null & this.Area != data.Area)
            {
                this.Area = data.Area;
                result.Add("Area");
            }
            //有修改，则需要重新审核
            if(result.Count()>0)
            {
                this.IsAccept = false;
                result.Add("IsAccept");
            }
            return result;
        }
        #endregion
    }
    #endregion
    //******************************************************************
    #region 骑手修改数据
    /// <summary>
    /// 骑手修改
    /// </summary>
    public class RiderModi
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [DisplayName("姓名")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [DisplayName("电话")]
        public string Phone { get; set; }
        /// <summary>
        /// 邀请商户id
        /// </summary>
        [DisplayName("邀请商户id")]
        public int BusinessID { get; set; }
        /// <summary>
        /// 意向城市
        /// </summary>
        [DisplayName("意向城市")]
        public string City { get; set; }
        /// <summary>
        /// 意向地点
        /// </summary>
        [DisplayName("意向地点")]
        public string Area { get; set; }
    }
    #endregion
    //******************************************************************
    #region 骑手申请数据
    /// <summary>
    /// 骑手申请提交数据
    /// </summary>
    public class RiderApplyDto
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [DisplayName("姓名")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [DisplayName("电话")]
        public string Phone { get; set; }
        /// <summary>
        /// 意向城市
        /// </summary>
        [DisplayName("意向城市")]
        public string City { get; set; }
        /// <summary>
        /// 意向地点
        /// </summary>
        [DisplayName("意向地点")]
        public string Area { get; set; }
        /// <summary>
        /// 邀请商户id
        /// </summary>
        [DisplayName("邀请商户id")]
        public int BusinessID { get; set; }
    }
    #endregion
    //******************************************************************
    #region 派单状态枚举 DeliveryState
    /// <summary>
    /// 派送单状态
    /// </summary>
    public enum DeliveryState
    {
        /// <summary>
        /// 商家已接订单，待发布派
        /// </summary>
        [Description("待发布")]
        WaitAssigned = 0,
        /// <summary>
        /// 商家已发布派单，待骑手接单
        /// </summary>
        [Description("待接单")]
        WaitRider = 1,
        /// <summary>
        /// 骑手已单，待商家发货
        /// </summary>
        [Description("待发货")]
        Delivered = 2,
        /// <summary>
        /// 已发货，商家已发货
        /// </summary>
        [Description("待送货")]
        Dispatch = 3,
        /// <summary>
        /// 已送达，骑手完工
        /// </summary>
        [Description("已送达")]
        Received = 4,
        /// <summary>
        /// 客户确认收货
        /// </summary>
        [Description("已结算")]
        Account =5
    }
    #endregion
    //******************************************************************
     #region  信息发送方式枚举  MessageSendModel
    /// <summary>
    /// 信息发送方式
    /// </summary>
    public enum MessageSendModel
    {
        /// <summary>
        /// 短信推送
        /// </summary>
        [Description("短信推送")]
        Sms = 0,
        /// <summary>
        /// 极光消息推送
        /// </summary>
        [Description("极光消息推送")]
        Aurora = 1,
        /// <summary>
        /// 微信模板消息
        /// </summary>
        [Description("微信模板消息")]
        WeChat = 2,
        /// <summary>
        /// 微信小程序模板消息
        /// </summary>
        [Description("微信小程序模板消息")]
        WeChatSmall = 3,
    }
    #endregion
    //******************************************************************
    #region  骑手类别枚举  RiderKind
    /// <summary>
    /// 骑手类别
    /// </summary>
    public enum RiderKind
    {
        /// <summary>
        /// 优先骑手
        /// </summary>
        [Description("优先骑手")]
        First = 1,
        /// <summary>
        /// 替补骑手
        /// </summary>
        [Description("替补骑手")]
        Reserve = 2
    }
    #endregion
    //******************************************************************
    #region  商户数据
    /// <summary>
    /// 嗨派猫商户信息
    /// </summary>
    public class BusinessMess
    {
        /// <summary>
        /// 商户编号
        /// </summary>
        [Description("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [Description("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [Description("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 掌联用户Id
        /// </summary>
        [Description("UserId")]
        public int UserId { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        [Description("Address")]
        public string Address { get; set; }
        /// <summary>
        /// 用户坐标
        /// </summary>
        [Description("UserPoint")]
        public double[] UserPoint { get; set; }
    }
    #endregion
    //******************************************************************
    #region 顾客数据
    /// <summary>
    /// 嗨派猫顾客信息
    /// </summary>
    public class CustomerMess
    {
        /// <summary>
        /// 顾客编号
        /// </summary>
        [Description("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [Description("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [Description("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        [Description("Address")]
        public string Address { get; set; }
        /// <summary>
        /// 用户坐标
        /// </summary>
        [Description("UserPoint")]
        public double[] UserPoint { get; set; }
        /// <summary>
        /// 推送方式
        /// </summary>
        [Description("Model")]
        public MessageSendModel Model { get; set; }
    }
    #endregion
    //******************************************************************
    #region 消息推送目标
    /// <summary>
    /// 消息推送目标
    /// </summary>
    public class PushObject
    {
        /// <summary>
        /// 顾客编号
        /// </summary>
        [Description("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [Description("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [Description("Phone")]
        public string Phone { get; set; }
    }
    #endregion
    #region  骑手数据
    /// <summary>
    /// 嗨派猫骑手信息
    /// </summary>
    public class RiderMess
    {
        /// <summary>
        /// 骑手编号
        /// </summary>
        [Description("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [Description("Name")]
        public string Name { get; set; }
        /// <summary>
        /// 电话
        /// </summary>
        [Description("Phone")]
        public string Phone { get; set; }
        /// <summary>
        /// 掌联用户Id
        /// </summary>
        [Description("UserId")]
        public int UserId { get; set; }
     }
    #endregion
    //******************************************************************
    #region 商品数据
    /// <summary>
    /// 嗨派猫商品信息
    /// </summary>
    public class GoodsMess
    {
        /// <summary>
        /// 商品名称 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 价格 
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        ///  图片 
        /// </summary>
        public string Picture { get; set; }
        /// <summary>
        /// 数量 
        /// </summary>
        public int Count { get; set; } 
    }
    #endregion
    //******************************************************************
    #region 消息数据
    /// <summary>
    /// 消息发送结构
    /// </summary>
    public class MessSend
    {
        /// <summary>
        /// 消息id 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 发送方式
        /// </summary>
        public MessageSendModel MessModel { get; set; }
        /// <summary>
        ///  发送时间 
        /// </summary>
        public string SendTime { get; set; }
 
    }
    #endregion
    //*****************派送单存储***************************************
    #region 派送单存储
    /// <summary>
    /// 派送单
    /// </summary>
    public class Delivery : Core, IAggregateRoot
    {
        /// <summary>
        ///编号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        ///订单Id
        /// </summary>
        [BsonElement("OrderId")]
        public int OrderId { get; set; }
        /// <summary>
        ///订单编号
        /// </summary>
        [BsonElement("OrderCode")]
        public string OrderCode { get; set; }
        /// <summary>
        /// 商家信息
        /// </summary>
        [BsonElement("Business")]
        public BusinessMess Business { get; set; }
        /// <summary>
        /// 顾客信息
        /// </summary>
        [BsonElement("Customer")]
        public CustomerMess Customer { get; set; }
        /// <summary>
        /// 骑手信息
        /// </summary>
        [BsonElement("Rider")]
        public RiderMess Rider { get; set; }
        /// <summary>
        /// 商品信息
        /// </summary>
        [BsonElement("Goods")]
        public GoodsMess[] Goods { get; set; }
        /// <summary>
        /// 配送要求
        /// </summary>
        [BsonElement("Demand")]
        public string Demand { get; set; }
        /// <summary>
        /// 费用
        /// </summary>
        [BsonElement("Cost")]
        public int Cost { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        [BsonElement("State")]
        public DeliveryState State { get; set; }
        /// <summary>
        /// 商家接单时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 商家发布时间
        /// </summary>
        [BsonElement("PushTime")]
        public string PushTime { get; set; }
        /// <summary>
        /// 顾客要求送达时间
        /// </summary>
        [BsonElement("NeedDeliveredTime")]
        public string NeedDeliveredTime { get; set; }
        /// <summary>
        /// 骑手接单时间
        /// </summary>
        [BsonElement("RiderAccetpTime")]
        public string RiderAccetpTime { get; set; }
        /// <summary>
        /// 商家发货时间
        /// </summary>
        [BsonElement("ShipMentTime")]
        public string ShipMentTime { get; set; }
        /// <summary>
        /// 货物送达时间
        /// </summary>
        [BsonElement("AccetpGoodsTime")]
        public string AccetpGoodsTime { get; set; }
        /// <summary>
        /// 结算时间
        /// </summary>
        [BsonElement("AccountTime")]
        public string AccountTime { get; set; }
        /// <summary>
        /// 评价
        /// </summary>
        [BsonElement("Evaluate")]
        public EvaluateContent Evaluate { get; set; }
        /// <summary>
        /// 是否减免单
        /// </summary>
        [BsonElement("IsReduce")]
        public bool IsReduce { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public Delivery()
        {

        }
        /// <summary>
        /// 构造带参数
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        public Delivery(int id,DeliveryInput input)
        {
            this.ID = id;
            this.OrderId = input.OrderId;
            this.OrderCode = input.OrderCode;
            this.Customer = input.Customer;
            this.Business = input.Business;
            this.Goods = input.Goods;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.State = DeliveryState.WaitAssigned;
            this.AccetpGoodsTime = "";
            this.AccountTime = "";
            this.NeedDeliveredTime = "";
            this.PushTime = "";
            this.RiderAccetpTime = "";
            this.ShipMentTime = "";
            this.IsReduce = false;
            //由平台设定的标准计算
            this.Cost = input.Cost;
            this.Demand = "无要求";
            this.NeedDeliveredTime = "当日送达";
        }
        /// <summary>
        /// 要求提交
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public List<string> PushInput(DeliveryPushDin data)
        {
            var result = new List<string>();
            //要求
            if (data.Demand != null && this.Demand != data.Demand)
            {
                this.Demand = data.Demand;
                result.Add("Demand");
            }
            //送达时间
            if (data.NeedDeliveredTime != null&& this.NeedDeliveredTime != data.NeedDeliveredTime)
            {
                this.NeedDeliveredTime = data.NeedDeliveredTime;
                result.Add("NeedDeliveredTime");
            }
            this.PushTime = DateTime.Now.ToString();
            result.Add("PushTime");
            return result;
        }
    }
    #endregion
    //******************************************************************
    #region  骑手接单显示
    /// <summary>
    /// 骑手接单显示对象
    /// </summary>
    public class RiderDelivery
    {
        /// <summary>
        ///编号
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        ///订单Id
        /// </summary>
        public int OrderId { get; set; }
        /// <summary>
        ///订单编号
        /// </summary>
        public string OrderCode { get; set; }
        /// <summary>
        /// 商家信息
        /// </summary>
        public BusinessMess Business { get; set; }
        /// <summary>
        /// 顾客信息
        /// </summary>
        public CustomerMess Customer { get; set; }
        /// <summary>
        /// 商品信息
        /// </summary>
        public GoodsMess[] Goods { get; set; }
        /// <summary>
        /// 配送要求
        /// </summary>
        public string Demand { get; set; }
        /// <summary>
        /// 费用
        /// </summary>
        public int Cost { get; set; }
        /// <summary>
        /// 商家发布时间
        /// </summary>
        public string PushTime { get; set; }
        /// <summary>
        /// 顾客要求送达时间
        /// </summary>
        public string NeedDeliveredTime { get; set; }
        /// <summary>
        /// 距离店家
        /// </summary>
        public int ToShopDistance { get; set; }
        /// <summary>
        /// 总距离
        /// </summary>
        public int TotalDistance { get; set; }
        /// <summary>
        /// 距离店家时间
        /// </summary>
        public int ToShopTime { get; set; }
        /// <summary>
        /// 总时间
        /// </summary>
        public int TotalTime { get; set; }
    }
    #endregion
    //******************************************************************
    #region  骑手抢单定位数据 
    /// <summary>
    /// 骑手抢单定位数据 
    /// </summary>
    public class RiderPoint
    {
        /// <summary>
        ///订单Id
        /// </summary>
        [DisplayName("订单Id")]
        public int OrderId { get; set; }
        /// <summary>
        /// 距离骑手位置
        /// </summary>
        [DisplayName("距离店家位置")]
        public int ToShopDistance { get; set; }
        /// <summary>
        /// 距离骑手时间
        /// </summary>
        [DisplayName("距离店家时间")]
        public int ToShopTime { get; set; }
        /// <summary>
        /// 总距离
        /// </summary>
        [DisplayName("总距离")]
        public int TotalDistance { get; set; }
        /// <summary>
        /// 总时间
        /// </summary>
        [DisplayName("总时间")]
        public int TotalTime { get; set; }
        /// <summary>
        /// 骑手坐标
        /// </summary>
        [DisplayName("骑手坐标")]
        public double[] Point { get; set; }
    }
    #endregion
    //******************************************************************
    #region 骑手评价类
    /// <summary>
    /// 评价
    /// </summary>
    public class EvaluateContent
    {
        /// <summary>
        /// 服务星级
        /// </summary>
        public StarKind Service { get; set; }
        /// <summary>
        /// 速递星级
        /// </summary>
        public StarKind Speed { get; set; }
        /// <summary>
        /// 综合星级
        /// </summary>
        public StarKind Colligate { get; set; }
        /// <summary>
        /// 速递快
        /// </summary>
        public bool SeedFast { get; set; }
        /// <summary>
        /// 态度好
        /// </summary>
        public bool Attitude { get; set; }
        /// <summary>
        /// 负责
        /// </summary>
        public bool Responsible { get; set; }
        /// <summary>
        /// 耐心
        /// </summary>
        public bool Patient { get; set; }
        /// <summary>
        /// 热情
        /// </summary>
        public bool Enthusiasm { get; set; }
        /// <summary>
        /// 评价
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        /// 获取分数，每项1分
        /// </summary>
        /// <returns></returns>
        public int GetScore()
        {
            int result = 0;
            if(this.SeedFast)
            {
                result++;
            }
            if (this.Attitude)
            {
                result++;
            }
            if (this.Responsible)
            {
                result++;
            }
            if (this.Patient)
            {
                result++;
            }
            if (this.Enthusiasm)
            {
                result++;
            }
            return result;
        }
    }
    #endregion
    //******************************************************************
    #region  星级分类枚举  StarKind
    /// <summary>
    ///星级类别
    /// </summary>
    public enum StarKind
    {
        /// <summary>
        /// 默认
        /// </summary>
        [Description("默认")]
        Default = 0,
        /// <summary>
        /// 一星
        /// </summary>
        [Description("一星")]
        OneStar = 1,
        /// <summary>
        /// 二星
        /// </summary>
        [Description("二星")]
        TwoStar = 2,
        /// <summary>
        /// 三星
        /// </summary>
        [Description("三星")]
        ThreeStar = 3,
        /// <summary>
        /// 四星
        /// </summary>
        [Description("四星")]
        FourStar= 4,
        /// <summary>
        /// 五星
        /// </summary>
        [Description("五星")]
        FiveStar = 5
    }
    #endregion
    //******************************************************************
    #region 派单输入数据
    /// <summary>
    /// 派送单输入
    /// </summary>
    public class DeliveryInput
    {
        /// <summary>
        ///订单Id
        /// </summary>
        [DisplayName("订单Id")]
        public int OrderId { get; set; }
        /// <summary>
        ///订单编号
        /// </summary>
        [DisplayName("订单编号")]
        public string OrderCode { get; set; }
        /// <summary>
        /// 商家信息
        /// </summary>
        [DisplayName("商家信息")]
        public BusinessMess Business { get; set; }
        /// <summary>
        /// 顾客信息
        /// </summary>
        [DisplayName("顾客信息")]
        public CustomerMess Customer { get; set; }
        /// <summary>
        /// 商品信息
        /// </summary>
        [DisplayName("商品信息")]
        public GoodsMess[] Goods { get; set; }
        /// <summary>
        /// 服务费用
        /// </summary>
        [DisplayName("服务费用")]
        public int Cost { get; set; }
    }
    #endregion
    //******************************************************************
    #region 派单发布输入数据
    /// <summary>
    /// 派单发布数据输入
    /// </summary>
    public class DeliveryPushDin
    {
        /// <summary>
        ///订单Id
        /// </summary>
        [DisplayName("订单Id")]
        public int OrderId { get; set; }
        /// <summary>
        /// 配送要求
        /// </summary>
        [DisplayName("配送要求")]
        public string Demand { get; set; }
        /// <summary>
        /// 顾客要求送达时间
        /// </summary>
        [DisplayName("顾客要求送达时间")]
        public string NeedDeliveredTime { get; set; }
    }
    #endregion
    //******************************************************************
    #region 账单明细存储
    /// <summary>
    /// 派单服务账单明细
    /// </summary>
    public class AccountDetail : Core, IAggregateRoot
    {
        /// <summary>
        ///编号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 派单id
        /// </summary>
        [BsonElement("DeliveryID")]
        public int DeliveryID { get; set; }
        /// <summary>
        /// 说明
        /// </summary>
        [BsonElement("Body")]
        public string Body { get; set; }
        /// <summary>
        /// 用户Id
        /// </summary>
        [BsonElement("Uid")]
        public int Uid { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [BsonElement("Money")]
        public int Money { get; set; }
        /// <summary>
        /// 记账时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public AccountDetail()
        {

        }
        /// <summary>
        /// 构造带参数
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body"></param>
        /// <param name="uid"></param>
        /// <param name="monry"></param>
        /// <param name="deliveryid"></param>
        public AccountDetail(int id, string body, int uid, int monry,int deliveryid)
        {
            this.ID = id;
            this.Body = body;
            this.Uid = uid;
            this.Money = monry;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.DeliveryID = deliveryid;
        }
    }
    #endregion
    //******************************************************************
    #region 信息存储存储
    /// <summary>
    /// 信息保存
    /// </summary>
    public class Message : Core, IAggregateRoot
    {
        /// <summary>
        /// 内容
        /// </summary>
        [BsonElement("Content")]
        public string Content { get; set; }
        /// <summary>
        /// 发送人id
        /// </summary>
        [BsonElement("SendUid")]
        public int SendUid { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [BsonElement("OrderId")]
        public int OrderId { get; set; }
        /// <summary>
        /// 推送方式
        /// </summary>
        [BsonElement("Model")]
        public MessageSendModel Model { get; set; }
        /// <summary>
        /// 目标用户信息
        /// </summary>
        [BsonElement("TargetMess")]
        public PushObject TargetMess { get; set; }
        /// <summary>
        /// 是否推送
        /// </summary>
        [BsonElement("Push")]
        public bool Push { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 推送对象Seller,Buyer
        /// </summary>
        [BsonElement("Target")]
        public string Target { get; set; }
        /// <summary>
        ///订单类
        /// </summary>
        [BsonElement("OrderType")]
        public EnumMessageOrderType OrderType { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public Message()
        {

        }
        /// <summary>
        /// 构造带参数
        /// </summary>
        /// <param name="input"></param>
        public Message(MessageInput input)
        {
            this.Content = input.Content;
            this.SendUid = input.SendUid;
            this.OrderId = input.OrderId;
            this.Model = input.Model;
            this.TargetMess = input.TargetMess;
            this.CreateTime =  DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
            this.OrderType = input.OrderType;
            this.Target = input.Target;
            this.Push = input.Push;
        }
    }
    #endregion
    //******************************************************************
    #region  信息输入数据
    /// <summary>
    /// 信息输入
    /// </summary>
    public class MessageInput
    {
        /// <summary>
        /// 内容
        /// </summary>
        [DisplayName("内容")]
        public string Content { get; set; }
        /// <summary>
        /// 发送人id
        /// </summary>
        [DisplayName("发送人id")]
        public int SendUid { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [DisplayName("订单编号")]
        public int OrderId { get; set; }
        /// <summary>
        /// 推送方式
        /// </summary>
        [DisplayName("推送方式")]
        public MessageSendModel Model { get; set; }
        /// <summary>
        /// 目标用户信息
        /// </summary>
        [DisplayName("目标用户信息")]
        public PushObject TargetMess { get; set; }
        /// <summary>
        /// 推送对象Seller,Buyer
        /// </summary>
        [DisplayName("推送对象")]
        public string Target { get; set; }
        /// <summary>
        ///订单类
        /// </summary>
        [DisplayName("订单类")]
        public EnumMessageOrderType OrderType { get; set; }
        /// <summary>
        /// 是否推送
        /// </summary>
        [DisplayName("是否推送")]
        public bool Push { get; set; }
    }
    #endregion
    #region  通知缓存
    /// <summary>
    /// 通知缓存
    /// </summary>
    public class NoticCache : Core, IAggregateRoot
    {
        /// <summary>
        /// 内容
        /// </summary>
        [BsonElement("Content")]
        public DeliveryNoticeDto Content { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        public NoticCache()
        {

        }
        public NoticCache(DeliveryNoticeDto content)
        {
            this.Content = content;
            this.CreateTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
        }
    }
    #endregion
    #region  推送消息的订单类型枚举  EnumMessageOrderType
    /// <summary>
    ///推送消息的订单类型枚举
    /// </summary>
    public enum EnumMessageOrderType:int
    {
        /// <summary>
        /// 未知
        /// </summary>
        [Description("")]
        Noknow = 0,
        /// <summary>
        /// 商城
        /// </summary>
        [Description("商城")]
        Mall = 1,
        /// <summary>
        /// 团购
        /// </summary>
        [Description("团购")]
        Groupon = 2,
        /// <summary>
        /// 外卖
        /// </summary>
        [Description("外卖")]
        Takeout = 3
    }
    #endregion
    //******************************************************************
    #region 序号保存存储
    /// <summary>
    /// 序号保存
    /// </summary>
    public class Recno : Core, IAggregateRoot
    {
        /// <summary>
        /// 类别序号
        /// </summary>
        [BsonElement("ID")]
        public int ID { get; set; }
        /// <summary>
        /// 保存的序号
        /// </summary>
        [BsonElement("Number")]
        public int Number { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public Recno()
        {

        }
        /// <summary>
        /// 构造，带参数
        /// </summary>
        /// <param name="id">类别</param>
        public Recno(int id)
        {
            this.ID = id;
            this.Number = 1;
        }
    }
    #endregion
    //******************************************************************
    #region  坐标数据
    /// <summary>
    /// 坐标数据
    /// </summary>
    public class Point
    {
        /// <summary>
        /// 经度
        /// </summary>
        public double Longti { get; set; }
        /// <summary>
        /// 纬度
        /// </summary>
        public double Lati { get; set; }
    }
    #endregion
}