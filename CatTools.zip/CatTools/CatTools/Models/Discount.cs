﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;


namespace CatTools.Models
{
    /// <summary>
    /// 联盟商家
    /// </summary>
    public class AllianceBusiness : Core, IAggregateRoot
    {
        /// <summary>
        /// 商户id
        /// </summary>
        public int ShopId { get; set; }
        /// <summary>
        /// 商户名
        /// </summary>
        public string ShopName { get; set; }
        /// <summary>
        /// 商品列表,无指定商品，未该商户的全部商品
        /// </summary>
        public IList<int> Goods { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        public AllianceBusiness()
        {

        }
        public AllianceBusiness(int shopid,string name,IList<int> goods)
        {
            this.ShopId = shopid;
            this.ShopName = name;
            this.Goods = goods;
            this.CreateTime = DateTime.Now;
        }
    }
    /// <summary>
    /// 联盟金卡
    /// </summary>
    public class AllianceCard : Core, IAggregateRoot
    {
        /// <summary>
        /// 用户id
        /// </summary>
        public int Uid { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 无参数构造
        /// </summary>
        public AllianceCard()
        {

        }
        /// <summary>
        /// 有参数构造
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="name"></param>
        public AllianceCard(int uid,string name)
        {
            this.Uid = uid;
            this.UserName = name;
            this.Money = 0;
            this.CreateTime = DateTime.Now; 
        }
    }
    #region 金卡类别枚举 CardKind
    /// <summary>
    /// 金卡类别
    /// </summary>
    public enum CardKind
    {
        /// <summary>
        /// 200元
        /// </summary>
        [Description("200元")]
        M200 = 0,
        /// <summary>
        /// 300元
        /// </summary>
        [Description("300元")]
        M300 = 1,
        /// <summary>
        /// 400元
        /// </summary>
        [Description("400元")]
        M400 = 2
    }
    #endregion
    /// <summary>
    /// 金卡使用
    /// </summary>
    public class CardUse : Core, IAggregateRoot
    {
        /// <summary>
        /// 用户id
        /// </summary>
        public int Uid { get; set; }
        /// <summary>
        /// 联盟金卡Id
        /// </summary>
        public string CardId { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public CardUse()
        {

        }
        /// <summary>
        /// 构造，带参数
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="cardid"></param>
        /// <param name="money"></param>
        public CardUse(int uid,string cardid,int money)
        {
            this.Uid = uid;
            this.CardId = cardid;
            this.Money = money;
            this.CreateTime = DateTime.Now;
        }
    }
    /// <summary>
    /// 金卡充值
    /// </summary>
    public class CardRecharge: Core, IAggregateRoot
    {
        /// <summary>
        /// 用户id
        /// </summary>
        public int Uid { get; set; }
        /// <summary>
        /// 联盟金卡Id
        /// </summary>
        public string CardId { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Money { get; set; }
        /// <summary>
        /// 费用
        /// </summary>
        public int Cost { get; set; }
        /// <summary>
        /// 是否支付
        /// </summary>
        public bool IsPay { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        [BsonElement("CreateTime")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public CardRecharge()
        {

        }
        /// <summary>
        /// 构造，带参数
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="cardid"></param>
        /// <param name="money"></param>
        /// <param name="cost"></param>
        public CardRecharge(int uid,string cardid, int money,int cost)
        {
            this.Uid = uid;
            this.CardId = cardid;
            this.Money = money;
            this.Cost = cost;
            this.IsPay = false;
            this.CreateTime = DateTime.Now;
        }
    }
   
 }
