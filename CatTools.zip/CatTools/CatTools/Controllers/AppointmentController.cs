﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 预约控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentService service;
        private readonly IClientService client;
        private readonly IUserService userservice;
        /// <summary>
        /// 预约控制器
        /// </summary>
        public AppointmentController(IAppointmentService _service, IClientService _client, IUserService _userservice)
        {
            //Thread thread = new Thread(TConsoleWrite);//记得要在new 创建的时候带上需要执行的方法名
            //thread.IsBackground = true;//这个是把我们这个线程放到后台线程里面执行
            //thread.Start();//Start就代表开始执行线程

            this.service = _service;
            this.client = _client;
            this.userservice = _userservice;
        }
        /// <summary>
        /// 添加模板，商户管理端
        /// </summary>
        /// <param name="shopid">门店id</param>
        /// <param name="explain">模板说明</param>
        [ProducesResponseType(typeof(JsonReturn<AappointmentModel>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> AddModel(int shopid, AappointmentExplain explain)
        {
            //获取门店信息
            var shopweb = client.GetBusiness(shopid);
            //判断门店是否有效
            var shop = new Shop() {  ShopId=shopid, ShopName=shopweb.Name, ShopAddress=shopweb.Address, ShopPhone=shopweb.Phone};
            //调用添加模板服务
            var result=await service.AddModel(shop, explain);
            //返回结果
            return new JsonReturn<AappointmentModel>(result,1, "添加模板成功");
        }
        /// <summary>
        /// 删除模板，商户管理端
        /// </summary>
        /// <param name="id">模板id</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpDelete("{id}")]
        public async Task<JsonReturn> DeleteModel(string id)
        {
            //调用删除模板服务
            var result=await service.DeleteModel(id);
            //返回结果
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "删除模板成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "删除模板失败");
            }
        }
        /// <summary>
        /// 获取模板，商户管理端
        /// </summary>
        /// <param name="id">模板id</param>
        [ProducesResponseType(typeof(JsonReturn<AappointmentModel>), StatusCodes.Status200OK)]
        [HttpGet("{id}")]
        public JsonReturn GetModel(string id)
        {
            //调用获取模板服务
            var result = service.GetModel(id);
            //返回结果
            return new JsonReturn<AappointmentModel>(result,1, "返回模板信息");
        }
        /// <summary>
        /// 获取模板列表，商户管理端
        /// </summary>
        /// <param name="uid">嗨派猫商户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">页记录</param>
        [ProducesResponseType(typeof(JsonReturn<List<AappointmentModel>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetModels(int uid, int PageIndex = 1, int PageSize = 15)
        {
            //调用获取模板列表服务
            var result = service.GetModels(uid, PageIndex, PageSize);
            //返回结果
            if(result.status=="OK")
            {
                return result;
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现模板列表");
            }
        }
        /// <summary>
        /// 添加模板时段，商户管理端
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="name">时间段名</param>
        /// <param name="num">设置数量</param>
        [ProducesResponseType(typeof(JsonReturn<AappointmentModel>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> AddTimes(string id, string name,int num)
        {
            //生成新的时段信息
            var time = new Times() {  Name=name, SetNum=num};
            //调用添加模板时段服务，保存新的时段信息
            var result = await service.AddTimes(id,time);
            //返回结果
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "添加模板时段成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "添加模板时段失败");
            }
 
            
        }
        /// <summary>
        /// 修改模板时段，商户管理端
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="name">时间段名</param>
        /// <param name="timeid">时段id</param>
        /// <param name="num">设置数量</param>
        [ProducesResponseType(typeof(JsonReturn<AappointmentModel>), StatusCodes.Status200OK)]
        [HttpPut]
        public async Task<JsonReturn> UpdateTimes(string id, string timeid,string name, int num)
        {
            //按id，timeid查询时段信息
            var time = new Times() { Id=timeid, Name = name, SetNum = num };
            //更新时段信息
            var result=await service.UpdateTimes(id, time);
            //返回结果
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "修改模板时段成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "修改模板时段失败");
            }
        }
        /// <summary>
        /// 修改休息日
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="resttime">休息日0,1，2，3，4，5，6，分别表示星期（日-六）休息，默认全部工作</param>
        /// <returns></returns>
        [ProducesResponseType(typeof(JsonReturn<AappointmentModel>), StatusCodes.Status200OK)]
        [HttpPut]
        public async Task<JsonReturn> UpdateModel(string id,int[] resttime)
        {
            var model = service.GetModel(id);
            if(model==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无发现该模板");
            }
            model.RestDate = resttime;
            //更新信息
            var result = await service.UpdateModel(model);
            //返回结果
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "修改模板休息日成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "修改模板休息日失败");
            }
        }
        /// <summary>
        /// 删除模板时段，商户管理端
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="timeid">时段id</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpDelete]
        public async Task<JsonReturn> DeleteTimes(string id,string timeid)
        {
            //
            var result = await service.DeleteTimes(id, timeid);
            //
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "删除模板时段成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "删除模板时段失败");
            }
        }
        /// <summary>
        /// 获取预约表，商户管理端
        /// </summary>
        /// <param name="modelid">模板id</param>
        /// <param name="date">日期</param>
        [ProducesResponseType(typeof(JsonReturn<AppointmentTable>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetTable(string modelid, string date)
        {
            //
            var result = service.GetTable(modelid, date);
            if (result.Result == "New"|| result.Result == "Exist")
            {
                return new JsonReturn<AppointmentTable>(result, 1, "返回预约表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail,result.Result);
            }
        }
        /// <summary>
        /// 履行预约，商户管理端
        /// </summary>
        /// <param name="id">预约id</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpPost("{id}")]
        public async Task<JsonReturn> FulfillAppointment(string id)
        {
            //
            var result = await service.FulfillAppointment(id);
            //
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "预约履行成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "预约履行失败");
            }
        }
        /// <summary>
        /// 获取预约订单列表，商户管理端
        /// </summary>
        /// <param name="shopid">商户id，默认查看全部</param>
        /// <param name="date">日期(yyyy-MM-dd)，空值查看全部</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        [ProducesResponseType(typeof(JsonReturn<List<AppointmentOrder>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetAppointments(int shopid, string date,int PageIndex = 1, int PageSize = 15)
        {
            //
            var result = service.GetAppointments(shopid, date, PageIndex, PageSize);
            //
            return result;
        }
        /// <summary>
        /// 预约登记，客户端
        /// </summary>
        /// <param name="modelid">模板id</param>
        /// <param name="date">日期</param>
        /// <param name="timeid">时段id</param>
        /// <param name="num">人数</param>
        /// <param name="money">金额</param>
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<AppointmentOrder>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> AddAppointment(string modelid, string date, string timeid, int num, int money)
        {
            //获取模板
            var model = service.GetModel(modelid);
            if (model == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现该模板{modelid}");
            var table = service.GetTable(modelid, date);
            if(table.Result == "New")
            {
                //添加新表
                table = await service.CreateNewTable(model, date);
            }
            else if(table.Result!="Exist")
            {
                //不存在，返回原因
                return new JsonReturn(EnumJsonReturnStatus.Fail, table.Result);
            }
            //获取用户信息
            var uid = int.Parse(Request.HttpContext.Items["Uid"].ToString());
            var temp = userservice.GetDetailed(uid);
            if (temp == null)
            {
                temp = new User();
            }
            var user = new AappointmentMan() { Name = temp.Name, Phone = temp.Phone, Userid = uid };
            //调用登记服务
            var result = await service.AddAppointment(table, timeid, num, money, user);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "预约失败");
            }
            else
            {
                return new JsonReturn<AppointmentOrder>(result, 1, "预约成功");
            }
        }
        /// <summary>
        /// 终止预约，客户端
        /// </summary>
        /// <param name="id">预约id</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpPost("{id}")]
        public async Task<JsonReturn> CancelAppointment(string id)
        {
            //
            var result = await service.CancelAppointment(id);

            //
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "终止预约成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "终止预约失败");
            }

        }
        /// <summary>
        /// 获取预约订单明细，客户端
        /// </summary>
        /// <param name="id">预约id</param>
        [ProducesResponseType(typeof(JsonReturn<AppointmentOrder>), StatusCodes.Status200OK)]
        [HttpGet("{id}")]
        public JsonReturn GetAppointment(string id)
        {
            //
            var result = service.GetAppointment(id);
            //
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该订单信息");
            }
            else
            {
                return new JsonReturn<AppointmentOrder>(result, 1, "返回预约订单");
            }
        }
        /// <summary>
        /// 获取预约订单列表，客户端
        /// </summary>
        /// <param name="uid">客户id</param>
        /// <param name="date">日期(yyyy-MM-dd)，空值查看全部</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        [ProducesResponseType(typeof(JsonReturn<List<AppointmentOrder>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetAppointmentsByClient(int uid, string date, int PageIndex = 1, int PageSize = 15)
        {
            //
            var result = service.GetAppointmentsByClient(uid, date, PageIndex, PageSize);
            //
            return result;
        }
        private string Get()
        {
            var info = string.Format("api执行线程:{0}", Thread.CurrentThread.ManagedThreadId);
            var infoTask = TaskCaller().Result;//使用Result

            var infoTaskFinished = string.Format("api执行线程（task调用完成后）:{0}", Thread.CurrentThread.ManagedThreadId);
            return string.Format("{0},{1},{2}", info, infoTask, infoTaskFinished);
        }

        private async Task<string> TaskCaller()
        {
            await Task.Delay(500);
            return string.Format("task 执行线程:{0}", Thread.CurrentThread.ManagedThreadId);
        }
    }
}