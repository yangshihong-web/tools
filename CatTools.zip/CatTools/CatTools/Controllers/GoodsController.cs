﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 礼品控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class GoodsController : ControllerBase
    {
        private readonly IGoodsService service;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="_service">礼品服务</param>
        public GoodsController(IGoodsService _service)
        {
            this.service = _service;
        }
        #region 添加
        /// <summary>
        /// 礼品发放，用户在商城下单后，调用该接口，保存订单信息，准备发放礼品
        /// </summary>
        /// <param name="input">新的礼品</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<GoodsOrders>),StatusCodes.Status200OK)]
        public async Task<JsonReturn> NewGoods(GoodsOrdersInput input)
        {
            var result = await service.Distribute(input);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "数据提交失败");
            }
            //返回结果
            return new JsonReturn<GoodsOrders>(result);
        }
        #endregion
        /// <summary>
        /// 礼品终止，用户终止礼品的继续发放
        /// </summary>
        /// <param name="id">订单Id</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Cancel(int id)
        {
            if (id == 0) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var Goods = service.GetOrderDetailed(id);

            if (Goods == null||!Goods.IsValid)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的礼品或者已终止");
            }
            //终止
            var temp = await service.Cancel(id);
            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "终止不成功");
            }
        }
        /// <summary>
        /// 礼品发放标记，商家发送货后，在通知单上标记货物已发
        /// </summary>
        /// <param name="id">领取单号</param>
        /// <returns>标记礼品发放信息</returns>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> SendMark(string id)
        {
            if (id == null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var temp = await service.SendGoods(id);

            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "标记不成功");
            }
        }
        /// <summary>
        /// 礼品领取，客户领取发送人发送的信息，并接受领取时，调用该接口，保存领取信息，生成发货通知信息
        /// </summary>
        /// <param name="input">输入领取信息</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        /// <response code="404">返回失败信息</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<GoodsTakeOrders>),StatusCodes.Status200OK)]
        public async Task<JsonReturn> GoodsTake(GoodsTakeOrdersInput input)
        {
            var temp=await service.TakeGoods(input);
           
            if (temp == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该礼包已经过期，无法领取");
            }
            //返回结果
            return  new JsonReturn<GoodsTakeOrders>(temp);
        }
        /// <summary>
        /// 获取指定订单的礼品包明细，查看礼品订单的明细信息
        /// </summary>
        /// <param name="id">礼品订单ID</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<GoodsOrders>),StatusCodes.Status200OK)]
        public JsonReturn Getid(int id)
        {
            //查询记录
            var result = service.GetOrderDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的礼品包");

            //返回结果
            return  new JsonReturn<GoodsOrders>(result);
        }
        /// <summary>
        /// 获取指定领取单的明细，查看单个通知的明细
        /// </summary>
        /// <param name="id">礼品领取ID</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<GoodsTakeOrders>),StatusCodes.Status200OK)]
        public JsonReturn GetTakeById(string id)
        {
            //查询记录
            var result = service.GetTakeDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的领取明细");

            //返回结果
            return new JsonReturn<GoodsTakeOrders>(result);
        }
        /// <summary>
        /// 获取指定发放用户的发放礼品单列表(分页)，历史记录
        /// </summary>
        /// <param name="uid">指定发放人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="isvlid">true仅查看可以领取的礼品信息</param>
        /// <response code="200">返回提交的礼品申请信息或者失败信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<GoodsOrders>>),StatusCodes.Status200OK)]
        public JsonReturn GetList(int uid=0,int PageIndex = 1, int PageSize = 15,bool isvlid=true)
        {
            int total = 0;
            var result= service.GetList(out total,uid,PageIndex, PageSize,isvlid);
            if(result!=null)
            {
                return new JsonReturn<List<GoodsOrders>>(result, total,"返回礼品列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        /// <summary>
        /// 获取指定订单的领取列表（按订单号查看发货通知单）
        /// </summary>
        /// <param name="id">订单id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="IsSend">true仅查看未发货通知单</param>
        /// <response code="200">返回提交的礼品申请信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<GoodsTakeOrders>>),StatusCodes.Status200OK)]
        public JsonReturn GetTakeList(int id, int PageIndex = 1, int PageSize = 15,bool IsSend=true)
        {
            if(id==0)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "红包id要求输入");
            }
            int total = 0;
            var result = service.GetTakeList(out total, id, PageIndex, PageSize,IsSend);
            if (result != null)
            {
                return new JsonReturn<List<GoodsTakeOrders>> (result, total, "返回领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        /// <summary>
        /// 获取指定领取人的领取列表（按发送人查看通知单）
        /// </summary>
        /// <param name="uid">领取人</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <response code="200">返回提交的礼品申请信息或者空表</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<GoodsTakeOrders>>),StatusCodes.Status200OK)]
        public JsonReturn GetTakeListByUid(int uid=0, int PageIndex = 1, int PageSize = 15)
        {

            int total = 0;
            var result = service.GetTakeListByUid(out total, uid, PageIndex, PageSize);
            if (result != null)
            {
                return new JsonReturn<List<GoodsTakeOrders>>(result, total, "返回领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
    }
}