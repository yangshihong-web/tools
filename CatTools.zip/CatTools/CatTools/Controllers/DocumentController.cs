﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Services;
using CatTools.Shares;
using log4net;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CatTools.Controllers
{
    /// <summary>
    /// 核销控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        private HttpClient httpclient;
        /// <summary>
        /// 
        /// </summary>
        public DocumentController()
        {
            httpclient = new HttpClient();
        }
        /// <summary>
        /// 线上核销通用接口，由后台调用
        /// </summary>
        /// <param name="into">核销数据</param>
        /// <response code="200">返回核销结果</response>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<int>), StatusCodes.Status200OK)]
        public JsonReturn WriteOff(WriteOffDataInto into)
        {
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "后台核销调用接口>>");
            log.Info("开始调用：" + "核销单据id：" + into.Id+"，核销类别："+into.Type.ToString()+"，核销金额："+into.Money+"，核销用户："+into.Uid+"核销商品"+into.Goodsid);
            string url = "";
            switch (into.Type)
            {
                case WriteOffType.ToolsPurchase:
                    url = $"http://xydev.yczlsq.com/API/Activity/WriteOffPurchase?id={into.Id}&uid={into.Uid}&goodsid={into.Goodsid}";
                    break;
                case WriteOffType.ToolsTake:
                    url = $"http://xydev.yczlsq.com/API/Activity/WriteOffTake?id={into.Id}&uid={into.Uid}&goodsid={into.Goodsid}";
                    break;
                case WriteOffType.Discount:
                    url = $"http://xydev.yczlsq.com/API/Discount/CardUse?cardid={into.Id}&money={into.Money}&uid={into.Uid}&goodsid={into.Goodsid}";
                    break;
                case WriteOffType.Elect:
                    url = $"http://xydev.yczlsq.com/API/ElectronicVouchers/Use?id={into.Id}&money={into.Money}&uid={into.Uid}&goodsid={into.Goodsid}";
                    break;
                case WriteOffType.Coupons:
                    url = $"http://xydev.yczlsq.com/API/MarketingCoupons/Use?id={into.Id}&goodsid={into.Goodsid}";
                    break;
                default:
                    return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "无效的类型输入！");
                    //break;
            }
            var taskresponse = httpclient.GetAsync(url);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                var json = JsonConvert.DeserializeObject<ReturnInt>(result);
                log.Info("返回结果：" + json.Status);
                if (json.Status == EnumJsonReturnStatus.OK)
                {
                    return json.Data;
                }
                else
                {
                    return new JsonReturn(json.Status, json.Message);
                }
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "核销失败！");
            }
            
        }
    }
}