﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CatTools.Controllers
{
    /// <summary>
    /// 活动控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        private readonly IActivityService service;
        private readonly IClientService client;
        private readonly IUserService userservice;
        private readonly IHPMGoodsService goods;
        private readonly IPayRecnoService payrecnos;

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="_service">活动服务</param>
        /// <param name="_client"></param>
        /// <param name="_userservice">用户服务</param>
        /// <param name="_goods"></param>
        /// <param name="_payrecnos"></param>
        public ActivityController(IActivityService _service, IClientService _client,IUserService _userservice, IHPMGoodsService _goods, IPayRecnoService _payrecnos)
        {
            this.service = _service;
            this.client = _client;
            this.userservice = _userservice;
            this.goods = _goods;
            this.payrecnos = _payrecnos;
            Task.Run(() => TransferPass());                      //后台处理
        }
        /// <summary>
        /// 活动申请提交，需要前端提供Session，用户验证后使用
        /// </summary>
        /// <param name="input">活动申请信息</param>
        /// <response code="200">返回提交的活动申请信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Activity>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> NewActivity(ActivityInput input)
        {
            var uid =int.Parse(Request.HttpContext.Items["Uid"].ToString());
            var businessid = 0;
            //商品列表和用户id都不空，验证商品
            if (input.Goodses.Count() > 0 && uid > 0&&goods.IsCheck())
            {
                var check = await CheckGoods(input.Goodses, uid);
                if (check != "OK")
                {
                    return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "商品验证失败:" + check);
                }
            }
            //提交活动
            var result = await service.ActivityApply(input, uid, businessid);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "该活动添加失败");
            }
            //返回结果
            return new JsonReturn<Activity>(result,1,"活动申请添加成功，请及时支付费用");
        }
        /// <summary>
        /// 通过微信向平台支付服务费用
        /// </summary>
        /// <param name="id">活动id</param>
        /// <param name="userid">支付用户id</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<WeChatPaymentOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn ActivityPayByWeChat(string id, int userid)
        {
            var activity = service.GetDetailed(id);
            if (activity == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该活动记录！");
            if (activity.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该活动已经支付过！");
            }
            var price = (int)(activity.Amount * activity.SetMoney * 0.05);
            var payno = payrecnos.GetCode(id);
            //发起微信支付
            var Dto = new WeChatPaymentInputDto
            {
                Body = "向平台支付活动申请费用",
                Attach = "按数量*面额*0.05计算申请费用",
                Code = payno,
                Price = price,
                NotifyUrl = "http://xydev.yczlsq.com/api/Activity/Notify"
            };
            var result = client.WeChatPayment(userid, Dto);
            //返回结果
            return result;
        }
        /// <summary>
        /// 通过微信公众号向平台支付服务费用
        /// </summary>
        /// <param name="id">活动id</param>
        /// <param name="userid">支付用户id</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<AllinWeChatOfficialAccountPaymentPayinfoOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn ActivityPayByGZH(string id, int userid)
        {
            var activity = service.GetDetailed(id);
            if (activity == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该活动记录！");
            if (activity.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该活动已经支付过！");
            }

            var price = (int)(activity.Amount * activity.SetMoney * 0.05);
            var payno = payrecnos.GetCode(id);
            //发起微信公众号支付
            var Dto = new AllinWeChatOfficialAccountsPaymentInputDto
            {
                Body = "向平台支付活动申请费用",
                Params = "按数量*面额*0.05计算申请费用",
                Code = payno,
                Amount = price,
                NotifyUrl = "http://xydev.yczlsq.com/api/Activity/Notify"
            };
            var result = client.WeChatGZHPayment(userid, Dto);
            return result;
        }
        /// <summary>
        /// 通过通联支付费用
        /// </summary>
        /// <param name="id">活动id</param>
        /// <param name="userid">用户id</param>
        /// <param name="agreeid">协议id</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<AllinPaymentOtherPaymentOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn ActivityPayByAllin(string id, int userid,string agreeid)
        {
            var activity = service.GetDetailed(id);
            if (activity == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该活动记录！");
            if(activity.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该活动已经支付过！");
            }
            var payno = payrecnos.GetCode(id);
            var price = (int)(activity.Amount * activity.SetMoney * 0.05);
            //发起微信公众号支付
            var Dto = new AllinpaymentOtherPaymentApplyInputDto
            {
                Body = "向平台支付活动申请费用",
                Params = "按数量*面额*0.05计算申请费用",
                OrderCode = payno,
                AgreeId = agreeid,
                Amount = price,
                NotifyUrl = "http://xydev.yczlsq.com/api/Activity/Notify"
            };
            var result = client.AllinPayment(userid, Dto);
            //返回结果
            return result;
        }
      
        /// <summary>
        /// 活动修改，需要前端提供Session
        /// </summary>
        /// <param name="id">活动id</param>
        /// <param name="input">修改内容</param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Activity>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> UpdateActivity(string id, ActivityInput input)
        {
            if (id == null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            //获取原纪录
            var temp = service.GetDetailed(id);
            if (temp == null)
            {
                //未发现原纪录
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该活动");
            }
            if(temp.IsPay) return new JsonReturn(EnumJsonReturnStatus.NoFound, "该活动已经支付过，无法修改");
            var result = await service.ActivityUpdate(temp,input);

            if (result)
            {
               //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK,"修改成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "修改不成功");
            }
        }
        /// <summary>
        /// 活动购买接口，需要前端提供Session，用户验证后使用
        /// </summary>
        /// <param name="input">输入活动购买信息</param>
        /// <response code="200">返回购买成功信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<PurchaseActivity>),StatusCodes.Status200OK)]
        public async Task<JsonReturn> Purchase(PurchaseActivityInput input)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            //获取活动
            var orders = service.GetDetailed(input.ActivityId);
            if (orders == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "活动id输入错误");
            }
            //计算购买次数
            var temp = 0;
            foreach (var n in orders.ParticipateList)
            {
                if (n == int.Parse(uid))
                {
                    temp = temp + 1;
                }
            };
            if (orders.PayNumber < temp)
            {

                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"该用户购买次数{orders.PayNumber}已经用完");
            }
            //判断活动有效性
            if (!orders.IsValid && orders.EndTime > DateTime.Now && orders.ParticipateList.Count() < orders.Amount)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该活动已经被终止，无法购买");
            }
            if (orders.ParticipateList.Count() >= orders.Amount)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该活动数量已满，无法购买");
            }
            if (orders.EndTime <= DateTime.Now)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该活动已经过期，无法购买");
            }
            //改为客户购买结算时支付
            //if(!orders.IsPay)        
            //{
            //    return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该活动未支付，无法购买");
            //}
            var result = await service.Purchase(orders,input.ShareId, int.Parse(uid));

            if (result != null)
            {
                //返回结果
                return new JsonReturn<PurchaseActivity>(result, 1, "已经成功购买");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "活动购买失败！");
            }
        }
        /// <summary>
        /// 购买人通过微信公众购买支付
        /// </summary>
        /// <param name="id">购买id</param>
        /// <param name="userid">用户id</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<AllinWeChatOfficialAccountPaymentPayinfoOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn PurchasePayByGZH(string id, int userid)
        {
            var purchase = service.GetPurchaseDetailed(id);
            if (purchase == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该购买记录！");
            if (purchase.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该购买已经支付过！");
            }
            var payno = payrecnos.GetCode(id);
            //支付额
            //发起微信公众号支付
            var Dto = new AllinWeChatOfficialAccountsPaymentInputDto
            {
                Body = "向平台支付购买费用，再分配到申请人和分享人资产",
                Params = "按购买价值结算",
                Code = payno,
                Amount = purchase.Price,
                NotifyUrl = "http://xydev.yczlsq.com/api/Activity/PurchaseNotify"
            };
            var result = client.WeChatGZHPayment(userid, Dto);
            return result;
        }
        /// <summary>
        /// 活动领取
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        public async Task<JsonReturn> Take(string id)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            try
            {
                await service.Take(id, int.Parse(uid));
                return new JsonReturn(EnumJsonReturnStatus.OK, "活动领取成功！");
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "活动领取失败！");
            }
        }
        /// <summary>
        /// 活动领取支付,通过微信公众
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<AllinWeChatOfficialAccountPaymentPayinfoOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn TakePayByGZH(string id, int userid)
        {
            var purchase = service.GetPurchaseDetailed(id);
            if (purchase == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该领取记录！");
            if (purchase.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该领取已经支付过！");
            }
            //支付号
            var payno = payrecnos.GetCode(id);
            //发起微信公众号支付
            var Dto = new AllinWeChatOfficialAccountsPaymentInputDto
            {
                Body = "向平台支付领取费用，分配给商户和平台",
                Params = "按价值10支付，商户和平台各5%",
                Code = payno,
                Amount =(int)(purchase.Price*0.1),
                NotifyUrl = "http://xydev.yczlsq.com/api/Activity/TakeNotify"
            };
            var result = client.WeChatGZHPayment(userid, Dto);
            return result;
        }
        /// <summary>
        /// 获取活动明细，客户本人使用接口，需要前端提供Session，以便记录浏览人和参入人
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回活动明细信息</response>
        [HttpGet("{id}")]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Activity>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> GetActivityByUser(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动id要求输入");
            }
            //查询记录
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var result = service.GetDetailed(id);
            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的活动");
            await service.UpdateBrowse(id, int.Parse(uid));
            //返回结果
            return new JsonReturn<Activity>(result, Mess:"返回活动明细");

        }
        /// <summary>
        /// 获取活动明细，后台管理使用，不计算浏览人和参入人
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回活动明细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<Activity>), StatusCodes.Status200OK)]
        public JsonReturn GetActivity(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动id要求输入");
            }
            //查询记录
            var result = service.GetDetailed(id);
            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的活动");

            //返回结果
            return new JsonReturn<Activity>(result, 1,"返回活动明细");

        }
        /// <summary>
        /// 获取活动的浏览人列表
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<dynamic>), StatusCodes.Status200OK)]
        public JsonReturn GetBrowseList(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动id要求输入");
            }
            var temp = service.GetDetailed(id);
            if (temp == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无数据返回");
            }
            var result = new List<User>();
            foreach (var n in temp.BrowseList)
            {
                var mm=userservice.GetDetailed(n);
                result = result.Append(mm).ToList();
            }
            return new JsonReturn<dynamic>(result.Select(o => new { o.ID, o.Name, o.Portrait }),result.Count,Mess:"返回浏览人列表");
        }
        /// <summary>
        /// 获取活动的参与人列表
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<dynamic>), StatusCodes.Status200OK)]
        public JsonReturn GetParticipateList(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动id要求输入");
            }
    
            var temp = service.GetDetailed(id);
            if (temp==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无数据返回");
            }
            var result = userservice.GetUserList(temp.BrowseList);
            return new JsonReturn<dynamic>(result, result.Count, Mess:"返回参与人列表");
        }
        /// <summary>
        /// 获取活动的购买人列表
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<dynamic>), StatusCodes.Status200OK)]
        public JsonReturn GetPurchaseManList(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动id要求输入");
            }
            var temp = userservice.GetUserList(o=>true);
            if (temp == null || temp.Count() < 1)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无数据返回");
            }
            var result = service.GetPurchaseList(id);
            if (result!= null)
            {
                var query = result.Join(temp, purchase => purchase.PurchaseId, user => user.ID, (purchase, user) => new { user.ID, user.Name, user.Portrait, purchase.Price, purchase.CreateTime }).ToList();
                return new JsonReturn<dynamic>(query, result.Count, Mess: "返回购买人列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无数据返回");
            }
        }
        /// <summary>
        /// 获取购买明细
        /// </summary>
        /// <param name="id">购买id</param>
        /// <response code="200">返回领购买细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<PurchaseActivity>), StatusCodes.Status200OK)]
        public JsonReturn GetPurchase(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "购买id要求输入");
            }
            //查询记录
            var result = service.GetPurchaseDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的购买记录");

            //返回结果
            return  new JsonReturn<PurchaseActivity>(result,Mess:"返回购买明细");
       
        }
      
        /// <summary>
        /// 获取领取明细
        /// </summary>
        /// <param name="id">领取id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<ActivityTake>), StatusCodes.Status200OK)]
        public JsonReturn GetTake(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "领取id要求输入");
            }
            //查询记录
            var result = service.GetTakeDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的领取记录");

            //返回结果
            return new JsonReturn<ActivityTake>(result, Mess: "返回领取明细");

        }
        /// <summary>
        /// 获取购买列表
        /// </summary>
        /// <param name="activityid">活动id</param>
        /// <param name="uid">发起人id</param>
        /// <param name="purchaseid">购买人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="IsCanUse">是否可使用,true可使用，false全部</param>
        /// <param name="IsPay">是否支付，true已支付，false全部</param>
        /// <response code="200">返回购买列表信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<PurchaseActivityModel>>), StatusCodes.Status200OK)]
        public JsonReturn GetPurchaseList(string activityid = "", int uid = 0, int purchaseid = 0, int PageIndex = 1, int PageSize = 15, bool IsCanUse = true, bool IsPay = true)
        {
            var result = service.GetPurchaseList(activityid, uid, purchaseid, PageIndex, PageSize, IsCanUse, IsPay);
         
            return result;
        }
        /// <summary>
        /// 获取领取列表
        /// </summary>
        /// <param name="activityid">活动id</param>
        /// <param name="uid">发起人id</param>
        /// <param name="takeid">领取人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="IsCanUse">是否可使用,true可使用，false全部</param>
        /// <param name="IsPay">是否支付，true已支付，false全部</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<ActivityTake>>), StatusCodes.Status200OK)]
        public JsonReturn GetTakeList(string activityid = "", int uid = 0, int takeid = 0, int PageIndex = 1, int PageSize = 15, bool IsCanUse = true, bool IsPay = true)
        {
            var result= service.GetTakeList(activityid , uid , takeid, PageIndex, PageSize, IsCanUse , IsPay);
            return result;
       }
        /// <summary>
        /// 获取活动的列表
        /// </summary>
        /// <param name="uid">发起用户的uid</param>
        /// <param name="kind">工具类别0-活动智能套框，1-带现金支付，分享红包分利的智能卡</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每月记录</param>
        /// <param name="IsValid">仅查看有效</param>
        /// <response code="200">返回购买列表信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Activity>>), StatusCodes.Status200OK)]
        public JsonReturn GetListByActivity(int uid=0, ActivityType kind = 0, int PageIndex = 1, int PageSize = 15,bool IsValid=true)
        {
            return service.GetActivityList(uid,kind, PageIndex, PageSize,IsValid);
        }
        /// <summary>
        /// 活动终止,需要验证session
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        /// <response code="200">返回活动终止信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Cancel(string id)
        {
            if (id ==null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var activity = service.GetDetailed(id);

            if (activity == null || !activity.IsValid||activity.Amount==activity.ParticipateList.Count())
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的活动或者已终止");
            }
            //终止
            var temp = await service.Cancel(id);
            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "终止不成功");
            }
        }
        /// <summary>
        /// 活动删除（用户本人操作）
        /// </summary>
        /// <param name="id">活动id</param>
        /// <response code="200">返回活动删除信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Delete(string id)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            if (id == null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var activity = service.GetDetailed(id);

            if (activity == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的活动或者已删除");
            }
            else
            {
                if (activity.UId != int.Parse(uid))
                {
                    return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "活动删除需要用户本人操作");
                }
            }
            var temp = await service.DeleteActivity(id);

            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "删除不成功");
            }
        }
        /// <summary>
        /// 测试时模拟前台登录掌联系统
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonReturn TestLogin(string phone = "13967355806", string password = "54241000")
        {
            var result = client.UserLogin(phone, password);
            if (result == null) return new JsonReturn(EnumJsonReturnStatus.Fail, "登录失败！！！");
            var session = result.S;
            HttpContext.Response.Cookies.Append("s", session);
            return new JsonReturn<string>(session, Mess:"返回用户Cookie信息");

        }
        /// <summary>
        /// 活动申请支付通知，由后台回调
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Notify(OtherPaymentResult data)
        {
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "申请支付通知>>");
            log.Info("接收数据：" + JsonConvert.SerializeObject(data));
            if (data.Result)
            {
                var payno = data.Code.Substring(0, data.Code.Length - 2);
                //支付标记
                await service.PayMark(payno);
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail);

            }
        }
        /// <summary>
        /// 活动购买支付通知，由后台回调
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> PurchaseNotify(OtherPaymentResult data)
        {
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "购买支付通知>>");
            log.Info("接收数据：" + JsonConvert.SerializeObject(data));
            if (data.Result)
            {
                var payno = data.Code.Substring(0, data.Code.Length - 2);
                //获取购买记录
                var purchase = service.GetPurchaseDetailed(payno);
                //支付标记
                await service.ActivityMark(purchase.ActivityId, purchase.PurchaseId);
                //标记购买单
                await service.PayerPayMark(payno);

                //分派金额
                if (purchase.UId != 0)
                {
                    var activity = service.GetDetailed(purchase.ActivityId);
                    //平台收费
                    int cost = (int)(purchase.Price * 0.05);
                    if(activity.IsPay)
                    {
                        cost = 0;      //已经支付过服务费
                    }
                    //记账申请人待收资产
                    var input = new BalnaceUpdateData()
                    {
                        UserId = purchase.UId,
                        Balance = purchase.Price - purchase.ShareMoney-cost
                    };
                    client.UpdateFreezeBalance(input);
                    //添加代收资产
                    await service.AddReceipt(purchase.Id,"活动购买支付时记账商户待收资产", input.UserId, input.Balance,"申请人");
                }
                if (purchase.ShareID != 0)
                {
                    //向分享人发送红包
                    var input1 = new BalnaceUpdateData()
                    {
                        UserId = purchase.ShareID,
                        Balance = purchase.ShareMoney
                    };
                    client.UpdateFreezeBalance(input1);
                    //添加代收资产
                    await service.AddReceipt(purchase.Id, "活动购买支付时记账分享人待收资产", input1.UserId, input1.Balance,"分享人");
                }

                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail);

            }
        }
        /// <summary>
        /// 活动领取支付回调，由后台调用
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> TakeNotify(OtherPaymentResult data)
        {
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "领取支付通知>>");
            log.Info("接收数据：" + JsonConvert.SerializeObject(data));
            if (data.Result)
            {
                var payno = data.Code.Substring(0, data.Code.Length - 2);
                //获取领取记录
                var take = service.GetTakeDetailed(payno);
                //支付标记,标记活动单
                await service.ActivityMark(take.ActivityId, take.TakeId);
                //标记领取单
                await service.PayTakeMark(payno);
                var money = (int)(take.Price * 0.05);
                //分派金额
                //记账申请人待收资产
                var input = new BalnaceUpdateData()
                {
                    UserId = take.UId,
                    Balance = money
                };
                client.UpdateFreezeBalance(input);
                //添加代收资产
                await service.AddReceipt(take.Id,"活动领取支付的待收资产", take.UId, money,"申请人");
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail);

            }
        }
        /// <summary>
        /// 获取用户账单列表（商户，或者分享人）关于冻结资产明细
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="untransfer">true未转账,false全部</param>
        [ProducesResponseType(typeof(JsonReturn<List<ReceiptModel>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetAccount(int uid,int PageIndex = 1, int PageSize = 15,bool untransfer=true)
        {
            if(uid<1)  return new JsonReturn(EnumJsonReturnStatus.NoFound,"用户id需要输入有效数据");
            var result = service.GetReceipts(uid,PageIndex,PageSize,untransfer);
            return result;
        }
        /// <summary>
        /// 商户活动购买核销，由商户调用(线下交易使用)
        /// </summary>
        /// <param name="id">核销id</param>
        /// <param name="uid">发起商户的用户id,0时不验证用户</param>
        /// <param name="goodsid">商品id，0时不验证商品</param>
        /// <returns>返回核销金额</returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<int>), StatusCodes.Status200OK)]
        public JsonReturn WriteOffPurchase(string id, int uid=0, int goodsid=0)
        {
            var temp = service.GetPurchaseDetailed(id);
            if (temp == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的购买记录");
            if (temp.IsUsed) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该id的购买已经使用");
            if (uid!=0&temp.UId != uid) return new JsonReturn(EnumJsonReturnStatus.NoFound, "商户id不符合");
            if (goodsid!=0&!temp.Goodses.Contains(goodsid)) return new JsonReturn(EnumJsonReturnStatus.NoFound, "商品id不符合");
         
            var tempacti = service.GetDetailed(temp.ActivityId);
            var account = service.GetReceipt(temp.Id, "申请人");
            //转入记账申请人资产
            var input = new BalnaceUpdateData()
            {
                UserId = account.Uid,
                Balance = account.Money
            };
            client.UpdateBalance(input);
            //转出记账申请人待收资产
            var input1 = new BalnaceUpdateData()
            {
                UserId = account.Uid,
                Balance = -account.Money
            };
            client.UpdateFreezeBalance(input1);
            //标记已经转出
            Task.Run(() => service.MarkReceipt(account.Id));
            //使用标记
            service.UsePurchase(id);
            return new JsonReturn<int>(temp.Price, 1, "核销金额");

        }
        /// <summary>
        /// 领取核销，由商户调用(线下交易使用)
        /// </summary>
        /// <param name="id">核销id</param>
        /// <param name="uid">发起商户的用户id</param>
        /// <param name="goodsid"></param>
        /// <returns>返回核销金额</returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<int>), StatusCodes.Status200OK)]
        public JsonReturn WriteOffTake(string id, int uid, int goodsid)
        {
            var temp = service.GetTakeDetailed(id);
            if (temp == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的领取记录");
            if (temp.IsUsed) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该id的领取已经使用");
            if (uid != 0 & temp.UId != uid) return new JsonReturn(EnumJsonReturnStatus.NoFound, "商户id不符合");
            if (goodsid != 0 & !temp.Goodses.Contains(goodsid)) return new JsonReturn(EnumJsonReturnStatus.NoFound, "商品id不符合");
            var tempacti = service.GetDetailed(temp.ActivityId);
           
            var account = service.GetReceipt(temp.Id, "申请人");
            //转入记账申请人资产
            var input = new BalnaceUpdateData()
            {
                UserId = account.Uid,
                Balance = account.Money
            };
            client.UpdateBalance(input);
            //转出记账申请人待收资产
            var input1 = new BalnaceUpdateData()
            {
                UserId = account.Uid,
                Balance = -account.Money
            };
            client.UpdateFreezeBalance(input1);
            //标记已经转出
            Task.Run(() => service.MarkReceipt(account.Id));
            //使用标记
            service.UseTake(id);
            return new JsonReturn<int>(temp.Price, 1, "核销金额");
        }
        /// <summary>
        /// 处理转账
        /// </summary>
        /// <returns></returns>
        private async Task TransferPass()
        {
            //获取过期未转账
            var accounts = service.GetReceipts(10);
            foreach (var account in accounts)
            {
               
                //转入记账申请人资产
                var input = new BalnaceUpdateData()
                {
                    UserId = account.Uid,
                    Balance = account.Money
                };
                client.UpdateBalance(input);
                //转出记账申请人待收资产
                var input1 = new BalnaceUpdateData()
                {
                    UserId = account.Uid,
                    Balance = -account.Money
                };
                client.UpdateFreezeBalance(input1);
                //标记已经转出
                await service.MarkReceipt(account.Id);
            }
        }
        /// <summary>
        /// 检查商品
        /// </summary>
        /// <param name="goodsid"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        private async Task<string> CheckGoods(int[] goodsid, int uid)
        {
            string result = "OK";
            //验证商品
            foreach (var n in goodsid)
            {
                if (n>0)
                {
                    var tempgoods = goods.Get(n);
                    //本地无商品记录
                    if (tempgoods==null||tempgoods.GoodId==0)
                    {
                        //添加本地数据
                        var tempid = client.GetBusinessId(n);
                        //网络无商品记录
                        if (tempid==null||tempid.Id == 0)
                        {
                            return $"提交的商品{n}不存在，请检查";
                        }
                        else
                        {
                            tempgoods = await goods.Add(tempid.Id, tempid.Name, tempid.Price, tempid.BusinessId, tempid.UserId, tempid.Price, DateTime.Now);
                        }
                    }
                    //验证所属
                    result = goods.CheckUser(tempgoods, uid);
                    if(result!="OK")
                    {
                        return result;
                    }
                }
            }
            return result;
        }
    }
}