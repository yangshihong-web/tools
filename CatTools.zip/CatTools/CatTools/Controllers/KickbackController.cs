﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 红包控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class KickbackController : ControllerBase
    {
        private readonly IKickbackService service;
        private readonly IClientService client;

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="_service">红包服务</param>
        /// <param name="_client"></param>
        public KickbackController(IKickbackService _service, IClientService _client)
        {
            this.service = _service;
            this.client = _client;
        }
        /// <summary>
        /// 红包发放，客户发放一个新出的红包
        /// </summary>
        /// <param name="input"></param>
        /// <response code="200">返回提交的红包数据</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Kickback>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Distribute(NewKickbackInput input)
        {
            //获取发送人数据
            var temp = client.GetUserByPhone(input.Phone);
            if(temp==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该用户的信息");
            }
            //判断可否发放红包的条件
            if(input.SingleMoney==0||input.People==0||input.Money==0)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "请输入有效数据");
            }
            if (input.Money > temp.Coupon)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该发送人是余额不足，请充值");
            }
            if(input.SingleMoney>input.Money)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "单笔金额不得大于发送额");
            }
            if(input.People*input.SingleMoney>input.Money)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "发送总额不足，请减少人数，或单笔金额");
            }
            //准备红包数据
            var tempinput = new KickbackDistribute()
            {
                Phone=input.Phone,
                Money = input.Money,
                People = input.People,
                SingleMoney = input.SingleMoney,
                Portrait = temp.Portrait,
                SendManId = temp.Id,
                SendManName = temp.Name,
                ValidTime = 3
            };
            //保存新红包
            var result = await service.NewKickback(tempinput);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "数据提交失败");
            }
            //锁定红包金额
            var data = new IncreaseCouponInputDto()
            {
                UserId = temp.Id,
                Coupon = -input.Money
            };
            client.UpdateUserCoupon(data);
            //返回结果
            return new JsonReturn<Kickback>(result);
        }
        /// <summary>
        /// 红包领取，客户领取一个红包
        /// </summary>
        /// <param name="input"></param>
        /// <response code="200">返回提交的领取数据信息</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<TakeKickback>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> TakeAKickback(TakeKickbackInput input)
        {
            var user = client.GetUserByPhone(input.Phone);
            if(user==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无指定用户");
            }
            var result = await service.NewKickbackTake(input,user);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "数据提交失败");
            }
            //提交领取人的转入申请
            var data = new IncreaseCouponInputDto()
            {
                UserId = user.Id,
                Coupon = result.TakeMoney
            };
            client.UpdateUserCoupon(data);
            //返回结果
            return new JsonReturn<TakeKickback>(result);
        }
        /// <summary>
        /// 红包终止，人工结束一个红包的领取
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回终止成功信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Cancel(string id)
        {
            if (string.IsNullOrEmpty(id)) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            //查询记录
            var temp = service.GetDetailed(id);
            if(temp==null)  return new JsonReturn(EnumJsonReturnStatus.NoFound, "该红包不存在");
            //未领取余额解锁
            //返还红包余额
            var mess = new IncreaseCouponInputDto()
            {
                UserId = temp.SendManId,
                Coupon = temp.Money - temp.TakeMoney
            };
            client.UpdateUserCoupon(mess);
            var result = await service.EndKickback(id);
            if (!result)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "红包终止不成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
        }
        /// <summary>
        /// 检查红包是否有效，检查某只红包的有效性
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回该红包有效信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public JsonReturn CheckIn(string id)
        {
            //查询记录
            var result = service.CheckKickback(id);

            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "该红包已经失效");
            }
         }
        /// <summary>
        /// 获取红包明细,
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回指定红包信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<Kickback>), StatusCodes.Status200OK)]
        public JsonReturn Getid(string id)
        {
            //查询记录
            var result = service.GetDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的红包");

            //返回结果
            return new JsonReturn<Kickback>(result);
        }
        /// <summary>
        /// 获取指定发送人的红包列表
        /// </summary>
        /// <param name="Manid">红包发送人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录数</param>
        /// <param name="Isvalid">true默认为有效红包，false全部红包</param>
        /// <response code="200">返回提交的礼品申请信息或者空表</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Kickback>>), StatusCodes.Status200OK)]
        public JsonReturn GetList(int Manid,int PageIndex = 1, int PageSize = 15,bool Isvalid=true )
        {
            int total = 0;
            var result = service.GetList(out total,Manid,PageIndex, PageSize, Isvalid);
            if (result != null)
            {
                return new JsonReturn<List<Kickback>>(result, total, "返回指定发送人的红包列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        /// <summary>
        /// 获取领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回指定领取明细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<TakeKickback>), StatusCodes.Status200OK)]
        public JsonReturn GetidTake(string id)
        {
            //查询记录
            var result = service.GetTakeDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的领取");

            //返回结果
            return new JsonReturn<TakeKickback>(result);
        }
        /// <summary>
        /// 获取指定红包的领取列表
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <response code="200">返回提交的礼品申请信息或者空表</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<TakeKickback>>), StatusCodes.Status200OK)]
        //[ResponseCache(Duration = 20)]
        public JsonReturn GetListByKickback(string Id, int PageIndex = 1, int PageSize = 15)
        {
            int total = 0;
            var result = service.GetTakeList(out total,Id, PageIndex, PageSize);
            if (result != null)
            {
                return new JsonReturn<List<TakeKickback>>(result, total, "返回指定红包领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        /// <summary>
        /// 获取指定领取人的领取列表
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <response code="200">返回提交的礼品申请信息或者空表</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<TakeKickback>>), StatusCodes.Status200OK)]
        public JsonReturn GetListByManid(int Id, int PageIndex = 1, int PageSize = 15)
        {
            int total = 0;
            var result = service.GetTakeListByTakeMan(out total,Id, PageIndex, PageSize);
            if (result != null)
            {
                return new JsonReturn<List<TakeKickback>>(result, total, "返回指定领取人的领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
    }
}