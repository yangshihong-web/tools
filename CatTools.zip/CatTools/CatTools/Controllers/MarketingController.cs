﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 申请加盟控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MarketingController : ControllerBase
    {
        private readonly IMarketingService service;
        private readonly IClientService client;
        private readonly IPayRecnoService payrecnos;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="_service">加盟服务</param>
        /// <param name="_client"></param>
        /// <param name="_payrecnos"></param>
        public MarketingController(IMarketingService _service, IClientService _client, IPayRecnoService _payrecnos)
        {
            this.service = _service;
            this.client = _client;
            this.payrecnos = _payrecnos;
        }
        /// <summary>
        /// 添加新的创业者
        /// </summary>
        /// <param name="level">创业者级别</param>
        /// <response code="200">返回新创业者数据</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Entrepreneur>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> NewEntrepreneur(EntrepreneurLevel level)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var result = await service.AddEntrepreneur(level, int.Parse(uid));
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "数据提交失败");
            }
            //返回结果
            return new JsonReturn<Entrepreneur>(result);
        }
        /// <summary>
        /// 创业者升级
        /// </summary>
        /// <param name="level">升到的级别</param>
        /// <response code="200">返回指升级成功信息</response>
        [HttpPut]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Upgrade(EntrepreneurLevel level)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var temp = await service.Upgrade(level, int.Parse(uid));

            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "升级不成功");
            }
        }
        /// <summary>
        /// 通过微信向平台支付
        /// </summary>
        /// <param name="id">创业者id</param>
        /// <returns></returns>
        [HttpPost("{id}")]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<WeChatPaymentOutputDto>), StatusCodes.Status200OK)]
        public JsonReturn Pay(int id)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var temp = service.GetEntrepreneur(id);
            var payno = payrecnos.GetCode(id.ToString());
            //发起微信支付
            var Dto = new WeChatPaymentInputDto
            {
                Body = "向平台支付创业者申请费用",
                Attach = "按设定的创业者费用计算，升级扣除原付款费用",
                Code = payno,
                Price = temp.CurrentMoney,
                NotifyUrl = "http://xydev.yczlsq.com/api/Marketing/Notify"
            };
            var result = client.WeChatPayment(int.Parse(uid), Dto);
            //返回结果
            return result;
        }
        /// <summary>
        /// 创业者申请支付通知，由后台回调
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Notify(OtherPaymentResult data)
        {
            if (data.Result)
            {
                var payno = data.Code.Substring(0, data.Code.Length - 2);
                //支付标记
                await service.PayMark(int.Parse(payno));
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail);

            }
        }
        /// <summary>
        /// 领取创业者发放的礼包
        /// </summary>
        /// <param name="kind">领取类别</param>
        /// <param name="id">创业者id</param>
        /// <response code="200">返回指定红包信息</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Kickback>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> TakeGift(TakeKind kind, int id)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var result = await service.TakeGift(kind, id, int.Parse(uid));
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "数据提交失败");
            }
        }
        /// <summary>
        /// 获取创业者明细
        /// </summary>
        /// <param name="id">创业者id</param>
        /// <response code="200">返回指定红包信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<Entrepreneur>), StatusCodes.Status200OK)]
        public JsonReturn Getid(int id)
        {
            //查询记录
            var result = service.GetEntrepreneur(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的创业者");

            //返回结果
            return new JsonReturn<Entrepreneur>(result);
        }
        /// <summary>
        /// 获取创业者的领取列表（带分页）
        /// </summary>
        /// <param name="id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <response code="200">返回创业者的领取列表</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<List<TakeMarketing>>), StatusCodes.Status200OK)]
        public JsonReturn GetTakeById(int id, int PageIndex = 1, int PageSize = 15)
        {
            //查询记录
            int total = 0;
            var result = service.GetListByUserid(out total,id, PageIndex, PageSize);

            if (result != null)
            {
                return new JsonReturn<List<TakeMarketing>>(result, total, "返回创业者的领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");

        }
        /// <summary>
        /// 获取领取人的领取列表（带分页）
        /// </summary>
        /// <param name="id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <response code="200">返回领取人的领取列表</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<List<TakeMarketing>>), StatusCodes.Status200OK)]
        public JsonReturn GetTakeByTakeid(int id, int PageIndex = 1, int PageSize = 15)
        {
            //查询记录
            int total = 0;
            var result = service.GetListByTakeid(out total,id, PageIndex, PageSize);

            if (result != null)
            {
                return new JsonReturn<List<TakeMarketing>>(result, total, "返回领取人的领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");

        }
    }
}