﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 新人营销券制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MarketingCouponsController : ControllerBase
    {
        private readonly IMarketingCouponsService service;
        private readonly IClientService client;
        public MarketingCouponsController(IMarketingCouponsService _service, IClientService _client)
        {
            this.service = _service;
            var scales = service.GetScales();
            if(scales==null)
            {
                scales = new List<ScaleStack>() { };
            }
            Scale.SetScale(scales);
            this.client = _client;
        }
        #region 添加新比例  AddScale(int coustomer, int platform = 0)
        /// <summary>
        /// 添加新比例 
        /// </summary>
        /// <param name="coustomer">客户优惠比例，0-100，0表示无优惠，100表示免费</param>
        /// <param name="platform">平台承担比例，0-100，0表示不承担，100表示全部承担</param>
        [HttpPost]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<ScaleStack>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> AddScale(int coustomer, int platform = 0)
        {
            if(coustomer<0|coustomer>100)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户优惠比例{coustomer}不符合规定！");
            }
            if(platform<0|platform>100)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"平台承担比例{platform}不符合规定！");
            }
            if(platform>coustomer)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"平台承担比例{platform}不得大于客户优惠比例{coustomer}！");
            }
            var scale = service.GetScale(coustomer);
            if(scale!=null&&scale.CoustomerDis==coustomer)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户优惠比例{coustomer}已经存在！");
            }
            var newscale = new ScaleStack(coustomer, platform);
            var result = await service.AddScale(newscale);
            if (result)
            {
                //重新刷新列表
                var scales = service.GetScales();
                Scale.SetScale(scales);
                return new JsonReturn<ScaleStack>(newscale, 1, $"添加比例{coustomer}成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"添加比例{coustomer}失败！");
            }
        }
        #endregion  ***添加新比例
        #region  客户比例删除  Delete(int coustomer)
        /// <summary>
        /// 客户比例删除
        /// </summary>
        /// <param name="coustomer">客户比例</param>
        /// <returns></returns>
        [HttpPut("{coustomer}")]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Delete(int coustomer)
        {
            if (coustomer<1) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户比例{coustomer}无效！");
            var result =await  service.DeleteScale(coustomer);

            if (result)
            {
                //重新刷新列表
                var scales = service.GetScales();
                Scale.SetScale(scales);
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK, $"客户比例{coustomer}成功！");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"客户比例{coustomer}删除不成功");
            }
        }
        #endregion
        #region 返回比例列表
        /// <summary>
        /// 返回比例列表
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<ScaleStack>>), StatusCodes.Status200OK)]
        public JsonReturn GetScales()
        {
   
            var scales = Scale.GetScales();
            return new JsonReturn<List<ScaleStack>>(scales, scales.Count, Mess: "返回比例列表");
        }
        #endregion
        #region 生成新的营销券
        /// <summary>
        /// 生成新的营销券
        /// </summary>
        /// <param name="input">营销券信息</param>
        /// <returns></returns>
        [HttpPost]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<MarketingCouponsStack>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> AddMarketing(MarketingCouponsInput input)
        {
            var marketing = new MarketingCouponsStack(input);
            var result=await service.AddMarketing(marketing);
            if(result)
            {
                return new JsonReturn<MarketingCouponsStack>(marketing, 1, $"添加营销券{marketing.Id}成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"添加营销券{marketing.Id}失败！");
            }
        }
        #endregion
        #region 修改营销券类型
        /// <summary>
        /// 修改营销券类型
        /// </summary>
        /// <param name="id">营销券id</param>
        /// <param name="input">新的营销券信息</param>
        /// <returns></returns>
        [HttpPut]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> UpdateMarketing(string id,MarketingCouponsInput input)
        {
            var marketing =service.GetMarketing(id);
            if(marketing==null||marketing.Id.Length<1)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现{id}营销券，无法修改");
            }
            var result = await service.AddMarketing(marketing);
            if (result)
            {
                return new JsonReturn<MarketingCouponsStack>(marketing, 1, $"营销券{id}修改成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"营销券{id}修改失败！");
            }
        }
        #endregion
        #region 营销券终止
        /// <summary>
        /// 营销券终止
        /// </summary>
        /// <param name="id">营销券id</param>
        /// <returns></returns>
        [HttpPut]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> CancelMarketing(string id)
        {
            var marketing = service.GetMarketing(id);
            if (marketing == null || marketing.Id.Length < 1)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现{id}营销券，无法终止");
            }
            var result = await service.CancelMarketing(id);
            if (result)
            {
                return new JsonReturn<MarketingCouponsStack>(marketing, 1, $"营销券{id}终止成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"营销券{id}终止失败！");
            }
        }
        #endregion
        #region  获取营销券
        /// <summary>
        /// 获取营销券
        /// </summary>
        /// <param name="id">营销券id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<MarketingCouponsStack>), StatusCodes.Status200OK)]
        public JsonReturn GetMarketing(string id)
        {
              
            var result = service.GetMarketing(id);
            if (result!=null)
            {
                return new JsonReturn<MarketingCouponsStack>(result, 1, Mess: "返回营销券");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现{id}营销券。");
            }
        }
        #endregion  获取营销券的列表
        #region  获取营销券的列表
        /// <summary>
        /// 获取营销券的列表
        /// </summary>
        /// <param name="isvalid">仅查看有效券</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<MarketingCouponsStack>>), StatusCodes.Status200OK)]
        public JsonReturn GetMarketings(bool isvalid = true, int PageIndex = 1, int PageSize = 15)
        {
            int totaltemp = 0;
            var result = service.GetMarketings(out totaltemp,isvalid,PageIndex,PageSize);

            return new JsonReturn<List<MarketingCouponsStack>>(result, totaltemp, "返回营销券的列表");
        }
        #endregion
        #region 设置商品比例
        /// <summary>
        /// 设置商品比例
        /// </summary>
        /// <param name="id">商品id</param>
        /// <param name="coustomerdis">客户优惠比例</param>
        /// <returns></returns>
        [HttpPost]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<CommodityStack>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> SetCommodity(int id,int coustomerdis)
        {
            var commodity = service.GetCommodity(id);
            if(commodity==null)
            {
                //无记录，从网络读取，设置
                var temp= client.GetBusinessId(id);
                if(temp.Id==0)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, $"无商品{id}的记录！");
                }
                var scale = Scale.Get(coustomerdis);
                if(scale==null)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, $"无比例{coustomerdis}的记录！");
                }
                commodity = new CommodityStack()
                {
                    ProductID = temp.Id,
                    BusinessId = temp.BusinessId,
                    Name = temp.Name,
                    Price = temp.Price,
                    UserId = temp.UserId,
                    CreateTime = DateTime.Now,
                    SetScale = Scale.GetUse(coustomerdis, temp.Price)
                };
                var result = await service.AddCommodity(commodity);
                if (result)
                {
                    return new JsonReturn<CommodityStack>(commodity, 1, $"保存商品{id}成功");
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.Fail, $"保存商品{id}失败！");
                }
            }
            else
            {
                var result = await service.SetCommodity(id,coustomerdis);
                if (result)
                {
                    return new JsonReturn<CommodityStack>(commodity, 1, $"保存商品{id}成功");
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.Fail, $"保存商品{id}失败！");
                }
            }
        }
        #endregion
        #region  获取商品
        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="id">商品id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<CommodityStack>), StatusCodes.Status200OK)]
        public JsonReturn GetCommodity(int id)
        {

            var result = service.GetCommodity(id);
            if (result != null)
            {
                return new JsonReturn<CommodityStack>(result, 1, Mess: "返回商品");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现{id}商品。");
            }
        }
        #endregion  获取商品
        #region  获取商品的列表
        /// <summary>
        /// 获取商品的列表
        /// </summary>
        /// <param name="businessid">商户id，商户id无效按用户id</param>
        /// <param name="uid">用户id，商户id与用户id同时无效，查看所有商品</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<CommodityStack>>), StatusCodes.Status200OK)]
        public JsonReturn GetCommoditys(int businessid = 0, int uid = 0, int PageIndex = 1, int PageSize = 15)
        {
            int totaltemp = 0;
            var result = service.GetCommoditys(out totaltemp,businessid,  uid , PageIndex, PageSize);

            return new JsonReturn<List<CommodityStack>>(result, totaltemp, "返回商品的列表");
        }
        #endregion
        #region 客户券领取
        /// <summary>
        /// 客户券领取
        /// </summary>
        /// <param name="id">有效券id</param>
        /// <param name="userid">客户的用户id</param>
        /// <returns></returns>
        [HttpPost]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<CustomerCouponsStack>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> TakeCoupons(string id, int userid)
        {
            if(string.IsNullOrEmpty(id)) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户领取营销券{id}失败！");
          
            if(userid<1) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户领取营销券{id}失败！");
            var marketing = service.GetMarketing(id);
            if(marketing==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"客户领取营销券{id}失败！");
            }
            if(!marketing.IsValid)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户领取营销券{id}失败！");
            }
            if(marketing.TakeEndTime<DateTime.Now)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户领取营销券{id}失败！");
            }
            var coupons = new CustomerCouponsStack(marketing, userid);
            var result = await service.AddMarketing(marketing);
            if (result)
            {
                return new JsonReturn<CustomerCouponsStack>(coupons, 1, $"客户领取营销券{id}成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, $"客户领取营销券{id}失败！");
            }
        }
        #endregion
        #region  获取客户券
        /// <summary>
        /// 获取客户券
        /// </summary>
        /// <param name="id">客户券id</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<CustomerCouponsStack>), StatusCodes.Status200OK)]
        public JsonReturn GetCoupons(string id)
        {

            var result = service.GetCoupons(id);
            if (result != null)
            {
                return new JsonReturn<CustomerCouponsStack>(result, 1, Mess: "返回客户券");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, $"未发现{id}客户券。");
            }
        }
        #endregion  获取客户券
        #region  获取客户券的列表
        /// <summary>
        /// 获取客户券的列表
        /// </summary>
        /// <param name="uid">用户id，用户id无效，查看所有券</param>
        /// <param name="onlyuse">仅查看有效客户券</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<CustomerCouponsStack>>), StatusCodes.Status200OK)]
        public JsonReturn GetCouponies(int uid = 0, bool onlyuse = true, int PageIndex = 1, int PageSize = 15)
        {
            int totaltemp = 0;
            var result = service.GetCouponies(out totaltemp, uid, onlyuse, PageIndex, PageSize);

            return new JsonReturn<List<CustomerCouponsStack>>(result, totaltemp, "返回客户券的列表");
        }
        #endregion
        #region 客户券使用
        /// <summary>
        /// 客户券使用
        /// </summary>
        /// <param name="id">客户券id</param>
        /// <param name="goodsid"></param>
        /// <returns></returns>
        [HttpGet]
        //[TokenInputActionFilter]
        //[TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Use(string id, int goodsid)
        {
            if(string.IsNullOrEmpty(id))
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"客户券{id}无记录");
            }
            if(goodsid==0)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, $"商品{goodsid}无记录");
            }
            var result = await service.UseCoupons(id,goodsid);
            if (result=="OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, $"客户券{id}使用使用成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }
        }
        #endregion
    }
}