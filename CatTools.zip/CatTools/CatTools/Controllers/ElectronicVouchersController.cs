﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 电子券控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ElectronicVouchersController : ControllerBase
    {
        private readonly IElectronicVouchersService service;

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="_service">电子券服务</param>
        public ElectronicVouchersController(IElectronicVouchersService _service)
        {
            this.service = _service;
        }
        #region 电子券生成
        /// <summary>
        /// 电子券包生成，申请用户使用，需要验证session
        /// </summary>
        /// <param name="input">礼品</param>
        /// <response code="200">返回券包明细信息</response>
        [HttpPost]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<ElectronicVouchers>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> NewVoucher(ElectronicVouchersInput input)
        {
            var result = await service.Distribute(input);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "电子券包生成失败");
            }
            //返回结果
            return new JsonReturn<ElectronicVouchers>(result,Mess:"电子券包生成成功");
        }
        #endregion
        #region  电子券包终止
        /// <summary>
        /// 电子券包终止，不再继续发放，申请用户使用，需要验证session
        /// </summary>
        /// <param name="id"></param>
        /// <response code="200">返回领取明细信息</response>
        [HttpPut("{id}")]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Cancel(string id)
        {
            if (id == null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var Goods = service.GetDetailed(id);

            if (Goods == null || !Goods.IsValid)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的电子券或者已终止");
            }
            //终止
            var temp = await service.Cancel(id);
            if (temp)
            {
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK);
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "终止不成功");
            }
        }
        #endregion
        #region 电子券使用
        /// <summary>
        /// 电子券使用，标记信息，商户或者后台使用
        /// </summary>
        /// <param name="id">电子券id</param>
        /// <param name="money">使用额，0时，全额使用</param>
        /// <param name="uid">用户id，为0时不验证用户</param>
        /// <param name="goodsid">商品id，为0时不验证商品</param>
        /// <response code="200">返回成功或者失败</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<int>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> Use(string id, int money=0,int uid=0, int goodsid=0)
        {
            if (id == null) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "id不可空值");
            var take = service.GetTakeDetailed(id);
            if(take==null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "无此电子券");
            var elect = service.GetDetailed(take.VouchersId);
            if (uid!=0&elect.ZLUId!=uid) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "掌联用户id错误");
            if(goodsid!=0&!elect.ZLProductID.Contains(goodsid)) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "掌联商品id错误");
            var canmoney = take.Money - take.UseMoney;
            if(canmoney<=0)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "此电子券无可扣除余额");
            }
            //余额不满足,按可扣余额扣除
            if (money>canmoney)
            {
               money= canmoney;
            }
            take.UseMoney = take.UseMoney + money;
            var temp = await service.Use(take);
            if (temp < 0)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "使用不成功");

            }
            else
            {
                //返回结果
                return new JsonReturn<int>(temp, 1, "电子券使用成功");
            }
        }
        #endregion
        #region  电子券领取
        /// <summary>
        /// 电子券领取，客户领取电子券时保存信息，领取客户使用，需要提供session
        /// </summary>
        /// <param name="input">输入领取信息</param>
        /// <response code="200">返回领取明细信息</response>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn<TakeVouchers>), StatusCodes.Status200OK)]
        [TokenInputActionFilter("User")]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        public async Task<JsonReturn> Take(TakeVouchersInput input)
        {
            var temp = await service.TakeGoods(input);

            if (temp == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该电子券已经过期，无法领取");
            }
            //返回结果
            return new JsonReturn<TakeVouchers>(temp);
        }
        #endregion
        #region 获取指定电子券礼包
        /// <summary>
        /// 获取指定电子券，商家查看已发的电子券信息
        /// </summary>
        /// <param name="id">电子券ID</param>
        /// <response code="200">返回领取明细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<ElectronicVouchers>), StatusCodes.Status200OK)]
        public JsonReturn Getid(string id)
        {
            //查询记录
            var result = service.GetDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的电子券");

            //返回结果
            return new JsonReturn<ElectronicVouchers>(result);
        }
        #endregion
        #region 获取电子券的记录
        /// <summary>
        /// 获取指定电子券，
        /// </summary>
        /// <param name="id">电子券ID</param>
        /// <response code="200">返回明细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<TakeVouchers>), StatusCodes.Status200OK)]
        public JsonReturn GetTakeById(string id)
        {
            //查询记录
            var result = service.GetTakeDetailed(id);

            if (result == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该id的领取记录");

            //返回结果
            return new JsonReturn<TakeVouchers>(result);
        }
        #endregion
        #region 获取指定用户的电子券列表(分页)
        /// <summary>
        /// 获取指定掌联用户的电子券列表(分页)，按掌联商铺id查看电子券
        /// </summary>
        /// <param name="uid">指定掌联用户id</param>
        /// <param name="shopid">指定嗨派猫用户id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvlid">true仅查看有效信息</param>
        /// <response code="200">返回明细信息或者空表</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<ElectronicVouchers>>), StatusCodes.Status200OK)]
        public JsonReturn GetList(int uid = 0,int shopid=0, int PageIndex = 1, int PageSize = 15, bool isvlid = true)
        {
            int total = 0;
            var result = service.GetList(out total,uid,shopid, PageIndex, PageSize, isvlid);
            if (result != null)
            {
                return new JsonReturn<List<ElectronicVouchers>>(result, total, "返回指定电子券列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        #endregion
        #region  获取指定电子券红包的领取列表
        /// <summary>
        /// 获取指定电子券的领取列表，查查看对应电子券的领取情况
        /// </summary>
        /// <param name="id">电子券id</param>
        /// <param name="uid">领取用户id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="Isvalid">仅查看有效</param>
        /// <response code="200">返回领取明细信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<TakeVouchers>>), StatusCodes.Status200OK)]
        public JsonReturn GetTakeList(string id,int uid, int PageIndex = 1, int PageSize = 15, bool Isvalid = true)
        {
            if (id == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "电子券红包id要求输入");
            }
            int total = 0;
            var result = service.GetTakeList(out total,id,uid, PageIndex, PageSize,Isvalid);
            if (result != null)
            {
                return new JsonReturn<List<TakeVouchers>>(result, total, "返回指定电子券领取列表");
            }
            return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
        }
        #endregion
 
    }
}
