﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 折扣控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DiscountController : ControllerBase
    {
        private IDiscountService discount;
        private readonly IClientService client;
        private readonly IUserService userservice;
        private readonly IPayRecnoService payrecnos;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_discount"></param>
        /// <param name="_client"></param>
        /// <param name="_userservice"></param>
        /// <param name="_payrecnos"></param>
        public DiscountController(IDiscountService _discount, IClientService _client, IUserService _userservice, IPayRecnoService _payrecnos)
        {
            this.discount = _discount; ;
            this.client = _client;
            this.userservice = _userservice;
            this.payrecnos = _payrecnos;
        }
        /// <summary>
        /// 商户申请加盟
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <param name="goodsid">商品id列表</param>
        [ProducesResponseType(typeof(JsonReturn<Activity>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> BusinessApply(int shopid,int[] goodsid)
        {
            //获取商户信息
            var shop = client.GetBusiness(shopid);
            if(shop==null) return new JsonReturn(EnumJsonReturnStatus.NoFound,"商户不存在。");
             //获取商品信息
            var goodies = goodsid.ToList();
            //保存申请表
            var result = await discount.ApplySave(shop.Id, shop.Name, goodsid);
            //返回
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "申请加盟失败");
            }
            else
            {
                return new JsonReturn<AllianceBusiness>(result,1,"申请加盟成功");
            }
        }
        /// <summary>
        /// 商户取消加盟
        /// </summary>
        /// <param name="shopid">商户id</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpPut("{shopid}")]
        public async Task<JsonReturn> BusinessCancel(int shopid)
        {
            var result = await discount.BusinessCancel(shopid);
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "取消加盟成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "取消加盟失败");
            }
        }
        /// <summary>
        /// 获取加盟商户
        /// </summary>
        /// <param name="shopid">商户id</param>
        [ProducesResponseType(typeof(JsonReturn<AllianceBusiness>), StatusCodes.Status200OK)]
        [HttpGet("{shopid}")]
        public JsonReturn GetApply(int shopid)
        {
            var result = discount.GetApply(shopid);
            if (result != null)
            {
                return new JsonReturn<AllianceBusiness>(result, 1, "获取申请");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无商户记录");
            }
        }
        /// <summary>
        /// 获取加盟商户列表
        /// </summary>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        [ProducesResponseType(typeof(JsonReturn<List<AllianceBusiness>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetApplys(int page, int pagesize)
        {
            return discount.GetApplys(page, pagesize);
        }
        /// <summary>
        /// 加盟卡购买
        /// </summary>
        /// <param name="kind">卡类别</param>
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<string>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> PurchaseCard(CardKind kind)
        {
            var uid = int.Parse(Request.HttpContext.Items["Uid"].ToString());
            var user = userservice.GetDetailed(uid);
           
            var money = 0;
            switch(kind)
            {
                case CardKind.M200:
                    money = 200;
                    break;
                case CardKind.M300:
                    money = 300;
                    break;
                case CardKind.M400:
                    money = 400;
                    break;
                default:

                    break;
            }
            var orderid = await discount.AddCard(user.ID, user.Name,money);
            return new JsonReturn<string>(orderid, 1,"加盟卡购买登记");
        }
        /// <summary>
        /// 加盟卡充值
        /// </summary>
        /// <param name="cardid">卡号</param>
        /// <param name="kind">类别</param>
        [ProducesResponseType(typeof(JsonReturn<string>), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> ChargeCard(string cardid,CardKind kind)
        {
            var card = discount.GetCard(cardid);
            var money = 0;
            switch (kind)
            {
                case CardKind.M200:
                    money = 200;
                    break;
                case CardKind.M300:
                    money = 300;
                    break;
                case CardKind.M400:
                    money = 400;
                    break;
                default:

                    break;
            }
            var charge =await  discount.AddRecharge(card.Uid,cardid, money);
            return new JsonReturn<string>(charge, 1, "加盟卡充值");
        }
        /// <summary>
        /// 通过微信向平台支付
        /// </summary>
        /// <param name="id">订单id</param>
        [ProducesResponseType(typeof(JsonReturn<WeChatPaymentOutputDto>), StatusCodes.Status200OK)]
        [HttpPost]
        public JsonReturn PayCard(string id)
        {
            var charge = discount.GetRecharge(id);

            if (charge.IsPay)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该订单已经支付过！");
            }
            var payno = payrecnos.GetCode(id);
            var uid = discount.GetCard(charge.CardId);
            var price = (int)(charge.Cost);
            //发起微信支付
            var Dto = new WeChatPaymentInputDto
            {
                Body = "向平台支付加盟卡充值费用",
                Attach = "按规定比例计算",
                Code = payno,
                Price = price,
                NotifyUrl = "http://xydev.yczlsq.com/api/Discount/Notify"
            };
            var result = client.WeChatPayment(uid.Uid, Dto);
            //返回结果
            return result;
        }
        /// <summary>
        /// 支付回调
        /// </summary>
        /// <param name="data">回调数据</param>
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        [HttpPost]
        public async Task<JsonReturn> Notify(OtherPaymentResult data)
        {
            if (data.Result)
            {
                var payno = data.Code.Substring(0, data.Code.Length - 2);
                //支付标记
                var result=await discount.PayNotify(payno);
                if (result)
                {
                    return new JsonReturn(EnumJsonReturnStatus.OK);
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.Fail);
                }
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail);

            }
        }
        /// <summary>
        /// 加盟卡使用
        /// </summary>
        /// <param name="cardid">加盟卡id</param>
        /// <param name="money">使用金额</param>
        /// <param name="uid">发起商户的用户id</param>
        /// <param name="goodsid">0时不验证商品</param>
        [ProducesResponseType(typeof(JsonReturn<int>), StatusCodes.Status200OK)]
        [HttpGet]
        public async Task<JsonReturn> CardUse(string cardid,int money,int uid,int goodsid=0)
        {
            var card = discount.GetCard(cardid);
            if (card == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该加盟卡！");
            if(card.Money<1) return new JsonReturn(EnumJsonReturnStatus.NoFound, "该加盟卡余额不足，请充值！");
            if (money<=0) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "使用额需要大于0");
            if(uid<1) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "商户的uid输入错误！");
            var shop = discount.GetApply(uid);
            if(shop==null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "无该商户的加盟记录");
            if(goodsid!=0&!shop.Goods.Contains(goodsid)) return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "该商品不是优惠商品");
            var result = await discount.CardUse(card, money);
            if (result<0)
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "加盟卡使用失败");
             
            }
            else 
            {
                //返回扣除额
                return new JsonReturn<int>(result,1,"返回扣除额");
            }
        }

        /// <summary>
        /// 获取加盟卡
        /// </summary>
        /// <param name="id">id</param>
        [ProducesResponseType(typeof(JsonReturn<AllianceCard>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetCard(string id)
        {
            var result = discount.GetCard(id);
            return new JsonReturn<AllianceCard>(result, 1, "获取加盟卡");
        }
        /// <summary>
        /// 获取加盟列表
        /// </summary>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        [ProducesResponseType(typeof(JsonReturn<List<AllianceCard>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetCards(int page, int pagesize)
        {
            return discount.GetCards(page, pagesize);
        }
        /// <summary>
        /// 获取加盟卡的充值列表
        /// </summary>
        /// <param name="id">卡号</param>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        /// <param name="begintime">开始日期</param>
        [ProducesResponseType(typeof(JsonReturn<List<CardRecharge>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetCardCharge(string id,int page, int pagesize, DateTime begintime)
        {
            return discount.GetCardCharge(id,page,pagesize,begintime);
        }
        /// <summary>
        /// 获取充值明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(JsonReturn<CardRecharge>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetCharge(string id)
        {
            var result = discount.GetRecharge(id);
            return new JsonReturn<CardRecharge>(result, 1, "获取卡充值明细");
        }
        /// <summary>
        /// 获取客户未支付列表
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        [ProducesResponseType(typeof(JsonReturn<List<CardRecharge>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetUnPay(int uid)
        {
            var result = discount.GetUnPayOrder(uid);
            return new JsonReturn<List<CardRecharge>>(result, 1, "获取未支付充值列表");
        }
        /// <summary>
        /// 获取加盟卡的使用列表
        /// </summary>
        /// <param name="id">卡号</param>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        /// <param name="begintime">开始日期</param>
        [ProducesResponseType(typeof(JsonReturn<List<CardUse>>), StatusCodes.Status200OK)]
        [HttpGet]
        public JsonReturn GetCardUser(string id,int page, int pagesize,DateTime begintime)
        {
            return discount.GetCardUser(id, page, pagesize, begintime);
        }
    }
}