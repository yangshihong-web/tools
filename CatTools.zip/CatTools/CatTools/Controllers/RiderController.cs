﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Services;
using CatTools.Shares;
using log4net;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    /// <summary>
    /// 外卖派送控制器
    /// </summary>
    [EnableCors("any")]               //跨域
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class RiderController : ControllerBase
    {
        private readonly IRiderService service;
        //private readonly IClientService client;
        private readonly IUserService userservice;

        public RiderController(IRiderService _service, IUserService _userservice)
        {
            this.service = _service;
            //this.client = _client;
            Task.Run(()=>DeliveryPass());                      //后台处理,客户过期未确认的记账
            this.userservice = _userservice;
            Task.Run(() =>service.PushMess());                 //后台处理未推送消息
        }
        //************************************************************************************
        //骑手接口
        //************************************************************************************
        #region 获取骑手信息,通过token验证
        /// <summary>
        /// 获取骑手信息,通过token验证
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Rider>), StatusCodes.Status200OK)]
        public JsonReturn GetRiderMess()
        {
            //获取骑手信息
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var rider = service.GetRider(uid);
            if (rider == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该骑手的信息！");
            }
            return new JsonReturn<Rider>(rider);
        }
        #endregion
        //************************************************************************************
        #region  获取骑手信息
        /// <summary>
        /// 获取骑手信息
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <returns></returns>
        [HttpGet("{riderid}")]
        [ProducesResponseType(typeof(JsonReturn<Rider>), StatusCodes.Status200OK)]
        public JsonReturn GetRider(int riderid)
        {
            //获取骑手信息
            var rider = service.GetRider(riderid);
            if (rider == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该骑手的信息！");
            }
            else
            {
                return new JsonReturn<Rider>(rider);
            }
  
        }
        #endregion
        //************************************************************************************
        #region  获取骑手账单信息
        /// <summary>
        /// 获取骑手账单信息
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <param name="days">查询天数,默认近30天以内</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <response code="200">返回骑手账单信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<AccountDetail>>), StatusCodes.Status200OK)]
        public JsonReturn GetRiderAccount(int riderid,int days=30, int pageIndex = 1, int pageSize = 15)
        {
            //获取骑手信息
            var rider = service.GetRider(riderid);
            if (rider == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该骑手的信息！");
            }
            var pageNum = 0;
            try
            {
                var begintime = DateTime.Now.AddDays(-days);
                var result = service.GetAccountList(rider.UserId, begintime, pageIndex, pageSize, out pageNum);
                return new JsonReturn<List<AccountDetail>>(result, pageNum, Mess:"返回骑手的账单");
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "开始和截止日期输入错误！");
            }
        }
        #endregion
        //************************************************************************************
        #region 骑手注册提交资料,该接口需要传递accesstoken
        /// <summary>
        /// 骑手注册提交资料,该接口需要传递accesstoken
        /// </summary>
        /// <param name="register">骑手资料</param>
        /// <response code="200">返回提交成功或者失败信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderRegister(RiderApplyDto register)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var rider = service.GetRider(uid);
            if (rider == null)
            {
                try
                {
                    //添加新的骑手用户
                    await service.AddRider(register, int.Parse(uid));
                    return new JsonReturn(EnumJsonReturnStatus.OK, "骑手注册成功！");
                }
                catch
                {
                    return new JsonReturn(EnumJsonReturnStatus.Fail, "骑手注册失败。");
                }
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "骑手已经注册过！");
            }
        }
        #endregion
        //************************************************************************************
        #region 更新骑手信息,该接口需要传递accesstoken
        /// <summary>
        /// 更新骑手信息,该接口需要传递accesstoken，信息更新后需要重新审核，否则无法接单，推荐商户id，当商户已经领取免单时，无法修改
        /// </summary>
        /// <param name="set">更新详细信息</param>
        /// <response code="200">返回更新成功或者失败信息</response>
        [HttpPut]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> UpdateRider(RiderModi set)
        {
            //获取本地骑手
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var rider = service.GetRider(uid);
            if (rider == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该骑手没有注册过，无法修改。");
            }
            var ts = rider.UpdateList(set);
            //更新用户信息
            var result=await service.UpdateRider(rider,ts);
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "骑手信息更新成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "骑手信息更新失败！");
            }

        }
        #endregion
        //************************************************************************************
        #region  获取未审核骑手列表
        /// <summary>
        /// 获取获取未审核骑手列表
        /// </summary>
        /// <response code="200">返回骑手列表信息</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Rider>>), StatusCodes.Status200OK)]
        public JsonReturn GetRiderList(int pageIndex = 1, int pageSize = 15)
        {
            var result = service.GetRiders(o=>!o.IsAccept, pageIndex, pageSize, out int pageNum);
            
            if (result.Count > 0)
            {
                return new JsonReturn<List<Rider>>(result, pageNum, "返回获取未审核骑手列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
            }
        }
        #endregion
        //************************************************************************************
        #region   骑手审核
        /// <summary>
        /// 骑手审核,由平台管理员调用
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <returns></returns>
        [HttpPut]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<List<int>>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderApplyCheck(int[] riderid)
        {
            List<int> passnum = new List<int>() { };
            //传递数组空,获取全部未审核骑手
            if (riderid.Count() < 1)
            {
                riderid = service.GetRiderIDs();
            }
            foreach (var id in riderid)
            {
                //获取骑手
                var rider = service.GetRider(id);
                if (rider != null && !rider.IsAccept)
                {
                    var temp = await service.RiderCheck(id);
                    //完成审核
                    if (temp)
                    {
                        passnum.Append(id);
                    }
                }
            }
            return new JsonReturn<List<int>>(passnum, passnum.Count, "已通过骑手审核的列表");
        }
        #endregion
        //************************************************************************************
        #region  获取骑手对应订单的定位数据
        /// <summary>
        /// 获取骑手对应订单的定位数据
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <param name="riderid">骑手id</param>
        /// <response code="200">返回骑手对应订单的定位数据</response>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<RiderPoint>), StatusCodes.Status200OK)]
        public JsonReturn GetRiderAccept(int orderid,int riderid)
        {
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "输入订单不存在！");
            var rider = service.GetRider(riderid);
            if(rider==null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "输入骑手不存在！");
            //计算距离
            var distance = (int)CommonClass.Distance(delivery.Business.UserPoint, rider.UserPoint);
            var totaldistance = distance + (int)CommonClass.Distance(rider.UserPoint, delivery.Business.UserPoint);
            var distancetime = distance / 500;
            var totaltime = totaldistance / 500;
            var result = new RiderPoint()
            {
                OrderId = delivery.OrderId,
                ToShopDistance = distance,
                TotalDistance = totaldistance,
                ToShopTime = distancetime,
                TotalTime = totaltime,
                Point=rider.UserPoint
            };
            return new JsonReturn<RiderPoint>(result, 1, "返回骑手对应订单的定位数据");

        }
        #endregion
        //************************************************************************************
        #region  上报保存骑手坐标
        /// <summary>
        /// 上报保存骑手坐标
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <param name="point">坐标</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> SaveRiderPoint(int riderid, Point point)
        {
            var data = new double[] { point.Longti, point.Lati };
            var result = await service.SavePoint(riderid, data);
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "保存成功！");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "保存失败！");
            }
        }
        #endregion
        //************************************************************************************
        #region  骑手抢单，需要传递accesstoken
        /// <summary>
        /// 骑手抢单，需要传递accesstoken
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <response code="200">返回接单成功或者失败信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderRecive(int orderid)
        {
            //获取骑手
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var rider = service.GetRider(uid);
            if (rider == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "该骑手未开通过本业务，不能接单");
            }
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            if (delivery.State!=DeliveryState.WaitRider) return new JsonReturn(EnumJsonReturnStatus.Fail, "此单已经已经不是待抢单状态，下次要抓紧哦。");

            var result=await service.RiderRevice(rider, delivery);
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "骑手接单成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }

        }
        #endregion
        //************************************************************************************
        #region  骑手取消订单
        /// <summary>
        /// 骑手取消订单
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <response code="200">返回成功或者失败信息</response>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderCancel(int orderid)
        {
            //获取派单
            var delivery = service.GetDelivery(orderid);
            //检查派单
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            if (delivery.State != DeliveryState.Delivered) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单不是已接单未发货状态，不可取消。");
            //取消服务
            var result = await service.RiderCancel(delivery);
            //返回结果
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "骑手取消订单成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }

        }
        #endregion
        #region  骑手送达标记
        /// <summary>
        /// 骑手送达标记
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <response code="200">返回送达成功或者失败信息</response>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderComplete(int orderid)
        {
            //获取派单
            var delivery = service.GetDelivery(orderid);
            //检查派单
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            //送达标记服务
            var result = await service.RiderComplete(delivery);
            //返回结果
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "骑手送达标记成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }
        }
        #endregion
        //************************************************************************************
        //商户接口
        //************************************************************************************
        #region  商家接单,需要传递accesstoken
        /// <summary>
        /// 商家接单,需要传递accesstoken
        /// </summary>
        /// <param name="orderid">嗨派猫订单id</param>
        /// <response code="200">返回接单成功或者失败信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn<Delivery>), StatusCodes.Status200OK)]
        public async Task<JsonReturn> BusinessRecive(int orderid)
        {
            var uid = Request.HttpContext.Items["Uid"].ToString();
            var delivery = service.GetDelivery(orderid);
            if (delivery != null) return new JsonReturn(EnumJsonReturnStatus.Fail, "该订单已经接单");
            //
            
             //添加派单
            var result = await service.AddDelivery(orderid,uid);
            if (result == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无该订单的记录");
            }
            else if (result.ID>0)
            {
                return new JsonReturn<Delivery>(result, 1, "商家接单成功！");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "商家接单失败");
            }
        }
        #endregion
        //************************************************************************************
        #region  商家定向骑手发布派单
        /// <summary>
        /// 商家定向骑手发布派单
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <param name="ids">骑手id列表</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> BusinessRePush(int orderid, int[] ids)
        {
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "无该派单信息。");
            if (delivery.State!=DeliveryState.WaitAssigned&& delivery.State != DeliveryState.WaitRider) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单已经被接单。");
            //更新派单

            var result = await service.BusinessRePush(delivery, ids);
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "派单定向发布成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }

        }
        #endregion
        //************************************************************************************
        #region 派送要求填写
        /// <summary>
        /// 派送要求填写，默认无要求，服务费按订单获取，商户可以通过该接口修改内容,填写该资料表示商户发布了派单
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPut]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> PushInput(DeliveryPushDin input)
        {
            //获取派单
            var delivery = service.GetDelivery(input.OrderId);
            if (delivery == null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "未发现该派单。");
            }
            var ts = delivery.PushInput(input);
            //更新派单信息
            var result = await service.BusinessPushInput(delivery, ts);
            if (result)
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "派送要求填写成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "派送要求填写失败！");
            }

        }
        #endregion
        //************************************************************************************
        #region  商家向指定公里内所有骑手发布派单
        /// <summary>
        /// 商家向指定公里内所有骑手发布派单，初始3km，无骑手，按每次1km递增，截止15公里
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> BusinessToPush(int orderid)
        {
           
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "无该派单信息。");
            if (delivery.State != DeliveryState.WaitAssigned && delivery.State != DeliveryState.WaitRider) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单已经被接单。");
            //更新派单
            try
            {
                var ids =new int[]{ };
                int dis = 3;     //初始距离3km
                while (ids.Count() < 1)
                {
                    ids = service.GetRiderIDs(delivery.Business.UserPoint, dis);
                    
                    if (ids.Count() > 0)
                    {
                        await service.BusinessRePush(delivery, ids);
                        break;
                    }
                    dis = dis + 1;
                    if (dis>15)
                    {
                        return new JsonReturn(EnumJsonReturnStatus.Fail, "因为15公里内无骑手，派单发布失败");
                    }
                   
                }
                //返回结果
                return new JsonReturn(EnumJsonReturnStatus.OK, $"已向{dis}公里内的{ids.Count()}个骑手发布派单。");
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, "派单发布失败");
            }
        }
        #endregion
        //************************************************************************************
        #region  商家发货,需要传递accesstoken
        /// <summary>
        /// 商家发货,需要传递accesstoken
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <response code="200">返回发货成功或者失败信息</response>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> BusinessSend(int orderid)
        {

            //获取派单
            var delivery = service.GetDelivery(orderid);
            //检查派单
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            if (delivery.State != DeliveryState.Delivered) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单不是待发货状态，不可发货。");
            //发货服务
            var result = await service.BusinessComplete(delivery);
            //返回结果
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "商家发货成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }

        }
        #endregion
        //************************************************************************************
        #region  获取推荐骑手的派单列表
        /// <summary>
        /// 获取推荐骑手的派单列表
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Delivery>>), StatusCodes.Status200OK)]
        public JsonReturn GetInviteRiderDeliverys(int riderid, int pageIndex = 1, int pageSize = 15)
        {
            var result = service.GetDeliveryList(o => o.Rider.ID == riderid, pageIndex, pageSize, out int pageNum);
           
            if (result.Count > 0)
            {
                return new JsonReturn<List<Delivery>>(result, pageNum, "返回骑手派单列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无骑手派单记录");
            }
        }
        #endregion
        //************************************************************************************
        #region  获取推荐骑手的列表
        /// <summary>
        /// 获取推荐骑手列表
        /// </summary>
        /// <param name="businessid">商户id</param>
        /// <param name="pageIndex">页数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Rider>>), StatusCodes.Status200OK)]
        public JsonReturn GetInviteRiders(int businessid,int pageIndex,int pageSize)
        {
            var result = service.GetRiders(o => o.InViteBusinessID == businessid,pageIndex,pageSize,out int pageNum);
            
            if (result!=null&&result.Count > 0)
            {
                return new JsonReturn<List<Rider>>(result, pageNum, "返回骑手列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无骑手记录");
            }
        }
        #endregion
        //************************************************************************************
        //顾客接口
        //************************************************************************************
        #region  顾客收货确认
        /// <summary>
        /// 顾客收货确认
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <returns></returns>
        [HttpPost]
        [TokenInputActionFilter]
        [TypeFilter(typeof(UserAuthenActionFilter))]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> CustomerAccept(int orderid)
        {

            //获取派单
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            if (delivery.State != DeliveryState.Received&& delivery.State != DeliveryState.Dispatch) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单不是送达或者发货状态，不可确认。");
            //处理派单记账
            var result = await service.CustomerAccept(delivery);

            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "顾客收货成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.Fail, result);
            }

        }
        #endregion
        //************************************************************************************
        #region  提交对骑手的评价
        /// <summary>
        /// 顾客提交对骑手的评价
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <param name="evaluate">评价分数</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(JsonReturn), StatusCodes.Status200OK)]
        public async Task<JsonReturn> RiderEvaluate(int orderid, EvaluateContent evaluate)
        {

            //获取派单
            var delivery = service.GetDelivery(orderid);
            if (delivery == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "没有该派单信息");
            if (delivery.State == DeliveryState.WaitAssigned && delivery.State == DeliveryState.WaitRider) return new JsonReturn(EnumJsonReturnStatus.NoFound, "派单还没有确定骑手，无法对骑手评价。");
            //评价提交
            var result = await service.RiderEvaluate(delivery, evaluate);
            if (result == "OK")
            {
                return new JsonReturn(EnumJsonReturnStatus.OK, "骑手评价成功");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "骑手评价失败");
            }

        }
        #endregion
        //************************************************************************************
        //公共接口
        //************************************************************************************
        #region  获取派送单明细
        /// <summary>
        /// 获取派送单明细
        /// </summary>
        /// <param name="id">订单id</param>
        /// <response code="200">返回派单明细信息</response>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(JsonReturn<Delivery>), StatusCodes.Status200OK)]
        public JsonReturn GetDeliveryDetailed(int id)
        {
            //查询记录
            var temp = service.GetDelivery(id);
            if(temp==null)
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound,"无该派单信息！");
            }
            //返回结果
            return new JsonReturn<Delivery>(temp, 1, "返回派送单明细");
        }
        #endregion
        //************************************************************************************
        #region  获取骑手的接单列表
        /// <summary>
        /// 获取骑手已经的接单列表
        /// </summary>
        /// <param name="riderid">骑手id</param>
        /// <param name="state">派单状态,0显示全部</param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<Delivery>>), StatusCodes.Status200OK)]
        public JsonReturn GetRiderAcceptList(int riderid, DeliveryState state=DeliveryState.Delivered, int pageIndex = 1, int pageSize = 15)
        {
            Expression<Func<Delivery, bool>> condstr = null;
            if (state == 0)
            {
                condstr = o => o.Rider.ID == riderid;
            }
            else
            {
                condstr = o => o.State == state && o.Rider.ID == riderid;
            }
            var result = service.GetDeliveryList(condstr, pageIndex, pageSize, out int pageNum);
            if (result!=null&&result.Count > 0)
            {
                return new JsonReturn<List<Delivery>>(result, pageNum, "返回骑手接单列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无骑手接单记录");
            }
        }
        #endregion
        //************************************************************************************
        #region  获取可接单列表
        /// <summary>
        /// 获取骑手可接单列表
        /// </summary>
        /// <returns></returns>
        /// <param name="riderid">骑手id</param>
        /// <param name="sort">排序类别，0-默认排序，1-发布时间排序(最新时间在前)，2-总距离排序（最短距离在前），3-总时间排序（最短时间在前），4-服务费排序（最多费用在前）</param>
        /// <param name="pageIndex">页数</param>
        /// <param name="pageSize">每页记录</param>
        [HttpGet]
        [ProducesResponseType(typeof(JsonReturn<List<RiderDelivery>>), StatusCodes.Status200OK)]
        public JsonReturn GetCanAcceptList(int riderid,int sort=0,int pageIndex=1, int pageSize=15)
        {
            if(riderid==0)
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "骑手id需要输入！");
            }
            var rider = service.GetRider(riderid);
            if (rider == null) return new JsonReturn(EnumJsonReturnStatus.NoFound, "输入骑手不存在！");
            //读取列表
            var temp = service.GetDeliveryList(o => o.State == DeliveryState.WaitRider , pageIndex, pageSize, out int pageNum);
            //转换列表
            List<RiderDelivery> result = new List<RiderDelivery>();
            foreach(var mm in temp)
            {
                //计算距离
                var toshopdistance = (int)CommonClass.Distance(mm.Business.UserPoint, rider.UserPoint);
                var totaldistance = toshopdistance + (int)CommonClass.Distance(rider.UserPoint, mm.Business.UserPoint);
                var toshoptime = toshopdistance / 500;
                var totaltime = totaldistance / 500;
                var nn = new RiderDelivery()
                {
                    ID = mm.ID,
                    OrderCode = mm.OrderCode,
                    Business = mm.Business,
                    Customer = mm.Customer,
                    Goods = mm.Goods,
                    OrderId = mm.OrderId,
                    Cost = mm.Cost,
                    Demand = mm.Demand,
                    NeedDeliveredTime = mm.NeedDeliveredTime,
                    PushTime = mm.PushTime,
                    ToShopDistance = toshopdistance,
                    ToShopTime =toshoptime,
                    TotalDistance = totaldistance,
                    TotalTime = totaltime
                };
                result=result.Append(nn).ToList();
            }
            //排序方式
            switch(sort)
            {
                default:
                    break;
                case 1:
                    result=result.OrderByDescending(o =>DateTime.Parse(o.PushTime)).ToList();
                    break;
                case 2:
                    result = result.OrderBy(o=>o.TotalDistance).ToList();
                    break;
                case 3:
                    result = result.OrderBy(o => o.TotalTime).ToList();
                    break;
                case 4:
                    result = result.OrderByDescending(o => o.Cost).ToList();
                    break;
            }
           
            if (result.Count > 0)
            {
                return new JsonReturn<List<RiderDelivery>>(result, pageNum, "返回可接单列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无可接单记录");
            }
        }
        #endregion
        //************************************************************************************
          //内部过程
        //************************************************************************************
        #region  处理过期顾客没确认单据
        /// <summary>
        /// 处理过期顾客没确认单据
        /// </summary>
        private async Task DeliveryPass()
        {
            //获取过期顾客没确认单据
            var accounts = service.GetDeliveryList(o=>(o.AccountTime==null||o.AccountTime=="")&&DateTime.Parse(o.AccetpGoodsTime).AddDays(1)<DateTime.Now);
            foreach (var account in accounts)
            {
                //处理派单记账
                var result = await service.CustomerAccept(account);

            }
        }
        #endregion
        //************************************************************************************
     
    }
}