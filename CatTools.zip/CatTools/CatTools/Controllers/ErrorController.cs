﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CarTools.Shares;
using log4net;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CatTools.Controllers
{
    [EnableCors("any")]               //跨域
    [ApiController]
    public class ErrorController : ControllerBase
    {
        /// <summary>
        /// 错误处理
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("/error")]
        public JsonReturn Error()
        {
            var feature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            var ex = feature?.Error;

            var exceptpe = ex.GetType().ToString();
            if (exceptpe == "System.NullReferenceException")
            {
                return new JsonReturn(EnumJsonReturnStatus.TokenFail, "输入数据出现不允许的空值！");
            }
            else if (exceptpe == "System.AggregateException")
            {
                return new JsonReturn(EnumJsonReturnStatus.ValidationFail, "调用的网址暂时错误！");
            }
            else
            {
                //保存记录到日志
                ILog log = LogManager.GetLogger(Startup.Repository.Name, "日志：");
                //记录到日志
                log.Error("错误信息： " + ex.Message);
                int index = ex.StackTrace.LastIndexOf(":line ");
                log.Error("错误定位： " + ex.StackTrace.Substring(0, index + 12));
                return new JsonReturn(EnumJsonReturnStatus.ServiceError, ex.Message);
            }
        }
    }
}