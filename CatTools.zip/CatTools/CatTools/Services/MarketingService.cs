﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    public interface IMarketingService
    {
        /// <summary>
        /// 添加新的创业者
        /// </summary>
        /// <param name="level">级别</param>
        /// <param name="userid">发放人</param>
        /// <returns></returns>
        Task<Entrepreneur> AddEntrepreneur(EntrepreneurLevel level, int userid);
        /// <summary>
        /// 领取
        /// </summary>
        /// <param name="kind"></param>
        /// <param name="userid"></param>
        /// <param name="takeid"></param>
        /// <returns></returns>
        Task<bool> TakeGift(TakeKind kind, int userid, int takeid);
        /// <summary>
        /// 获取创业者信息
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        Entrepreneur GetEntrepreneur(int userid);
        /// <summary>
        /// 创业者升级
        /// </summary>
        /// <param name="level"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        Task<bool> Upgrade(EntrepreneurLevel level, int userid);
        /// <summary>
        /// 获取创业者的领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="userid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        List<TakeMarketing> GetListByUserid(out int total,int userid, int PageIndex, int PageSize);
        /// <summary>
        /// 获取领取人的领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="takeid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        List<TakeMarketing> GetListByTakeid(out int total,int takeid, int PageIndex, int PageSize);
        /// <summary>
        /// 支付标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> PayMark(int id);
    }
    /// <summary>
    /// 营销服务
    /// </summary>
    public class MarketingService: IMarketingService
    {
        private readonly IRepository<Entrepreneur> entres;
        private readonly IRepository<TakeMarketing> takes;
        private readonly IRecnoService recnos;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="config"></param>
        /// <param name="_recnos"></param>
        public MarketingService(IConfiguration config,IRecnoService _recnos)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            recnos = _recnos;
            entres = new MongoRespository<Entrepreneur>(new MongoDBContext<Entrepreneur>(dbName, dbconn));
            takes = new MongoRespository<TakeMarketing>(new MongoDBContext<TakeMarketing>(dbName, dbconn));
        }
        /// <summary>
        /// 添加新的创业者
        /// </summary>
        /// <param name="level">创业者级别</param>
        /// <param name="userid">创业者编号</param>
        /// <returns></returns>
        public async Task<Entrepreneur> AddEntrepreneur(EntrepreneurLevel level, int userid)
        {
            //数据提交
            try
            {
                var recno = await recnos.Get("创业者序号");
                var temp = new Entrepreneur(level, userid,recno);
                await entres.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 礼品领取
        /// </summary>
        /// <param name="kind">类别</param>
        /// <param name="id">发放人</param>
        /// <param name="takeid">领取人</param>
        /// <returns></returns>
        public async Task<bool> TakeGift(TakeKind kind,int id, int takeid)
        {
            //查询主表消息
            Expression<Func<Entrepreneur, bool>> expression = s => s.ID==id;
            var temp= entres.GetQueryable(expression).FirstOrDefault();
            if (temp!=null&&temp.Take(kind, takeid))
            {
                try
                {
                    //更新主表消息
                    await entres.UpdateAsync(temp);
                    var temp1 = new TakeMarketing(kind, id, takeid);
                    //保存领取表
                    await takes.AddAsync(temp1);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 获取创业者消息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Entrepreneur GetEntrepreneur(int id)
        {
            try
            {
                Expression<Func<Entrepreneur, bool>> condstr = s => s.ID == id;
                var result = entres.GetQueryable(condstr).FirstOrDefault();
                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 创业者升级
        /// </summary>
        /// <param name="level"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public async Task<bool> Upgrade(EntrepreneurLevel level, int userid)
        {
            Expression<Func<Entrepreneur, bool>> condstr = s => s.UserId == userid;
            var temp = entres.GetQueryable(condstr).FirstOrDefault();
            if(temp==null)
            {
                return false;
            }
            temp.Upgrade(level);
            try
            {
                //更新主表消息
                await entres.UpdateAsync(temp);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 支付标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> PayMark(int id)
        {
            var filter = Builders<Entrepreneur>.Filter.Eq("ID", id);
            var update = Builders<Entrepreneur>.Update.Set("IsPay", true);
            try
            {
                await entres.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 返回指定创业者的领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<TakeMarketing> GetListByUserid(out int total, int id,int PageIndex,int PageSize)
        {
            //排序条件
            Expression<Func<TakeMarketing, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<TakeMarketing, bool>> condstr = s => s.ID == id;
            var listtemp = takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total =takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
        /// <summary>
        /// 返回指定领取者的领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<TakeMarketing> GetListByTakeid(out int total, int uid, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<TakeMarketing, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<TakeMarketing, bool>> condstr = s => s.TakeId == uid;
            var listtemp = takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
    }
}
