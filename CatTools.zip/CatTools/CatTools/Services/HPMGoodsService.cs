﻿using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 
    /// </summary>
    public interface IHPMGoodsService
    {
        /// <summary>
        /// 添加商品
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="price"></param>
        /// <param name="businessid"></param>
        /// <param name="uid"></param>
        /// <param name="disprice"></param>
        /// <param name="time"></param>
        /// <returns></returns>
        Task<HPMGoods> Add(int id, string name, int price, int businessid, int uid, int disprice, DateTime time);
        /// <summary>
        /// 修改商品
        /// </summary>
        /// <param name="id">商品id</param>
        /// <param name="disprice">折扣价</param>
        /// <param name="endtime">截止期</param>
        /// <returns></returns>
        Task<bool> Update(int id, int disprice, DateTime endtime);
        /// <summary>
        /// 删除商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> Delete(int id);
        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        HPMGoods Get(int id);
        /// <summary>
        /// 获取商品列表
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <returns>用户id为0返回全部商品</returns>
        List<HPMGoods> GetList(int uid=0);
        /// <summary>
        ///  验证所属用户
        /// </summary>
        /// <param name="goods">商品</param>
        /// <param name="uid">用户id</param>
        /// <returns>返回结果</returns>
        string CheckUser(HPMGoods goods, int uid);
        /// <summary>
        /// 是否检查商品
        /// </summary>
        /// <returns></returns>
        bool IsCheck();
    }
    /// <summary>
    /// 
    /// </summary>
    public class HPMGoodsService : IHPMGoodsService
    {
        private readonly IRepository<HPMGoods> oper;
        //是否验证商品
        private readonly int goodsvalid=0;
        public HPMGoodsService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var valid= config.GetConnectionString("GoodsValid");
            if(valid=="1")
            {
                goodsvalid = 1;
            }
            var dbName = "ToolsDb";
            oper = new MongoRespository<HPMGoods>(new MongoDBContext<HPMGoods>(dbName, dbconn));
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="price"></param>
        /// <param name="businessid"></param>
        /// <param name="uid"></param>
        /// <param name="disprice"></param>
        /// <param name="time"></param>
        /// <returns></returns>
        public async Task<HPMGoods> Add(int id, string name, int price, int businessid, int uid, int disprice, DateTime time)
        {
            //数据提交
            try
            {
                var result = new HPMGoods(id, name, price,businessid, uid, disprice, time);
                await oper.AddAsync(result);
                return result;
            }
            catch
            {
                return default(HPMGoods);
            }
        }
        /// <summary>
        /// 验证所属用户
        /// </summary>
        /// <param name="goods">商品</param>
        /// <param name="uid">用户id</param>
        /// <returns>返回0不存在1用户不符2有效</returns>
        public string CheckUser(HPMGoods goods, int uid)
        {

            //检查商品id
            if(goods.GoodId<1)
            {
                return "商品id无效,无需验证";
            }
            //检查用户id
            if(uid<1)
            {
                return "用户id无效，无需验证";
            }
            //验证所属用户
            if(goods.UserId==uid)
            {
                return "OK";
            }
            else
            {
                return $"商品{goods.GoodId}所属用户不是{uid}";
            }
        }
        /// <summary>
        /// 判断是否检查商品
        /// </summary>
        /// <returns></returns>
        public bool IsCheck()
        {
            //检查验证开关，如果关闭，直接返回ok
            if (goodsvalid == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> Delete(int id)
        {
            try
            {
                var entry = oper.Get(o => o.GoodId == id);
                await oper.RemoveAsync(entry);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public HPMGoods Get(int id)
        {
            try
            {
                var entry = oper.Get(o => o.GoodId == id);
                return entry;
            }
            catch
            {
                return default(HPMGoods);
            }
        }
        /// <summary>
        /// 获取列表
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public List<HPMGoods> GetList(int uid = 0)
        {
            if (uid == 0)
            {
                var result = oper.GetList(o => true, o => o.EndTime);
                return result;
            }
            else
            {
                var result = oper.GetList(o => o.UserId == uid, o => o.EndTime);
                return result;
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="id"></param>
        /// <param name="disprice"></param>
        /// <param name="endtime"></param>
        /// <returns></returns>
        public async Task<bool> Update(int id,int disprice,DateTime endtime)
        {
            var filter = Builders<HPMGoods>.Filter.Eq("GoodId", id);
            var update = Builders<HPMGoods>.Update.Set("DisPrice", disprice).Set("EndTime", endtime);

            try
            {
                await oper.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
