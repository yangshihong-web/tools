﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    public interface IRiderService
    {
        /// <summary>
        /// 骑手注册
        /// </summary>
        /// <param name="register"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        Task<Rider> AddRider(RiderApplyDto register,int uid);
        /// <summary>
        /// 修改骑手信息
        /// </summary>
        /// <param name="rider"></param>
        /// <param name="properts"></param>
        /// <returns></returns>
        Task<bool> UpdateRider(Rider rider, List<string> properts);
        /// <summary>
        /// 获取骑手明细
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <returns></returns>
        Rider GetRider(string uid);
        /// <summary>
        /// 获取骑手明细
        /// </summary>
        /// <param name="id">骑手id</param>
        /// <returns></returns>
        Rider GetRider(int id);
        /// <summary>
        ///商家添加派送单
        /// </summary>
        /// <param name="orderid"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        Task<Delivery> AddDelivery(int orderid, string uid);
        /// <summary>
        /// 获取骑手列表（通过数组）
        /// </summary>
        /// <param name="IDs">骑手数组</param>
        /// <returns></returns>
        List<Rider> GetRiders(int[] IDs);
        /// <summary>
        /// 获取骑手列表(条件)
        /// </summary>
        /// <returns></returns>
        List<Rider> GetRiders(Expression<Func<Rider, bool>> condstr, int pageIndex, int pageSize, out int totalpage);
        /// <summary>
        /// 获取骑手id数组(商户dis公里内)
        /// </summary>
        /// <param name="businesspoint"></param>
        /// <param name="dis">距离</param>
        /// <returns></returns>
        int[] GetRiderIDs(double[] businesspoint,int dis);
        /// <summary>
        /// 获取全部未审核的骑手id数组
        /// </summary>
        /// <returns></returns>
        int[] GetRiderIDs();
        /// <summary>
        /// 获取派送单明细
        /// </summary>
        /// <param name="orderid">订单号</param>
        /// <returns></returns>
        Delivery GetDelivery(int orderid);
        /// <summary>
        /// 获取派送单列表
        /// </summary>
        /// <param name="condstr">条件</param>
        /// <param name="pageIndex">页数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <param name="totalpage">总页数</param>
        /// <returns></returns>
        List<Delivery> GetDeliveryList(Expression<Func<Delivery, bool>> condstr, int pageIndex, int pageSize, out int totalpage);
        /// <summary>
        /// 获取派单列表，不分页
        /// </summary>
        /// <param name="condstr"></param>
        /// <returns></returns>
        List<Delivery> GetDeliveryList(Expression<Func<Delivery, bool>> condstr);
        /// <summary>
        /// 骑手接单
        /// </summary>
        /// <param name="rider">骑手</param>
        /// <param name="delivery">订单;</param>
        /// <returns></returns>
        Task<string> RiderRevice(Rider rider, Delivery delivery);
        /// <summary>
        /// 商家发货
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        Task<string> BusinessComplete(Delivery delivery);
        /// <summary>
        /// 骑手送达
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        Task<string> RiderComplete(Delivery delivery);
        /// <summary>
        /// 顾客确认
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        Task<string> CustomerAccept(Delivery delivery);
        /// <summary>
        /// 骑手申请审核
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> RiderCheck(int id);
         /// <summary>
        /// 获取账单明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        AccountDetail GetAccountDetail(int id);
        /// <summary>
        /// 获取指定用户的账单列表
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="begintime"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalpage"></param>
        /// <returns></returns>
        List<AccountDetail> GetAccountList(int uid, DateTime begintime, int pageIndex, int pageSize, out int totalpage);
        /// <summary>
        /// 骑手评价
        /// </summary>
        /// <param name="delivery">派单</param>
        /// <param name="evaluate">评价分数</param>
        /// <returns></returns>
        Task<string> RiderEvaluate(Delivery delivery, EvaluateContent evaluate);
        /// <summary>
        /// 商家定向发布派单
        /// </summary>
        /// <param name="delivery"></param>
        /// <param name="riderids"></param>
        /// <returns></returns>
        Task<string> BusinessRePush(Delivery delivery, int[] riderids);
        /// <summary>
        /// 保存骑手坐标
        /// </summary>
        /// <param name="id">骑手id</param>
        /// <param name="data">当前坐标</param>
        /// <returns></returns>
        Task<bool> SavePoint(int id, double[] data);
        /// <summary>
        /// 商户填写派送要求
        /// </summary>
        /// <param name="delivery"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        Task<bool> BusinessPushInput(Delivery delivery, List<string> list);
        /// <summary>
        /// 骑手取消接单
        /// </summary>
        /// <param name="delivery">派单</param>
        /// <returns></returns>
        Task<string> RiderCancel(Delivery delivery);
        /// <summary>
        /// 重复推送
        /// </summary>
        /// <returns></returns>
        Task PushMess();
    }
    
    public class RiderService : IRiderService
    {
        delegate bool PushTo(Message data);
        private readonly IRepository<Rider> riders;
        private readonly IRepository<Delivery> deliverys;
        private readonly IRepository<Recno> recnos;
        private readonly IRepository<Message> messages;
        private readonly IRepository<AccountDetail> account;
        private readonly IRepository<NoticCache> notics;

        Dictionary<MessageSendModel, PushTo> pushdic = new Dictionary<MessageSendModel, PushTo>(); 
       
        //
        private readonly IClientService client;
      
        public RiderService(IConfiguration config, IClientService _client)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
  
            riders = new MongoRespository<Rider>(new MongoDBContext<Rider>(dbName, dbconn));
            deliverys = new MongoRespository<Delivery>(new MongoDBContext<Delivery>(dbName, dbconn));
            recnos = new MongoRespository<Recno>(new MongoDBContext<Recno>(dbName, dbconn));
            messages = new MongoRespository<Message>(new MongoDBContext<Message>(dbName, dbconn));
            account = new MongoRespository<AccountDetail>(new MongoDBContext<AccountDetail>(dbName, dbconn));
            notics = new MongoRespository<NoticCache>(new MongoDBContext<NoticCache>(dbName, dbconn));

            this.client = _client;
            pushdic.Add(MessageSendModel.Aurora, this.PushAurora);
            pushdic.Add(MessageSendModel.Sms,this.PushSms);
            pushdic.Add(MessageSendModel.WeChat, this.PushWeChat);
        }
       
        #region 获取最新序号
        /// <summary>
        /// 获取最新序号
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private async Task<int> GetNumber(int id)
        {
            Expression<Func<Recno, bool>> findstr = f => f.ID == id;

            try
            {
                var result = recnos.GetQueryable(findstr).FirstOrDefault();
                if (result == null)
                {
                    try
                    {
                        await recnos.AddAsync(new Recno(id));
                        return 1;
                    }
                    catch
                    {
                        return 0;
                    }
                }
                else
                {
                    var mm = result.Number + 1;
                    var filter = Builders<Recno>.Filter.Eq("ID", id);
                    var update = Builders<Recno>.Update.Set("Number", mm);
                    try
                    {
                        await recnos.UpdateAsync(filter, update);
                        return mm;
                    }
                    catch
                    {
                        return 0;
                    }
                }
            }
            catch
            {
                try
                {
                    await recnos.AddAsync(new Recno(id));
                    return 1;
                }
                catch
                {
                    return 0;
                }
            }

        }
        #endregion
        #region 骑手申请审核
        /// <summary>
        /// 骑手申请审核
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> RiderCheck(int id)
        {

            var filter = Builders<Rider>.Filter.Eq("ID", id);
            var update = Builders<Rider>.Update.Set("IsAccept", true);
            try
            {
                await riders.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
            
        }
        #endregion
        #region  添加骑手
        /// <summary>
        /// 添加骑手
        /// </summary>
        /// <param name="register"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        public async Task<Rider> AddRider(RiderApplyDto register, int uid)
        {
            var riderid = await GetNumber(1);      //获取新的序号,1的类别代表骑手
            //数据提交
            try
            {
                var temp = new Rider(register, riderid, uid);
                await riders.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        #endregion
        #region 修改骑手信息
        /// <summary>
        /// 修改骑手信息
        /// </summary>
        /// <param name="rider"></param>
        /// <param name="properts"></param>
        /// <returns></returns>
        public async Task<bool> UpdateRider(Rider rider, List<string> properts)
        {
            //数据提交
            try
            {
                await riders.UpdateAsync(rider, properts);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region 获取骑手明细
        /// <summary>
        /// 获取骑手明细
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <returns></returns>
        public Rider GetRider(string uid)
        {
            Expression<Func<Rider, bool>> findstr = o => o.UserId == int.Parse(uid);
            try
            {
                var result = riders.Get(findstr);

                return result;
            }
            catch
            {
                return null;
            }
        }
        #endregion
        #region 获取骑手明细
        /// <summary>
        /// 获取骑手明细
        /// </summary>
        /// <param name="id">骑手id</param>
        /// <returns></returns>
        public Rider GetRider(int id)
        {
            Expression<Func<Rider, bool>> findstr = o => o.ID == id;
            try
            {
                var result = riders.Get(findstr); 

                return result;
            }
            catch
            {
                return null;
            }
        }
        #endregion
        #region 通过数组 获取骑手列表
        /// <summary>
        ///通过数组 获取骑手列表
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        public List<Rider> GetRiders(int[] IDs)
        {
            var temp = riders.GetQueryable(o => IDs.Contains(o.ID) && o.IsAccept).ToList();
            return temp;
        }
        #endregion
        #region 获取骑手列表(条件)
        /// <summary>
        /// 获取骑手列表(条件)
        /// </summary>
        /// <returns></returns>
        public List<Rider> GetRiders(Expression<Func<Rider, bool>> condstr, int pageIndex, int pageSize, out int totalpage)
        {
            try
            {
                //排序条件
                Expression<Func<Rider, DateTime>> orderstr = item => item.CreateTime;

                var listtemp = riders.GetListPage(condstr, orderstr, pageIndex, pageSize);
                totalpage = riders.GetTotalPage(condstr, pageSize);
                return listtemp;
            }
            catch
            {
                totalpage = 0;
                return null;
            }
        }
        #endregion
        #region 获取指定距离（公里）内骑手数组
        /// <summary>
        /// 获取指定距离（公里）内骑手数组
        /// </summary>
        /// <returns></returns>
        public int[] GetRiderIDs(double[] businesspoint,int dis)
        {
            var position = DistanceHelper.FindNeighPosition(businesspoint[0], businesspoint[1], dis);
            try
            {

                var temp = riders.GetQueryable(o=>o.IsAccept&&o.UserPoint[0]<=position.MaxLng&& o.UserPoint[0] >= position.MinLng&& o.UserPoint[1] >= position.MinLat&&o.UserPoint[1] <= position.MaxLat).Select(o =>o.ID).ToList().ToArray();
                return temp;
            }
            catch
            {
                return new int[] { };
            }
        }
        #endregion
        #region  获取全部未审核的骑手数组
        /// <summary>
        /// 获取全部未审核的骑手数组
        /// </summary>
        /// <returns></returns>
        public int[] GetRiderIDs()
        {
            try
            {

                var temp = riders.GetQueryable(o => !o.IsAccept).Select(o => o.ID).ToList().ToArray();
                return temp;
            }
            catch
            {
                return new int[] { };
            }
        }
        #endregion
        #region 商家接单（派发单添加）
        /// <summary>
        /// 商家接单（派发单添加）
        /// </summary>
        /// <param name="orderid">订单id</param>
        /// <param name="uid"></param>
        /// <returns></returns>
        public async Task<Delivery> AddDelivery(int orderid,string uid)
        {
            var order = client.GetOrderData(orderid);
            if (order == null) return null;
            //转换商品数组
            var list = new GoodsMess[order.Goods.Count()];
            int index = 0;
            foreach (var mm in order.Goods)
            {
                var mp = new GoodsMess()
                {
                    Count = mm.Count,
                    Name = mm.Name,
                    Picture = mm.Picture,
                    Price = mm.Price
                };
                list[index] = mp;
                index++;
            };
            //计算距离
            int dist = (int)CommonClass.Distance(order.Business.Point, order.Coordinate);
            //计算费用
            var cost = AcountCost(dist);
            //派单数据
            var data = new DeliveryInput()
            {
                Business = new BusinessMess()
                {
                    ID = order.Business.Id,
                    Address = order.Business.Address,
                    Name = order.Business.Name,
                    Phone = order.Business.Phone,
                    UserId = int.Parse(uid),
                    UserPoint = order.Business.Point
                },
                Customer = new CustomerMess()
                {
                    ID = order.Buyer.Id,
                    Name = order.Buyer.Name,
                    Phone = order.Address.Phone,
                    Address = order.Address.Address,
                    UserPoint = order.Coordinate,
                    Model = (MessageSendModel)order.Client                            //从订单里获取
                },
                OrderId = order.Id,
                OrderCode = order.Code,
                Goods = list,
                Cost = cost                               //(int)order.Freight //从订单获取
            };
            //数据提交
            var id = await GetNumber(2);      //获取新的序号,2的类别派单id
            //数据提交
            try
            {
                var result = new Delivery(id, data);
                await deliverys.AddAsync(result);
                //提交状态
                var notic = new DeliveryNoticeDto()
                {
                    OrderCode = result.OrderCode,                           //订单号
                    State = (int)DeliveryState.WaitAssigned,                //状态
                    ExpressName = "无",                                       //快递员姓名
                    ExpressPhone = "0",                                      //快递员电话
                    ExpressId = 0
                };
                var noticresult = client.DeliveryNotice(notic);

                if (!noticresult)
                {
                    return default(Delivery);
                }
               return result;
            }
            catch
            {
                return default(Delivery);
            }
        }
        #endregion
      
        #region 获取派单列表
        /// <summary>
        /// 获取派单列表
        /// </summary>
        /// <param name="condstr">筛选条件</param>
        /// <param name="pageIndex">获取页数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <param name="totalpage">总页数</param>
        /// <returns></returns>
        public List<Delivery> GetDeliveryList(Expression<Func<Delivery, bool>> condstr,int pageIndex,int pageSize,out int totalpage)
        {
            //排序条件
            Expression<Func<Delivery, DateTime>> orderstr = item => item.CreateTime;
            
            var listtemp = deliverys.GetListPage(condstr, orderstr, pageIndex, pageSize);
            totalpage = deliverys.GetTotalPage(condstr, pageSize);
            return listtemp;
        }
        #endregion
        #region 获取派单明细
        /// <summary>
        /// 获取派单明细
        /// </summary>
        /// <param name="orderid">订单号</param>
        /// <returns></returns>
        public Delivery GetDelivery(int orderid)
        {
            Expression<Func<Delivery, bool>> findstr = f => f.OrderId == orderid;

            try
            {
                var result = deliverys.GetQueryable(findstr).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        #endregion
        #region 商家定向发布
        /// <summary>
        /// 商家定向发布
        /// </summary>
        /// <param name="delivery"></param>
        /// <param name="riderids"></param>
        /// <returns></returns>
        public async Task<string> BusinessRePush(Delivery delivery, int[] riderids)
        {
            //
            delivery.PushTime = DateTime.Now.ToString();
            delivery.State = DeliveryState.WaitRider;
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "PushTime", "State" });
            }
            catch
            {
                return "派单更新失败！";
            }
            //接收对象
            var riders=GetRiders(riderids);
            //
            foreach (var rider in riders)
            {
                var input = new MessageInput()
                {
                    Content = "尊敬的骑手：你好，有商家外卖派单,请立即抢单",
                    OrderId = delivery.OrderId,
                    TargetMess = new PushObject()
                    {
                        ID = rider.UserId,
                        Name = rider.Name,
                        Phone = rider.Phone
                    },
                    SendUid = delivery.Business.UserId,
                    Model = MessageSendModel.Aurora,
                    OrderType = EnumMessageOrderType.Takeout,
                    Target = "Rider"
                };
                //
                if(PuAll(new Message(input)))
                {
                    //已经推送
                    input.Push = true;
                }
                else
                {
                    //未推送
                    input.Push = false;
                }
                //保存信息
                await AddMessage(input);
            }
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.WaitRider,
                ExpressName = "无骑手",
                ExpressPhone = "无电话",
                ExpressId = 0
            };
            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
        #region 骑手接单
        /// <summary>
        /// 骑手接单
        /// </summary>
        /// <param name="rider">骑手</param>
        /// <param name="delivery">派单</param>
        /// <returns></returns>
        public async Task<string> RiderRevice(Rider rider, Delivery delivery)
        {
            //更新派单骑手信息
            delivery.Rider = new RiderMess()
            {
                ID = rider.ID,
                Name = rider.Name,
                Phone = rider.Phone,
                UserId = rider.UserId
            };
            delivery.RiderAccetpTime = DateTime.Now.ToString();
            delivery.State = DeliveryState.Delivered;
            //标记减免
            if (rider.InViteBusinessID==delivery.Business.ID&&rider.InViteBusinessTime<=10)
            {
                delivery.IsReduce = true;
                rider.InViteBusinessTime = rider.InViteBusinessTime + 1;
                await riders.UpdateAsync(rider);
            }
            
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "Rider", "RiderAccetpTime", "IsReduce", "State" });
            }
            catch
            {
                return "派单更新失败！";
            }
            //发送消息到队列
            var input = new MessageInput()
            {
                Content = "尊敬的商户：你好，有骑手抢到你的外派订单",
                OrderId = delivery.OrderId,
                TargetMess =new PushObject()
                {
                    ID = delivery.Business.UserId,
                    Name = delivery.Business.Name,
                    Phone = delivery.Business.Phone
                },
            
                SendUid = rider.UserId,
                Model = MessageSendModel.Aurora,
                OrderType = EnumMessageOrderType.Takeout,
                Target = "Seller"
            };
            if (PuAll(new Message(input)))
            {
                //已经推送
                input.Push = true;
            }
            else
            {
                //未推送
                input.Push = false;
            }
            //保存信息
            await AddMessage(input);

            //发送消息到队列
            input = new MessageInput()
            {
                Content = "尊敬的客户：你好，有骑手抢到你的外派订单",
                OrderId = delivery.OrderId,
                TargetMess =new PushObject()
                {
                    ID = delivery.Customer.ID,
                    Name = delivery.Customer.Name,
                    Phone = delivery.Customer.Phone
                },
                SendUid = rider.UserId,
                Model =delivery.Customer.Model,
                OrderType = EnumMessageOrderType.Takeout,
                Target = "Buyer"
            };
            if (PuAll(new Message(input)))
            {
                //已经推送
                input.Push = true;
            }
            else
            {
                //未推送
                input.Push = false;
            }
            //保存信息
            await AddMessage(input);
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.Delivered,
                ExpressName = rider.Name,
                ExpressPhone = rider.Phone,
                ExpressId = rider.ID
            };
            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
        #region 商家发货
        /// <summary>
        /// 商家发货
        /// </summary>
        /// <param name="delivery">派单</param>
        /// <returns></returns>
        public async Task<string> BusinessComplete(Delivery delivery)
        {

            delivery.ShipMentTime = DateTime.Now.ToString();
            delivery.State = DeliveryState.Dispatch;
            
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "ShipMentTime", "State" });
            }
            catch
            {
                return "派单更新失败！";
            }
            //发送消息到队列
            var input = new MessageInput()
            {
                Content = "尊敬的客户：你好，你的外卖已经发出，请等待收货",
                OrderId = delivery.OrderId,
                TargetMess = new PushObject()
                {
                    ID = delivery.Customer.ID,
                    Name = delivery.Customer.Name,
                    Phone = delivery.Customer.Phone

                },
                SendUid = delivery.Business.UserId,
                Model = delivery.Customer.Model,
                OrderType = EnumMessageOrderType.Takeout,
                Target = "Buyer"
            };

            if (PuAll(new Message(input)))
            {
                //已经推送
                input.Push = true;
            }
            else
            {
                //未推送
                input.Push = false;
            }
            //保存信息
            await AddMessage(input);
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.Dispatch,
                ExpressName = delivery.Rider.Name,
                ExpressPhone = delivery.Rider.Phone,
                ExpressId=delivery.Rider.ID
            };
            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
        #region 骑手送达
        /// <summary>
        /// 骑手送达
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        public async Task<string> RiderComplete(Delivery delivery)
        {
            delivery.AccetpGoodsTime = DateTime.Now.ToString();
            delivery.State = DeliveryState.Received;
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "AccetpGoodsTime", "State" });
            }
            catch
            {
                return "派单更新失败！";
            }
            //发送消息到队列
            var input = new MessageInput()
            {
                Content = "尊敬的客户：你好，你的外卖已经送达，请评价本次服务。",
                OrderId = delivery.OrderId,
                TargetMess = new PushObject()
                {
                    ID = delivery.Customer.ID,
                    Name = delivery.Customer.Name,
                    Phone = delivery.Customer.Phone

                },
                SendUid = delivery.Rider.UserId,
                Model = delivery.Customer.Model,
                OrderType = EnumMessageOrderType.Takeout,
                Target = "Buyer"
            };

            if (PuAll(new Message(input)))
            {
                //已经推送
                input.Push = true;
            }
            else
            {
                //未推送
                input.Push = false;
            }
            //保存信息
            await AddMessage(input);
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.Received,
                ExpressName = delivery.Rider.Name,
                ExpressPhone = delivery.Rider.Phone,
                ExpressId = delivery.Rider.ID
            };
            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
        #region 骑手取消接单
        /// <summary>
        /// 骑手取消接单
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        public async Task<string> RiderCancel(Delivery delivery)
        {
            
             //发送消息到队列
            var input = new MessageInput()
            {
                Content = $"尊敬的商户：你好，你的外卖骑手{delivery.Rider.Name}取消了服务{delivery.OrderCode}，请重新派单。",
                OrderId = delivery.OrderId,
                TargetMess =  new PushObject()
                    {
                        ID =delivery.Business.UserId,
                        Name=delivery.Business.Name,
                        Phone=delivery.Business.Phone
                    
                },
                SendUid = delivery.Rider.UserId,
                Model = MessageSendModel.Aurora,
                OrderType = EnumMessageOrderType.Takeout,
                Target = "Seller"
            };
            if (PuAll(new Message(input)))
            {
                //已经推送
                input.Push = true;
            }
            else
            {
                //未推送
                input.Push = false;
            }
            //保存信息
            await AddMessage(input);
            delivery.State = DeliveryState.WaitRider;
            delivery.Rider = new RiderMess()
            {
                ID = 0,
                Name = "骑手退单",
                Phone = "",
                UserId = 0
            };
            delivery.RiderAccetpTime = "";
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "State", "RiderAccetpTime", "Rider" });
            }
            catch
            {
                return "派单更新失败！";
            }
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.WaitRider,
                ExpressName = "无骑手",
                ExpressPhone = "无电话",
                ExpressId = 0
            };

            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
        #region 骑手评价
        /// <summary>
        /// 骑手评价
        /// </summary>
        /// <param name="delivery"></param>
        /// <param name="evaluate"></param>
        /// <returns></returns>
        public async Task<string> RiderEvaluate(Delivery delivery, EvaluateContent evaluate)
        {
            //获取骑手信息     
            var rider = GetRider(delivery.Rider.ID);
            if(rider==null)
            {
                return "订单的骑手信息有误，无法完成评价";
            }
            //计算分数score
            var score= evaluate.GetScore();
            var upscore =(score + rider.Num*rider.Score) / (rider.Num+1);
            //保留1位小数
            var tscore=(int)upscore * 10;
            rider.Score= tscore/10;
            ////计算星级评价
            var total = (int)evaluate.Colligate + (int)evaluate.Service + (int)evaluate.Speed;
            total = (int)(total / 3);
            var result = (total + (int)rider.JudgeStar*rider.Num)/(rider.Num + 1);
            rider.JudgeStar = (StarKind)result;
            //保存结果
            rider.Num = rider.Num + 1;
            try
            {
                //保存派单评价
                delivery.Evaluate = evaluate;
                await deliverys.UpdateAsync(delivery, new List<string> { "Evaluate" });
                //更新骑手信息
                await riders.UpdateAsync(rider, new List<string> { "Score", "Evaluate", "JudgeStar", "Num" });
            }
            catch
            {
                return "";
            }
            return "OK";
            //}
        }
        #endregion
        #region 信息添加
        /// <summary>
        /// 信息添加
        /// </summary>
        /// <param name="input">输入信息</param>
        /// <returns></returns>
        private async Task<Message> AddMessage(MessageInput input)
        {
            //数据提交
            //var id = await GetNumber(3);      //获取新的序号,3的类别代表信息
            try
            {
                var temp = new Message(input);
                await messages.AddAsync(temp);
                return temp;
            }
            catch
            {
                return default(Message);
            }
        }
        #endregion
        #region 添加账单明细
        /// <summary>
        /// 添加账单明细
        /// </summary>
        /// <param name="body"></param>
        /// <param name="uid"></param>
        /// <param name="monry"></param>
        /// <param name="deliveryid"></param>
        /// <returns></returns>
        private async Task<int> AddAccountDetail(string body, int uid, int monry,int deliveryid)
        {
            //数据提交
            var id = await GetNumber(4);      //获取新的序号,4的类别账单明细
            try
            {
                var temp = new AccountDetail(id, body, uid, monry, deliveryid);
                await account.AddAsync(temp);
                return id;
            }
            catch
            {
                return 0;
            }
        }
        #endregion
        #region  获取账单
        /// <summary>
        /// 获取账单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public AccountDetail GetAccountDetail(int id)
        {
            Expression<Func<AccountDetail, bool>> findstr = f => f.ID == id;
            try
            {
                var result = account.GetQueryable(findstr).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        #endregion
        #region 获取账单列表
        /// <summary>
        /// 获取账单列表
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="begintime"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalpage"></param>
        /// <returns></returns>
        public List<AccountDetail> GetAccountList(int uid, DateTime begintime, int pageIndex, int pageSize, out int totalpage)
        {
            //排序条件
            Expression<Func<AccountDetail, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<AccountDetail, bool>> condstr = s => s.Uid == uid&&s.CreateTime>=begintime;

            var listtemp = account.GetListPage(condstr, orderstr, pageIndex, pageSize);
            totalpage = account.GetTotalPage(condstr, pageSize);
            return listtemp;

        }
        #endregion
        #region 账单标记，顾客确认
        /// <summary>
        /// 顾客确认,或者过期自动账单标记
        /// </summary>
        /// <param name="delivery"></param>
        /// <returns></returns>
        public async Task<string> CustomerAccept(Delivery delivery)
        {
          
            //费用记账
            delivery.AccountTime = DateTime.Now.ToString();
            delivery.State = DeliveryState.Account;
            try
            {
                await deliverys.UpdateAsync(delivery, new List<string> { "AccountTime", "State" });
            }
            catch
            {
                return "派单更新失败！";
            }
            if (delivery.IsReduce)
            {
                //向后台返还佣金发送调用
                client.ReturnFree(delivery.OrderCode);
            }
            //记账商户资产
            var balance = new BalnaceUpdateData()
            {
                UserId = delivery.Business.UserId,
                Balance = -delivery.Cost
            };
            try
            {
                client.UpdateBalance(balance);
                await AddAccountDetail("商家向骑手支付费用", delivery.Business.UserId, -delivery.Cost,delivery.ID);
            }
            catch
            {
                return "记账商户资产失败！";
            }
            //记账骑手资产
            balance = new BalnaceUpdateData()
            {
                UserId = delivery.Rider.UserId,
                Balance = delivery.Cost
            };
            try
            {
                client.UpdateBalance(balance);
                await AddAccountDetail("骑手获取商家服务费", delivery.Rider.UserId, delivery.Cost, delivery.ID);
            }
            catch
            {
                return "记账骑手资产失败！";
            }
            //提交状态
            var notic = new DeliveryNoticeDto()
            {
                OrderCode = delivery.OrderCode,
                State = (int)DeliveryState.Account,
                ExpressName = delivery.Rider.Name,
                ExpressPhone = delivery.Rider.Phone,
                ExpressId = delivery.Rider.ID
            };
            //未提交成功，保存缓存
            if (!client.DeliveryNotice(notic))
            {
                await notics.AddAsync(new NoticCache(notic));
            }
            return "OK";
        }
        #endregion
       
        #region 保存骑手坐标
        /// <summary>
        /// 保存骑手坐标
        /// </summary>
        /// <param name="id"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task<bool> SavePoint(int id,double[] data)
        {
            var filter = Builders<Rider>.Filter.Eq("ID", id);
            var update = Builders<Rider>.Update.Set("UserPoint", data);
            try
            {
                await riders.UpdateAsync(filter,update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region 填写要求
        /// <summary>
        /// 填写要求
        /// </summary>
        /// <param name="delivery"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        public async Task<bool> BusinessPushInput(Delivery delivery,List<string> list)
        {
            try
            {
                await deliverys.UpdateAsync(delivery,list);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
        #region 获取派单列表
        /// <summary>
        /// 获取派单列表
        /// </summary>
        /// <param name="condstr"></param>
        /// <returns></returns>
        public List<Delivery> GetDeliveryList(Expression<Func<Delivery, bool>> condstr)
        {
            var listtemp = deliverys.GetQueryable(condstr).ToList();
            return listtemp;
        }
        #endregion
        #region 推送代理
        /// <summary>
        /// 推送代理
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool PuAll(Message data)
        {
            PushTo push = pushdic.GetValueOrDefault(data.Model);
           
            return push(data);
        }
        /// <summary>
        /// 极光推送
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool PushAurora(Message data)
        {
            var input = new MessagePushInputDto()
            {
                Content = data.Content,
                SendUserID = data.SendUid,
                Type = "订单通知",
                ReceiveUserID = data.TargetMess.ID,
                OrderId = data.OrderId,
                OrderType = (int)data.OrderType,
                Target = data.Target,
                SendTime = data.CreateTime.ToString()
            };
            if (client.MessagePush(input))
            {
                //发送成功
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 短信推送
        /// </summary>
        /// <param name="data"></param>
        private bool PushSms(Message data)
        {
            var input = new SmsInputDto()
            {
                Content = data.Content,
                Phone = data.TargetMess.Phone,
                PushUserId = data.SendUid,
                SmsSign = "嗨哌猫"
            };
            if (client.SmsPush(input))
            {
                //发送成功
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 微信模板
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool PushWeChat(Message data)
        {
            //使用状态更新模板推送
            var input = new PushTemplateMessageInputDto()
            {
                UserId = data.TargetMess.ID,
                TemplateId = "Rjkm3FQg-tu35MjtF2em2K2WpR38Rj7PMMTBTaN9iZA",
                Url = "",
                TemplateDatas = new StatusUpdate()
                {
                    First = new Shares.TempItem(data.TargetMess.Name),                                //头部
                    OrderSn = new Shares.TempItem(data.OrderId.ToString()),                //订单号
                    OrderStatus = new Shares.TempItem(data.OrderType.ToString()),               //状态
                    Remark = new Shares.TempItem(data.Content)                             //尾部
                }
            };
            if (client.WeChatTemplate(input))
            {
                //发送成功
                return true;
            }
            else
            {
                return false;
            }
        }
       
        #endregion
        #region  消息延后推送
        /// <summary>
        /// 消息推送
        /// </summary>
        public async Task PushMess()
        {
            //获取未推送的消息
            var unsend = messages.GetList(o => !o.Push).ToList(); 
            foreach (var mess in unsend)
            {
                //推送消息
                if (PuAll(mess))
                {
                    //已经推送
                    var filter = Builders<Message>.Filter.Eq("Id", mess.Id);
                    var update = Builders<Message>.Update.Set("Push ", true);
                    //标记已经推送
                    await messages.UpdateAsync(filter, update);
                }
      
            }
            //获取未发送通知
            var unnotic = notics.GetList(o => true).ToList();
            foreach(var notic in unnotic)
            {
                //发送通知
                if (!client.DeliveryNotice(notic.Content))
                {
                    await notics.RemoveAsync(notic);
                }
            }
        }
        #endregion
        #region  计算服务费用
        private int AcountCost(int dist)
        {
            int result = 0;
            if (dist <= 1500)
            {
                result = 400;
            }
            else if (dist <= 2000)
            {
                result = 450;
            }
            else if (dist <= 3000)
            {
                result = 500;
            }
            else
            {
                result = 550;
            }
            return result;
        }
        #endregion
    }
}
