﻿using CarTools.Shares;
using CatTools.Models;
using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    public interface IUserService
    {
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<User> AddUser(UserRegister input);
        /// <summary>
        ///获取用户明细
        /// </summary>
        /// <param name="uid">uid</param>
        /// <returns></returns>
        User GetDetailed(int uid);
        /// <summary>
        /// 修改用户信息
        /// </summary>
        /// <param name="id"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<User> UserUpdate(int id, UserModi input);
        /// <summary>
        /// 删除客户
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        Task<bool> DeleteUser(int uid);
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        dynamic GetUserList(int[] IDs);
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="condstr">条件</param>
        /// <returns></returns>
        List<User> GetUserList(Expression<Func<User, bool>> condstr);
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="condstr">筛选条件</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        JsonReturn<List<User>> GetList(Expression<Func<User, bool>> condstr, int PageIndex, int PageSize);
        /// <summary>
        /// 保存session
        /// </summary>
        /// <param name="id"></param>
        /// <param name="session"></param>
        void SaveSession(int id, string session);
        /// <summary>
        /// session是否有效
        /// </summary>
        /// <param name="session"></param>
        /// <returns>有效返回uid，否则返回-1</returns>
        int IsValid(string session);
    }
    public class UserService : IUserService
    {
        private readonly IRepository<User> Users;
        private List<UserCheck> users;

        public UserService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            Users = new MongoRespository<User>(new MongoDBContext<User>(dbName, dbconn));
            if (MemoryCacheHelper.Exists("UserCheck"))
            {
                //从缓存中读取检查表
                users = (List<UserCheck>)MemoryCacheHelper.Get("UserCheck");
                //清理过期
                Clear();
            }
            else
            {
                //生成验证信息
                users = new List<UserCheck>();
            }
        }
        /// <summary>
        /// 用户注册
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<User> AddUser(UserRegister input)
        {
            //数据提交
            try
            {
                var temp = new User(input);
                await Users.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 修改用户信息
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<User> UserUpdate(int uid, UserModi input)
        {
            //获取原纪录
            var temp = GetDetailed(uid);
            if (temp == null)
            {
                //未发现原纪录
                return null;
            }
            //数据提交
            try
            {
                //获取修改列表
                var properts = temp.UpdateList(input);
                await Users.UpdateAsync(temp, properts);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 删除用户
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public async Task<bool> DeleteUser(int uid)
        {
            try
            {
                var temp = GetDetailed(uid);
                await Users.RemoveAsync(temp);
            }
            catch
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// 获取用户明细
        /// </summary>
        /// <param name="uid">嗨派猫uid</param>
        /// <returns></returns>
        public User GetDetailed(int uid)
        {
            var result = Users.Get(o => o.ID == uid);
            return result;

        }
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        public dynamic GetUserList(int[] IDs)
        {
            var res = Users.GetList(o => IDs.Contains(o.ID)).Select(o => new { o.ID, o.Name, o.Portrait }).ToList();
            return res;

        }
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="condstr"></param>
        /// <returns></returns>
        public List<User> GetUserList(Expression<Func<User, bool>> condstr)
        {
            return Users.GetList(condstr).ToList();
        }
        /// <summary>
        /// 获取用户列表
        /// </summary>
        /// <param name="condstr"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public JsonReturn<List<User>> GetList(Expression<Func<User, bool>> condstr, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<User, int>> orderstr = item => item.ID;
            var listtemp = Users.GetListPage(condstr, orderstr, PageIndex, PageSize).ToList();
            var totaltemp = Users.GetTotalPage(condstr, PageSize);
            return new JsonReturn<List<User>>(listtemp, totaltemp, "返回用户列表");
        }
        /// <summary>
        /// 是否存在
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public bool IsExists(int uid)
        {
            if (users.Exists(o => o.ID == uid))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 保存sesion
        /// </summary>
        /// <param name="id"></param>
        /// <param name="session"></param>
        public void SaveSession(int id, string session)
        {
            users.Add(new UserCheck() { ID = id, Session = session, EndTime = DateTime.Now.AddHours(4) });
            MemoryCacheHelper.Remove("UserCheck");
            MemoryCacheHelper.Set("UserCheck", users, TimeSpan.FromHours(120), true);
        }
        /// <summary>
        /// 检查是否有效
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        public int IsValid(string session)
        {
            //var test = users.Find(o =>true);
            var result = users.Find(o => { return o.Session == session && o.EndTime >= DateTime.Now; });
            if (result == null)
            {
                return -1;
            }
            else
            {
                return result.ID;
            }
        }
        /// <summary>
        /// 清理过期
        /// </summary>
        private void Clear()
        {
            users.RemoveAll(o => { return o.EndTime<= DateTime.Now; });
        }
    }
}
