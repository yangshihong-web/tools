﻿using CatTools.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Services
{
    public interface IPayRecnoService
    {
        /// <summary>
        /// 获取支付号
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string GetCode(string id);
    }
    public class PayRecnoService : IPayRecnoService
    {
        private readonly IRepository<PayRecno> payrecnos;
        public PayRecnoService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            payrecnos = new MongoRespository<PayRecno>(new MongoDBContext<PayRecno>(dbName, dbconn));
        }
        /// <summary>
        /// 获取支付号
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetCode(string id)
        {
            var recno = payrecnos.Get(o => o.PayId == id);
            if(recno==null)
            {
                //添加新记录
                recno = new PayRecno(id);
                Task.Run(() => payrecnos.AddAsync(recno)) ;
            }
            else
            {
                if (recno.LastNo < 99)
                {
                    //序号加一
                    recno.LastNo = recno.LastNo + 1;
                    Task.Run(() => payrecnos.UpdateAsync(recno));
                }
            }
            var recnostr = "00";
            if(recno.LastNo<10)
            {
                recnostr = "0" + recno.LastNo.ToString();
            }
            else
            {
                recnostr = recno.LastNo.ToString();
            }
            var result = recno.PayId + recnostr;
            return result;
        }
    }
}
