﻿using CarTools.Shares;
using CatTools.Models;
using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 营销券接口
    /// </summary>
    public interface IMarketingCouponsService
    {
        //
        //比例操作,添加，删除，获取明细，获取列表
        //
        Task<bool> AddScale(ScaleStack scale);
        Task<bool> DeleteScale(int coustomer);
        ScaleStack GetScale(int coustomer);
        List<ScaleStack> GetScales();
        //
        //营销券操作，添加，修改，终止，获取明细，获取列表（有效性,分页）
        //
        Task<bool> AddMarketing(MarketingCouponsStack data);
        Task<bool> UpdateMarketing(MarketingCouponsStack data);
        Task<bool> CancelMarketing(string id);
        MarketingCouponsStack GetMarketing(string id);
        List<MarketingCouponsStack> GetMarketings(out int totaltemp, bool isvalid = true, int PageIndex = 1, int PageSize = 15);
        //
        //商户商品操作，添加，设置，获取明细，获取列表（商户id，用户id，分页）
        //
        Task<bool> AddCommodity(CommodityStack data);
        Task<bool> SetCommodity(int id, int coustomerdis);
        CommodityStack GetCommodity(int id);
        List<CommodityStack> GetCommoditys(out int totaltemp, int businessid = 0, int uid = 0, int PageIndex = 1, int PageSize = 15);
        //
        //客户券操作，领取，使用，获取明细，获取列表（客户id，仅可用,分页）
        //
        Task<bool> TakeCoupons(CustomerCouponsStack data);
        Task<string> UseCoupons(string couponsid, int goodsid);
        CustomerCouponsStack GetCoupons(string id);
        List<CustomerCouponsStack> GetCouponies(out int totaltemp, int uid = 0, bool onlyuse=true,int PageIndex = 1, int PageSize = 15);
    }
    /// <summary>
    /// 营销券服务
    /// </summary>
    public class MarketingCouponsService : IMarketingCouponsService
    {
        private readonly IRepository<ScaleStack> scales;
        private readonly IRepository<MarketingCouponsStack> marketings;
        private readonly IRepository<CommodityStack> commoditys;
        private readonly IRepository<CustomerCouponsStack> couponies;
        public MarketingCouponsService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            scales = new MongoRespository<ScaleStack>(new MongoDBContext<ScaleStack>(dbName, dbconn));
            marketings = new MongoRespository<MarketingCouponsStack>(new MongoDBContext<MarketingCouponsStack>(dbName, dbconn));
            commoditys = new MongoRespository<CommodityStack>(new MongoDBContext<CommodityStack>(dbName, dbconn));
            couponies = new MongoRespository<CustomerCouponsStack>(new MongoDBContext<CustomerCouponsStack>(dbName, dbconn));
        }
        #region 比例服务
        /// <summary>
        /// 添加比例
        /// </summary>
        /// <param name="scale">新比例</param>
        /// <returns>成功或者失败</returns>
        public async Task<bool> AddScale(ScaleStack scale)
        {
            try
            {
                await scales.AddAsync(scale);

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 删除比例
        /// </summary>
        /// <param name="coustomer"></param>
        /// <returns></returns>
        public async Task<bool> DeleteScale(int coustomer)
        {
            var entity = scales.GetQueryable(o => o.CoustomerDis == coustomer).FirstOrDefault();
            if(entity==null)
            {
                return false;
            }
            try
            {
                await scales.RemoveAsync(entity);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取比例
        /// </summary>
        /// <param name="coustomer"></param>
        /// <returns></returns>
        public ScaleStack GetScale(int coustomer)
        {
            Expression<Func<ScaleStack, bool>> findstr = f => f.CoustomerDis == coustomer;
            try
            {
                var result = scales.GetQueryable(findstr).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取比例列表
        /// </summary>
        /// <returns></returns>
        public List<ScaleStack> GetScales()
        {
            //排序条件
            Expression<Func<ScaleStack, int>> orderstr = item => item.CoustomerDis;
            Expression<Func<ScaleStack, bool>> condstr = s => true;
            var result = scales.GetList(condstr, orderstr).ToList();
            return result;
        }
        #endregion
        #region 营销券服务
        /// <summary>
        /// 添加营销券
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task<bool> AddMarketing(MarketingCouponsStack data)
        {
            try
            {
                await marketings.AddAsync(data);

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 营销券修改
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task<bool> UpdateMarketing(MarketingCouponsStack data)
        {
            try
            {
                await marketings.UpdateAsync(data);

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 营销券终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> CancelMarketing(string id)
        {
            //更新数据
            var filter = Builders<MarketingCouponsStack>.Filter.Eq("Id", id);
            var update = Builders<MarketingCouponsStack>.Update.Set("IsValid", false);

            try
            {
                await marketings.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取营销券
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public MarketingCouponsStack GetMarketing(string id)
        {
            try
            {
                var result = marketings.GetQueryable(o=>o.Id==id).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取营销券列表
        /// </summary>
        /// <param name="isvalid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="totaltemp">总页数</param>
        /// <returns></returns>
        public List<MarketingCouponsStack> GetMarketings(out int totaltemp, bool isvalid = true, int PageIndex = 1, int PageSize = 15)
        {
            //排序条件
            Expression<Func<MarketingCouponsStack, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<MarketingCouponsStack, bool>> condstr = null;
            //仅查看有效
            if (isvalid)
            {
                  //仅查看有效记录
                  condstr = s =>s.IsValid&&s.TakeEndTime>=DateTime.Now;
            
            }
            else
            {
                condstr = s => true;
            }
            var listtemp = marketings.GetListPage(condstr, orderstr, PageIndex, PageSize);
            totaltemp = marketings.GetTotalPage(condstr, PageSize);
            return listtemp;
        }
        #endregion
        #region 商品服务
        /// <summary>
        /// 添加商品
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task<bool> AddCommodity(CommodityStack data)
        {
            try
            {
                await commoditys.AddAsync(data);

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 设置商品优惠比例
        /// </summary>
        /// <param name="id">商品id</param>
        /// <param name="coustomerdis">客户优惠比例</param>
        /// <returns></returns>
        public async Task<bool> SetCommodity(int id,int coustomerdis)
        {
            var scale = Scale.Get(coustomerdis);
            if(scale==null)
            {
                return false;
            }
            //更新数据
            var filter = Builders<CommodityStack>.Filter.Eq("ProductID", id);
            var update = Builders<CommodityStack>.Update.Set("SetScale", scale);

            try
            {
                await commoditys.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// 获取商品
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CommodityStack GetCommodity(int id)
        {
            try
            {
                var result = commoditys.GetQueryable(o => o.ProductID == id).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取商品列表
        /// </summary>
        /// <param name="totaltemp"></param>
        /// <param name="businessid"></param>
        /// <param name="uid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<CommodityStack> GetCommoditys(out int totaltemp, int businessid = 0, int uid = 0, int PageIndex = 1, int PageSize = 15)
        {
            //排序条件
            Expression<Func<CommodityStack, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<CommodityStack, bool>> condstr = null;
            //
            if (businessid <1)
            {
                if(uid<1)
                {
                    condstr = s => true;
                }
                else
                {
                    condstr = s => s.UserId==uid;
                }
            }
            else
            {
                condstr = s => s.BusinessId==businessid;
            }
            var listtemp = commoditys.GetListPage(condstr, orderstr, PageIndex, PageSize);
            totaltemp = commoditys.GetTotalPage(condstr, PageSize);
            return listtemp;
        }
        #endregion
        #region 客户券服务
        /// <summary>
        /// 获取客户券列表
        /// </summary>
        /// <param name="totaltemp"></param>
        /// <param name="uid"></param>
        /// <param name="onlyuse"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<CustomerCouponsStack> GetCouponies(out int totaltemp, int uid = 0, bool onlyuse = true, int PageIndex = 1, int PageSize = 15)
        {
            //排序条件
            Expression<Func<CustomerCouponsStack, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<CustomerCouponsStack, bool>> condstr = null;
            if (uid < 1)
            {
                //仅查看有效
                if (onlyuse)
                {
                    //仅查看有效记录
                    condstr = s => s.Balance > 0 && s.UseEndTime >= DateTime.Now;

                }
                else
                {
                    condstr = s => true;
                }
            }
            else
            {
                //仅查看有效
                if (onlyuse)
                {
                    //仅查看有效记录
                    condstr = s =>s.UserId==uid && s.Balance > 0 && s.UseEndTime >= DateTime.Now;

                }
                else
                {
                    condstr = s => s.UserId == uid;
                }
            }
            var listtemp = couponies.GetListPage(condstr, orderstr, PageIndex, PageSize);
            totaltemp = couponies.GetTotalPage(condstr, PageSize);
            return listtemp;
        }
        /// <summary>
        /// 获取客户券
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CustomerCouponsStack GetCoupons(string id)
        {
            try
            {
                var result = couponies.GetQueryable(o => o.Id == id).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }


        /// <summary>
        /// 客户券领取
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public async Task<bool> TakeCoupons(CustomerCouponsStack data)
        {
            try
            {
                await couponies.AddAsync(data);

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 客户券更新
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private async Task<bool> UpdateCoupons(CustomerCouponsStack data)
        {
            try
            {
                await couponies.UpdateAsync(data);

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 客户券使用
        /// </summary>
        /// <param name="couponsid">券id</param>
        /// <param name="goodsid">商品id</param>
        /// <returns></returns>
        public async Task<string> UseCoupons(string couponsid, int goodsid)
        {
            //获取客户券
            var coupons = couponies.Get(o => o.Id == couponsid);
            if(coupons==null)
            {
                return $"无客户券{couponsid}的记录！";
            }
            //获取商品
            var goods = commoditys.Get(o => o.ProductID == goodsid);
            if(goods==null||goods.SetScale==null)
            {
                return $"无商品{goods}的记录";
            }
            //计算余额
            if(coupons.Balance<1)
            {
                return "券余额不足";
            }
            //计算有效日期
            if(coupons.UseEndTime<DateTime.Now)
            {
                return "券已经过期";
            }
            var usemoney = 0;
            if(coupons.Balance>=goods.SetScale.CoustomerMoney)
            {
                //券余额满足,按比例要求扣减
                usemoney = goods.SetScale.CoustomerMoney;
            }
            else
            {
                //按余额扣减
                usemoney = coupons.Balance;
            }
            //添加使用信息
            var usemess = new CouponsUse()
            {
                ProductID = goods.ProductID,
                UseTime = DateTime.Now,
                SetScale = goods.SetScale,
                UseMoney = usemoney
            };
            
            var userecno = coupons.UseRecno;
            userecno.Add(usemess);
            coupons.Balance = coupons.Balance - usemoney;
            coupons.UseRecno = userecno;
            //保存结果
            var result = await UpdateCoupons(coupons);
            if(result)
            {
                return "OK";
            }
            else
            {
                return "保存失败！";
            }
        }
        #endregion
    }
}
