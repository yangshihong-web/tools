﻿using CatTools.Shares;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CatTools.Services
{
    public class Account : BackgroundService
    {
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await new TaskFactory().StartNew(() =>
                {
                    try
                    {
                        //满足某种条件执行 比如每天凌晨执行
                        var time = DateTime.Now.ToString("HH:mm:ss");
                        if ("00:01:00" == time)
                        {
                            //业务逻辑 
                            //Console.WriteLine(DateTime.Now + ":进入这里了");

                        }

                    }
                    catch (Exception)
                    {
                        //错误处理
                    }

                    //定时任务休眠
                    Thread.Sleep(1 * 1000);
                });
            }

        }
    }
}
