﻿using CarTools.Shares;
using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 预约接口
    /// </summary>
    public interface IAppointmentService
    {
        /// <summary>
        /// 添加模板
        /// </summary>
        /// <param name="shop">门店</param>
        /// <param name="explain">项目说明</param>
        /// <returns></returns>
        Task<AappointmentModel> AddModel(Shop shop, AappointmentExplain explain);
        /// <summary>
        /// 删除模板
        /// </summary>
        /// <param name="id">模板id</param>
        /// <returns></returns>
        Task<bool> DeleteModel(string id);
        /// <summary>
        /// 获取模板
        /// </summary>
        /// <param name="id">模板id</param>
        /// <returns></returns>
        AappointmentModel GetModel(string id);
        /// <summary>
        /// 获取模板列表
        /// </summary>
        /// <param name="uid">指定用户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录数</param>
        /// <returns></returns>
        JsonReturn GetModels(int uid, int PageIndex, int PageSize);
        /// <summary>
        /// 添加时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="times">时段</param>
        /// <returns></returns>
        Task<bool> AddTimes(string id,Times times);
        /// <summary>
        /// 修改时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="times">时段</param>
        /// <returns></returns>
        Task<bool> UpdateTimes(string id, Times times);
        /// <summary>
        /// 删除时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="timeid">时段id</param>
        /// <returns></returns>
        Task<bool> DeleteTimes(string id, string timeid);
        /// <summary>
        /// 建立新预约表
        /// </summary>
        /// <param name="model">模板</param>
        /// <param name="date">日期</param>
        /// <returns></returns>
        Task<AppointmentTable> CreateNewTable(AappointmentModel model, string date);
        /// <summary>
        /// 获取预约表
        /// </summary>
        /// <param name="modelid">模板id</param>
        /// <param name="date">日期</param>
        /// <returns></returns>
        AppointmentTable GetTable(string modelid, string date);
        /// <summary>
        /// 添加预约
        /// </summary>
        /// <param name="table">预约表</param>
        /// <param name="timeid">时段id</param>
        /// <param name="num">设置数量</param>
        /// <param name="man">用户id</param>
        /// <param name="money"></param>
        /// <returns></returns>
        Task<AppointmentOrder> AddAppointment(AppointmentTable table, string timeid, int num, int money,AappointmentMan man);
        /// <summary>
        /// 终止预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        Task<bool> CancelAppointment(string id);
        /// <summary>
        /// 履行预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        Task<bool> FulfillAppointment(string id);
        /// <summary>
        /// 获取预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        AppointmentOrder GetAppointment(string id);
        /// <summary>
        /// 获取预约列表
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <param name="date">日期</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        JsonReturn GetAppointments(int shopid, string date, int PageIndex, int PageSize);
        /// <summary>
        /// 获取预约列表
        /// </summary>
        /// <param name="uid">客户id</param>
        /// <param name="date">日期</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        JsonReturn GetAppointmentsByClient(int uid, string date, int PageIndex, int PageSize);
        /// <summary>
        /// 修改模板
        /// </summary>
        /// <param name="model">模板</param>
        /// <returns></returns>
        Task<bool> UpdateModel(AappointmentModel model);
    }
    /// <summary>
    /// 预约服务
    /// </summary>
    public class AppointmentService : IAppointmentService
    {
        private readonly IRepository<AappointmentModel> models;   //模板
        private readonly IRepository<AppointmentOrder> orders;    //订单
        private readonly IRepository<AppointmentTable> tables;    //登记表
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="config"></param>
        public AppointmentService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            models = new MongoRespository<AappointmentModel>(new MongoDBContext<AappointmentModel>(dbName, dbconn));
            orders = new MongoRespository<AppointmentOrder>(new MongoDBContext<AppointmentOrder>(dbName, dbconn));
            tables = new MongoRespository<AppointmentTable>(new MongoDBContext<AppointmentTable>(dbName, dbconn));
        }
        /// <summary>
        /// 添加预约
        /// </summary>
        /// <param name="table">预约表</param>
        /// <param name="timeid">时段id</param>
        /// <param name="num">人数</param>
        /// <param name="money">金额</param>
        /// <param name="man">预约人信息</param>
        /// <returns></returns>
        public async Task<AppointmentOrder> AddAppointment(AppointmentTable table, string timeid, int num, int money, AappointmentMan man)
        {
            //生成预约订单
            var order = new AppointmentOrder()
            {
                CreateDate = DateTime.Now,
                Date = table.Date,
                Explain = table.Explain,
                IsValid = true,
                TableId = table.Id,
                PersonsNum = num,
                Money = money,
                ShopMess = table.ShopMess,
                TimeId = timeid,
                Fulfill = "",
                Man = man
            };
            //标记预约表
            var temp = table.Arrange.FindIndex(o => o.Id == timeid);
            if (table.Arrange[temp] == null|| table.Arrange[temp].Aappointment==null)
            {
                table.Arrange[temp].Aappointment = new List<string>() { order.Id};
            }
            else
            {
                table.Arrange[temp].Aappointment.Add(order.Id);
            }
            //
            try
            {
                //添加预约订单
                await orders.AddAsync(order);
                //更新预约表
                await tables.UpdateAsync(table);
                //返回
                return order;
            }
            catch
            {
                return default(AppointmentOrder);
            }
        }
        /// <summary>
        /// 添加模板
        /// </summary>
        /// <param name="shop">门店</param>
        /// <param name="explain">项目说明</param>
        /// <returns></returns>
        public async Task<AappointmentModel> AddModel(Shop shop, AappointmentExplain explain)
        {
            try
            {
                var result = new AappointmentModel(shop, explain);
                await models.AddAsync(result);
                return result;
            }
            catch
            {
                return default(AappointmentModel);
            }
        }
        /// <summary>
        /// 修改模板
        /// </summary>
        /// <param name="model">模板</param>
        /// <returns></returns>
        public async Task<bool> UpdateModel(AappointmentModel model)
        {
            try
            {
                await models.UpdateAsync(model);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 添加模板时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="times">时段</param>
        /// <returns></returns>
        public async Task<bool> AddTimes(string id, Times times)
        {
            //获取活动
            var model = GetModel(id);
            if (model==null||model.Time == null)
            {
                model.Time = new List<Times>() { times};
            }
            else
            {
                model.Time.Add(times);
            }
            //更新购买人列表
            try
            {
                await models.UpdateAsync(model);

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 终止预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        public async Task<bool> CancelAppointment(string id)
        {
            //获取预约
            var order = orders.Get(o => o.Id == id);
            if (order == null) return false;
            var table = tables.Get(o => o.Id == order.TableId);
            if (table == null) return false;
            var temp = table.Arrange.FindIndex(o => o.Id == order.TimeId);
            if (table.Arrange[temp] == null || table.Arrange[temp].Aappointment == null)
            {
                return false;
            }
            else
            {
                table.Arrange[temp].Aappointment.Remove(order.Id);
                order.IsValid = false;
            }
            //
            try
            {
                //标记预约订单
                await orders.UpdateAsync(order);
                //更新预约表
                await tables.UpdateAsync(table);
                //返回
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 建立新表
        /// </summary>
        /// <param name="model">模板</param>
        /// <param name="date">日期</param>
        /// <returns></returns>
        public async Task<AppointmentTable> CreateNewTable(AappointmentModel model, string date)
        {
            var arrange = new List<TimesArrange>();
            foreach(var n in model.Time)
            {
                var mm = new TimesArrange()
                {
                    Id = n.Id,
                    Name = n.Name,
                    SetNum = n.SetNum
                };
                arrange.Add(mm);
            }
            var table = new AppointmentTable() { Date=date, Explain=model.Explain, ModelId=model.Id, ShopMess=model.ShopMess, Arrange= arrange };
            if(table==null)
            {
                return default(AppointmentTable);
            }
            try
            {
                await tables.AddAsync(table);
                return table;
            }
            catch
            {
                return default(AppointmentTable);
            }
        }
        /// <summary>
        /// 删除模板
        /// </summary>
        /// <param name="id">模板id</param>
        /// <returns></returns>
        public async Task<bool> DeleteModel(string id)
        {
            try
            {
                var model = GetModel(id);
                await models.RemoveAsync(model);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 删除时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="timeid">时段id</param>
        /// <returns></returns>
        public async Task<bool> DeleteTimes(string id, string timeid)
        {
            //获取活动
            var model = GetModel(id);
            if (model==null||model.Time == null)
            {
                return false;
            }
            else
            {
                var temp = model.Time.Find(o => o.Id == timeid);
                model.Time.Remove(temp);
                //更新购买人列表
                try
                {
                    await models.UpdateAsync(model);

                    return true;
                }
                catch
                {
                    return false;
                }
            }
          
        }
        /// <summary>
        /// 履行预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        public async Task<bool> FulfillAppointment(string id)
        {
            //获取预约
            var order = orders.Get(o => o.Id == id);
            if (order == null)
            {
                return false;
            }
            order.Fulfill = DateTime.Now.ToString();
            //
            try
            {
                //标记预约订单
                await orders.UpdateAsync(order);

                //返回
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取预约
        /// </summary>
        /// <param name="id">预约id</param>
        /// <returns></returns>
        public AppointmentOrder GetAppointment(string id)
        {
            var result = orders.Get(o => o.Id == id);
            return result;
        }
        /// <summary>
        /// 获取预约列表
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <param name="date">日期</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录数</param>
        /// <returns></returns>
        public JsonReturn  GetAppointments(int shopid, string date, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<AppointmentOrder, DateTime>> orderstr = item => item.CreateDate;
            try
            {
                var result = orders.GetListPage(o => o.ShopMess.ShopId == shopid, orderstr, PageIndex, PageSize);
                var total = orders.GetTotalPage(o => o.ShopMess.ShopId == shopid, PageSize);
                if (result!=null&&result.Count > 0)
                {
                    return new JsonReturn<List<AppointmentOrder>>(result, total, "获取预约列表");
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现预约记录");
                }
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现预约记录");
            }
        }
        /// <summary>
        /// 获取客户端预约列表
        /// </summary>
        /// <param name="uid">客户id</param>
        /// <param name="date">日期</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录数</param>
        /// <returns></returns>
        public JsonReturn GetAppointmentsByClient(int uid, string date, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<AppointmentOrder, DateTime>> orderstr = item => item.CreateDate;
            try
            {
                var result = orders.GetListPage(o => o.Man.Userid == uid, orderstr, PageIndex, PageSize);
                var total = orders.GetTotalPage(o => o.Man.Userid == uid, PageSize);
                if (result.Count > 0)
                {
                    return new JsonReturn<List<AppointmentOrder>>(result, total, "获取预约列表");
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现预约记录");
                }
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现预约记录");
            }
        }

        /// <summary>
        /// 获取模板
        /// </summary>
        /// <param name="id">模板id</param>
        /// <returns></returns>
        public AappointmentModel GetModel(string id)
        {
            try
            {
                var result = models.Get(o => o.Id == id);
                return result;
            }
            catch
            {
                return default(AappointmentModel);
            }
        }
        /// <summary>
        /// 获取模板列表
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">记录数</param>
        /// <returns></returns>
        public JsonReturn GetModels(int shopid, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<AappointmentModel, DateTime>> orderstr = item => item.CreateTime;
            try
            {
                var result = models.GetListPage(o => o.ShopMess.ShopId == shopid,orderstr,PageIndex,PageSize);
                var total = models.GetTotalPage(o => o.ShopMess.ShopId == shopid,PageSize);
                if (result.Count > 0)
                {
                    return new JsonReturn<List<AappointmentModel>>(result, total, "获取模板列表");
                }
                else
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "没发现模板记录");
                }
                
            }
            catch
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound,"没发现模板记录");
            }
        }
        /// <summary>
        /// 获取登记表
        /// </summary>
        /// <param name="modelid">模板id</param>
        /// <param name="date">日期</param>
        /// <returns></returns>
        public AppointmentTable GetTable(string modelid, string date)
        {
            try
            {
                var dat = DateTime.Parse(date).Date;
                var table = tables.Get(o => o.ModelId == modelid&&o.Date==date);
                if (table == null)
                {
                    //不存在获取模板
                    var model = GetModel(modelid);
                    if (model == null)
                    {
                        return new AppointmentTable() { Result = "输入模板id错误" };
                    }
                    //检查休息日
                    var weekmark = (int)dat.DayOfWeek;
                    var index = Array.IndexOf(model.RestDate, weekmark);
                    if (index < 0)
                    {
                        table = new AppointmentTable() { Date = date, Explain = model.Explain, ModelId = model.Id, ShopMess = model.ShopMess, Arrange = new List<TimesArrange>(), Result = "New" };
                        return table;
                    }
                    else
                    {
                        return new AppointmentTable() { Result = "休息日" };
                    }
                }
                else
                {
                    table.Result = "Exist";
                    return table;
                }
            }
            catch
            {
                return new AppointmentTable() { Result = "输入日期错误" };
            }
        }
        /// <summary>
        /// 修改时段
        /// </summary>
        /// <param name="id">模板id</param>
        /// <param name="times">时段</param>
        /// <returns></returns>
        public async Task<bool> UpdateTimes(string id, Times times)
        {
            //获取活动
            var model = GetModel(id);
            if (model==null||model.Time == null)
            {
                model.Time = new List<Times>() { times };
            }
            else
            {
                var temp=model.Time.FindIndex(o => o.Id == times.Id);
                model.Time[temp] = times;
            }
            //更新购买人列表
            try
            {
                await models.UpdateAsync(model);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
