﻿using CarTools.Shares;
using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 加盟卡接口
    /// </summary>
    public interface IDiscountService
    {
        /// <summary>
        /// 申请保存
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <param name="name">商户名</param>
        /// <param name="goodies">商品列表</param>
        /// <returns></returns>
        Task<AllianceBusiness>  ApplySave(int shopid, string name, IList<int> goodies);
        /// <summary>
        /// 商户取消加盟
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <returns></returns>
        Task<bool> BusinessCancel(int shopid);
        /// <summary>
        /// 获取申请明细
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <returns></returns>
        AllianceBusiness GetApply(int shopid);
        /// <summary>
        /// 获取加盟商户
        /// </summary>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录</param>
        /// <returns></returns>
        JsonReturn GetApplys(int page, int pagesize);
        /// <summary>
        /// 添加加盟卡
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <param name="name">用户名</param>
        /// <param name="money">金额</param>
        /// <returns></returns>
        Task<string> AddCard(int uid, string name, int money);
        /// <summary>
        /// 获取加盟卡
        /// </summary>
        /// <param name="id">用户id</param>
        /// <returns></returns>
        AllianceCard GetCard(int id);
        /// <summary>
        /// 获取加盟卡
        /// </summary>
        /// <param name="id">卡id</param>
        /// <returns></returns>
        AllianceCard GetCard(string id);
        /// <summary>
        /// 获取加盟卡列表
        /// </summary>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录</param>
        /// <returns></returns>
        JsonReturn GetCards(int page, int pagesize);
        /// <summary>
        /// 充值
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="cardid"></param>
        /// <param name="money"></param>
        /// <returns></returns>
        Task<string> AddRecharge(int uid,string cardid, int money);
        /// <summary>
        /// 支付回调
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> PayNotify(string id);
        /// <summary>
        /// 获取充值明细
        /// </summary>
        /// <param name="id">充值id</param>
        /// <returns></returns>
        CardRecharge GetRecharge(string id);
        /// <summary>
        /// 加盟卡使用
        /// </summary>
        /// <param name="card">加盟卡</param>
        /// <param name="money">金额</param>
        /// <returns></returns>
        Task<int> CardUse(AllianceCard card, int money);
        /// <summary>
        /// 获取加盟卡充值列表
        /// </summary>
        /// <param name="id">卡号</param>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        /// <param name="begintime">开始日期</param>
        /// <returns></returns>
        JsonReturn GetCardCharge(string id, int page, int pagesize, DateTime begintime);
        /// <summary>
        /// 获取加盟卡使用列表
        /// </summary>
        /// <param name="id">卡号</param>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录数</param>
        /// <param name="begintime">开始日期</param>
        /// <returns></returns>
        JsonReturn GetCardUser(string id, int page, int pagesize, DateTime begintime);
        /// <summary>
        /// 获取未支付订单
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <returns></returns>
        List<CardRecharge> GetUnPayOrder(int uid);
    }
    /// <summary>
    /// 加盟卡服务
    /// </summary>
    public class DiscountService: IDiscountService
    {
        private double cardscale = 0.1;
        private readonly IRepository<AllianceBusiness> business;
        private readonly IRepository<AllianceCard> cards;
        private readonly IRepository<CardRecharge> charges;
        private readonly IRepository<CardUse> uses;
        public DiscountService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            business = new MongoRespository<AllianceBusiness>(new MongoDBContext<AllianceBusiness>(dbName, dbconn));
            cards = new MongoRespository<AllianceCard>(new MongoDBContext<AllianceCard>(dbName, dbconn));
            charges = new MongoRespository<CardRecharge>(new MongoDBContext<CardRecharge>(dbName, dbconn));
            uses = new MongoRespository<CardUse>(new MongoDBContext<CardUse>(dbName, dbconn));
            var scale = config.GetConnectionString("CardScale");
            cardscale = double.Parse(scale);
        }
        /// <summary>
        /// 申请保存
        /// </summary>
        /// <param name="shopid"></param>
        /// <param name="name"></param>
        /// <param name="goodies"></param>
        /// <returns></returns>
        public async Task<AllianceBusiness> ApplySave(int shopid, string name, IList<int> goodies)
        {
            //数据提交
            try
            {
                var result = new AllianceBusiness(shopid, name, goodies);
                await business.AddAsync(result);
                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 商户取消加盟
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <returns></returns>
        public async Task<bool> BusinessCancel(int shopid)
        {
            try
            {
                var result = business.Get(o => o.ShopId == shopid);
                await business.RemoveAsync(result);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取申请
        /// </summary>
        /// <param name="shopid">商户id</param>
        /// <returns></returns>
        public AllianceBusiness GetApply(int shopid)
        {
            var result = business.Get(o=>o.ShopId==shopid);
            return result;
        }
        /// <summary>
        /// 获取申请列表
        /// </summary>
        /// <param name="page">页数</param>
        /// <param name="pagesize">记录</param>
        /// <returns></returns>
        public JsonReturn  GetApplys(int page, int pagesize)
        {
            if(page>0&pagesize>0)
            {
                var result = business.GetListPage(o=>true,page,pagesize);
                var total = business.GetTotalPage(o => true, pagesize);
                if(result==null)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound,"无记录");
                }
                return new JsonReturn<List<AllianceBusiness>>(result,total,"返回申请分页列表");
            }
            else
            {
                var result = business.GetList(o => true);
                if (result == null)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
                }
                return new JsonReturn<List<AllianceBusiness>>(result, result.Count, "返回申请列表(不分页)");
            }
           
        }
        /// <summary>
        /// 添加加盟卡
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <param name="name">姓名</param>
        /// <param name="money"></param>
        /// <returns></returns>
        public async Task<string> AddCard(int uid, string name,int money)
        {
            try
            {
                var card = new AllianceCard(uid, name);
                await cards.AddAsync(card);
                var result=await AddRecharge(uid,card.Id, money);
                return result;
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// 获取加盟卡
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public AllianceCard GetCard(int id)
        {
            var result = cards.Get(o => o.Uid == id);
            return result;
        }
        /// <summary>
        /// 获取加盟卡列表
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public JsonReturn GetCards(int page, int pagesize)
        {
            if (page > 0 & pagesize > 0)
            {
                var result = cards.GetListPage(o => true, page, pagesize);
                var total = cards.GetTotalPage(o => true, pagesize);
                if (result == null)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
                }
                return new JsonReturn<List<AllianceCard>>(result, total, "返回加盟卡分页列表");
            }
            else
            {
                var result = cards.GetList(o => true);
                if (result == null)
                {
                    return new JsonReturn(EnumJsonReturnStatus.NoFound, "无记录");
                }
                return new JsonReturn<List<AllianceCard>>(result, result.Count, "返回加盟卡列表(不分页)");
            }
        }
        /// <summary>
        /// 充值
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="cardid">卡号</param>
        /// <param name="money">金额</param>
        /// <returns></returns>
        public async Task<string> AddRecharge(int uid,string cardid, int money)
        {
            int cost =(int)(money * cardscale);
            
            try
            {
                var result = new CardRecharge(uid,cardid,money,cost);
                await charges.AddAsync(result);
                return result.Id;
            }
            catch
            {
                return "";
            }
        }
        /// <summary>
        /// 支付回调
        /// </summary>
        /// <param name="id">订单id</param>
        /// <returns></returns>
        public async Task<bool> PayNotify(string id)
        {
            var charge = GetRecharge(id);
            if (charge == null)
            {
                return false;
            }
            var card = GetCard(charge.CardId);
            if (card == null)
            {
                return false;
            }
            var upmoney = card.Money + charge.Money;
            //修改卡
            var filter = Builders<AllianceCard>.Filter.Eq("Id", charge.CardId);
            var update = Builders<AllianceCard>.Update.Set("Money", upmoney);
            var filter1 = Builders<CardRecharge>.Filter.Eq("Id", id);
            var update1 = Builders<CardRecharge>.Update.Set("IsPay", true);
            try
            {
                await cards.UpdateAsync(filter, update);
                await charges.UpdateAsync(filter1, update1);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取充值明细
        /// </summary>
        /// <param name="id">充值id</param>
        /// <returns></returns>
        public CardRecharge GetRecharge(string id)
        {
            var result = charges.Get(o => o.Id == id);
            return result;
        }
        /// <summary>
        /// 获取客户未支付列表
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        public List<CardRecharge> GetUnPayOrder(int uid)
        {
            if(uid<1)
            {
                var result = charges.GetList(o => !o.IsPay);
                return result;
            }
            else
            {
                var result = charges.GetList(o => o.Uid == uid&& !o.IsPay);
                return result;
            }
        }
        /// <summary>
        /// 获取加盟卡
        /// </summary>
        /// <param name="id">卡id</param>
        /// <returns></returns>
        public AllianceCard GetCard(string id)
        {
            var result = cards.Get(o => o.Id == id);
            return result;
        }
        /// <summary>
        /// 加盟卡使用
        /// </summary>
        /// <param name="card">卡id</param>
        /// <param name="money">扣除金额</param>
        /// <returns></returns>
        public async Task<int> CardUse(AllianceCard card, int money)
        {
            var canmoney= money;
            if(card.Money<money)
            {
                canmoney = card.Money;
            }
            //新余额
            var  upmoney = card.Money - canmoney;
            try
            {
                var filter = Builders<AllianceCard>.Filter.Eq("Id", card.Id);
                var update = Builders<AllianceCard>.Update.Set("Money", upmoney);
                await cards.UpdateAsync(filter,update);
                var result = new CardUse(card.Uid,card.Id, canmoney);
                await uses.AddAsync(result);

                return canmoney;
            }
            catch
            {
                return -1;
            }
        }
        /// <summary>
        /// 获取充值列表
        /// </summary>
        /// <param name="id">卡id</param>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="begintime"></param>
        /// <returns></returns>
        public JsonReturn GetCardCharge(string id, int page, int pagesize, DateTime begintime)
        {
            Expression<Func<CardRecharge, bool>> findstr = null;
            if (id == null || id.Length < 1)
            {
                findstr = o => o.CardId == id&&o.CreateTime>=begintime;
            }
            else
            {
                findstr = o => o.CreateTime >= begintime;
            }
            if (page > 0 & pagesize > 0)
            {
                var result = charges.GetListPage(findstr, page, pagesize);
                var total = charges.GetTotalPage(findstr, pagesize);
                return new JsonReturn<List<CardRecharge>>(result, total, "返回充值分页列表");
            }
            else
            {
                var result = charges.GetList(findstr);
                return new JsonReturn<List<CardRecharge>>(result, result.Count, "返回充值列表(不分页)");
            }
        }
        /// <summary>
        /// 获取使用列表
        /// </summary>
        /// <param name="id">卡id</param>
        /// <param name="page"></param>
        /// <param name="pagesize"></param>
        /// <param name="begintime"></param>
        /// <returns></returns>
        public JsonReturn GetCardUser(string id, int page, int pagesize, DateTime begintime)
        {
            Expression<Func<CardUse, bool>> findstr = null;
            if (id == null || id.Length < 1)
            {
                findstr = o => o.CardId == id && o.CreateTime >= begintime;
            }
            else
            {
                findstr = o => o.CreateTime >= begintime;
            }
            if (page > 0 & pagesize > 0)
            {
                var result = uses.GetListPage(findstr, page, pagesize);
                var total = uses.GetTotalPage(findstr, pagesize);
                return new JsonReturn<List<CardUse>>(result, total, "返回使用分页列表");
            }
            else
            {
                var result = uses.GetList(findstr);
                return new JsonReturn<List<CardUse>>(result, result.Count, "返回使用列表(不分页)");
            }
        }
    }
}
