﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 电子券接口
    /// </summary>
    public interface IElectronicVouchersService
    {
        /// <summary>
        /// 电子券发放
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<ElectronicVouchers> Distribute(ElectronicVouchersInput input);
        /// <summary>
        /// 电子券发放终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> Cancel(string id);
        /// <summary>
        /// 电子券领取
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<TakeVouchers> TakeGoods(TakeVouchersInput input);
        /// <summary>
        /// 电子券使用
        /// </summary>
        /// <param name="take">电子券</param>
        /// <returns></returns>
        Task<int> Use(TakeVouchers take);
        /// <summary>
        /// 获取电子券单明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ElectronicVouchers GetDetailed(string id);
        /// <summary>
        /// 获取领取单明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        TakeVouchers GetTakeDetailed(string id);
        /// <summary>
        /// 获取指定客户的已发电子券列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid">掌联用户</param>
        /// <param name="shopid">嗨派猫用户</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvalid">是否有效，否则全部</param>
        /// <returns></returns>
        List<ElectronicVouchers> GetList(out int total,int uid,int shopid, int PageIndex, int PageSize, bool isvalid);
        /// <summary>
        /// 获取指定领取客户的电子券列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">电子券id</param>
        /// <param name="uid">领取人id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsValid"></param>
        /// <returns></returns>
        List<TakeVouchers> GetTakeList(out int total,string id,int uid, int PageIndex, int PageSize, bool IsValid);
    }
    /// <summary>
    /// 电子券服务
    /// </summary>
    public class ElectronicVouchersService : IElectronicVouchersService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly Repository<ElectronicVouchers> Vouchers;
        private readonly Repository<TakeVouchers> Takes;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="config"></param>
        /// <param name="httpClientFactory"></param>
        public ElectronicVouchersService(IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            Vouchers = new Repository<ElectronicVouchers>(new MongoDBContext<ElectronicVouchers>(dbName, dbconn));
            Takes = new Repository<TakeVouchers>(new MongoDBContext<TakeVouchers>(dbName, dbconn));

            _httpClientFactory = httpClientFactory;
        }
        /// <summary>
        /// 电子券终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> Cancel(string id)
        {
            //更新数据
            var filter = Builders<ElectronicVouchers>.Filter.Eq("Id", id);
            var update = Builders<ElectronicVouchers>.Update.Set("IsValid", false);

            try
            {
                await Vouchers.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 电子券发放
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<ElectronicVouchers> Distribute(ElectronicVouchersInput input)
        {
            //数据提交
            try
            {
                var temp = new ElectronicVouchers(input);
                await Vouchers.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取指定商铺的申请列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid"></param>
        /// <param name="shopid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvalid"></param>
        /// <returns></returns>
        public List<ElectronicVouchers> GetList(out int total,int uid,int shopid, int PageIndex, int PageSize, bool isvalid)
        {
            //排序条件
            Expression<Func<ElectronicVouchers, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<ElectronicVouchers, bool>> condstr = null;
            if (isvalid)
            {
                if (uid <1)
                {
                    if (shopid > 0)
                    {
                        condstr = s => s.ZLUId == shopid && s.IsValid;
                    }
                    else
                    {
                        condstr = s => s.IsValid;
                    }
                }
                else 
                {
                    condstr = s => s.HPUId == uid && s.IsValid;
                }
            }
            else
            {
                if (uid <1)
                {
                    if (shopid > 0)
                    {
                        condstr = s => s.ZLUId == shopid;
                    }
                    else
                    {
                        condstr = s => true;
                    }
                }
                else
                {
                    condstr = s => s.HPUId == uid;
                }
            }
            var listtemp = Vouchers.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Vouchers.GetTotalPage(condstr, PageSize);
            return listtemp;
        }
        /// <summary>
        /// 获取指定电子券包的明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ElectronicVouchers GetDetailed(string id)
        {
            Expression<Func<ElectronicVouchers, bool>> findstr() { return f => f.Id == id; };

            var result = Vouchers.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取指定的领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public TakeVouchers GetTakeDetailed(string id)
        {
            Expression<Func<TakeVouchers, bool>> findstr() { return f => f.Id == id; };

            var result = Takes.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取指定电子券的列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<TakeVouchers> GetTakeList(out int total,string id, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<TakeVouchers, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<TakeVouchers, bool>> condstr = null;

            condstr = s => s.VouchersId == id;
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);
          
            return  listtemp;
        }
        /// <summary>
        /// 获取电子券列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id"></param>
        /// <param name="uid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvalid">true 仅查看有效电子券</param>
        /// <returns></returns>
        public List<TakeVouchers> GetTakeList(out int total,string id,int uid, int PageIndex, int PageSize,bool isvalid)
        {
            //排序条件
            Expression<Func<TakeVouchers, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<TakeVouchers, bool>> condstr = null;

            if (isvalid)
            {
                if (uid <1)
                {
                    if (string.IsNullOrEmpty(id))
                    {
                        condstr = s => s.Money > s.UseMoney && s.EndTime > DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.Id == id && s.Money>s.UseMoney&&s.EndTime>DateTime.Now;
                    }
                }
                else
                {
                    condstr = s => s.TakeId == uid && s.Money > s.UseMoney && s.EndTime > DateTime.Now;
                }
            }
            else
            {
                if (uid <1)
                {
                    if (string.IsNullOrEmpty(id))
                    {
                        condstr = s => true;
                    }
                    else
                    {
                        condstr = s => s.Id == id;
                    }
                }
                else
                {
                    condstr = s => s.TakeId == uid;
                }
            }
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);
          
            return listtemp;
        }
        /// <summary>
        /// 电子券
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<TakeVouchers> TakeGoods(TakeVouchersInput input)
        {
            var orders = GetDetailed(input.VouchersId);
            //判断有效性
            if (orders!=null&&orders.IsValid&&orders.TakeList.Count()<orders.Amount&&orders.EndTime>orders.CreateTime)
            {
                var temp=orders.TakeList.Append(input.TakeId);
                var filter = Builders<ElectronicVouchers>.Filter.Eq("Id", input.VouchersId);
                var update = Builders<ElectronicVouchers>.Update.Set("TakeList", temp);
                try
                {
                    await Vouchers.UpdateAsync(filter, update);
                    var result = new TakeVouchers(orders, input);
                    await Takes.AddAsync(result);
                    return result;
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 使用电子券
        /// </summary>
        /// <param name="take">电子券领取</param>
        /// <returns></returns>
        public async Task<int> Use(TakeVouchers take)
        {
            //更新数据
            try
            {
                await Takes.UpdateAsync(take);
                return take.Money;
            }
            catch
            {
                return -1;
            }
        }
        /// <summary>
        /// 支付提交
        /// </summary>
        /// <param name="input"></param>
        private JsonReturn<BatchPlaceOrderOutputDto> PayPost(PlaceOrderInputDto input)
        {
            var client = _httpClientFactory.CreateClient("MyClient");

            var content = new StringContent(JsonConvert.SerializeObject(input), Encoding.UTF8, "application/json");

            var result = client.PostAsync("/API/Order/PlaceOrder", content).Result.Content.ReadAsStringAsync().Result;
            var json = JsonConvert.DeserializeObject<JsonReturn<BatchPlaceOrderOutputDto>>(result);
  
            return json;
        }
     
    }
}
