﻿using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    #region 序号存储
    /// <summary>
    /// 序号存储
    /// </summary>
    public class RecnoStock : Core, IAggregateRoot
    {
        /// <summary>
        /// 序号类别
        /// </summary>
        [BsonElement("Kind")]
        public string Kind { get; set; }
        /// <summary>
        /// 保存的序号
        /// </summary>
        [BsonElement("Number")]
        public int Number { get; set; }
        /// <summary>
        /// 构造
        /// </summary>
        public RecnoStock()
        {

        }
        /// <summary>
        /// 构造，带参数
        /// </summary>
        /// <param name="kind">类别</param>
        public RecnoStock(string kind)
        {
            this.Kind = kind;
            this.Number = 1;
        }
    }
    #endregion
    /// <summary>
    /// 序号接口
    /// </summary>
    public interface IRecnoService
    {
        /// <summary>
        /// 获取序号
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        Task<int> Get(string kind);
        /// <summary>
        /// 获取序号
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        Task<int> GetNumber(string kind);
        /// <summary>
        /// 添加新类别
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        Task<bool> Add(string kind);
        /// <summary>
        /// 确定是否存在
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        bool IsExist(string kind);
    }
    /// <summary>
    /// 获取记录号服务
    /// </summary>
    public class ReconService : IRecnoService
    {
        private readonly IRepository<RecnoStock> recnos;
        public ReconService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            recnos = new MongoRespository<RecnoStock>(new MongoDBContext<RecnoStock>(dbName, dbconn));
        }
        /// <summary>
        /// 添加新序号
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        public async Task<bool> Add(string kind)
        {
            try
            {
                await recnos.AddAsync(new RecnoStock(kind));
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取序号
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        public async Task<int> GetNumber(string kind)
        {
            try
            {
                var result = recnos.GetQueryable(o => o.Kind == kind).FirstOrDefault();
                if (result != null)
                {
                    var mm = result.Number + 1;
                    var filter = Builders<RecnoStock>.Filter.Eq("Kind", kind);
                    var update = Builders<RecnoStock>.Update.Set("Number", mm);

                    await recnos.UpdateAsync(filter, update);
                    return mm;
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
        /// <summary>
        /// 确定是否存在
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        public bool IsExist(string kind)
        {
            try
            {
                var result = recnos.GetQueryable(o => o.Kind == kind).FirstOrDefault();
                if (result != null)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取序号
        /// </summary>
        /// <param name="kind"></param>
        /// <returns></returns>
        public async Task<int> Get(string kind)
        {
            if(IsExist(kind))
            {
                return await GetNumber(kind);
            }
            else
            {
                await Add(kind);
                return 1;
            }
        }
    }
}
