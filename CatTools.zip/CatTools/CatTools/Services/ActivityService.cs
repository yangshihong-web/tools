﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 活动接口
    /// </summary>
    public interface IActivityService
    {
        /// <summary>
        /// 活动申请
        /// </summary>
        /// <param name="input"></param>
        /// <param name="uid"></param>
        /// <param name="businessid"></param>
        /// <returns></returns>
        Task<Activity> ActivityApply(ActivityInput input,int uid,int businessid);
        /// <summary>
        /// 活动修改
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<bool> ActivityUpdate(Activity activity, ActivityInput input);
        /// <summary>
        /// 活动终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> Cancel(string id);
        /// <summary>
        /// 活动删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> DeleteActivity(string id);
        /// <summary>
        /// 购买活动
        /// </summary>
        /// <param name="order"></param>
        /// <param name="shareid"></param>
        /// <param name="purchaseid"></param>
        /// <returns></returns>
        Task<PurchaseActivity> Purchase(Activity order, int shareid, int purchaseid);
        /// <summary>
        /// 活动领取
        /// </summary>
        /// <param name="id"></param>
        /// <param name="takeid"></param>
        /// <returns></returns>
        Task<ActivityTake> Take(string id, int takeid);
        /// <summary>
        /// 购买活动核销标记
        /// </summary>
        /// <param name="id">购买id</param>
        /// <returns></returns>
        Task<bool> UsePurchase(string id);
        /// <summary>
        /// 领取活动核销
        /// </summary>
        /// <param name="id">领取id</param>
        /// <returns></returns>
        Task<bool> UseTake(string id);
        /// <summary>
        /// 更新用户浏览数
        /// </summary>
        /// <param name="id"></param>
        /// <param name="takeid"></param>
        /// <returns></returns>
        Task<int> UpdateBrowse(string id, int takeid);
        /// <summary>
        /// 活动支付标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> PayMark(string id);
        /// <summary>
        /// 支付完成在活动中添加购买人
        /// </summary>
        /// <param name="id"></param>
        /// <param name="takeid"></param>
        /// <returns></returns>
        Task<bool> ActivityMark(string id, int takeid);
        /// <summary>
        /// 活动购买向申请人支付
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> PayerPayMark(string id);
        /// <summary>
        /// 活动领取支付标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> PayTakeMark(string id);
        //***********************************************************************
        /// <summary>
        /// 获取活动明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Activity GetDetailed(string id);
        /// <summary>
        /// 获取领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ActivityTake GetTakeDetailed(string id);
        /// <summary>
        /// 获取购买明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        PurchaseActivity GetPurchaseDetailed(string id);
       
        //**************************************************************************
        /// <summary>
        /// 获取活动列表
        /// </summary>
        /// <param name="id"></param>
        /// <param name="kind"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsValid"></param>
        /// <returns></returns>
        JsonReturn GetActivityList(int id, ActivityType kind, int PageIndex, int PageSize, bool IsValid);
        /// <summary>
        /// 获取领取列表
        /// </summary>
        /// <param name="activityid"></param>
        /// <param name="uid"></param>
        /// <param name="takeid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsNoUse"></param>
        /// <param name="IsPay"></param>
        /// <returns></returns>
        JsonReturn GetTakeList(string activityid = "", int uid = 0, int takeid = 0, int PageIndex = 1, int PageSize = 15, bool IsNoUse = true, bool IsPay = true);
        /// <summary>
        /// 获取购买列表
        /// </summary>
        /// <param name="activityid">活动id</param>
        /// <param name="uid">发起人id</param>
        /// <param name="purchaseid">购买人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录数</param>
        /// <param name="IsCanUse">是否可使用</param>
        /// <param name="IsPay">是否支付</param>
        /// <returns></returns>
        JsonReturn GetPurchaseList(string activityid="",int uid=0,int purchaseid=0, int PageIndex=1, int PageSize=15, bool IsCanUse= true,bool IsPay=true);
        //*******************************************************************************************
        /// <summary>
        /// 添加账单
        /// </summary>
        /// <param name="code"></param>
        /// <param name="body"></param>
        /// <param name="uid"></param>
        /// <param name="monry"></param>
        /// <param name="kind"></param>
        /// <returns></returns>
        Task<bool> AddReceipt(string code, string body, int uid, int monry, string kind);
        /// <summary>
        /// 获取账单详细
        /// </summary>
        /// <param name="code"></param>
        /// <param name="kind"></param>
        /// <returns></returns>
        Receipt GetReceipt(string code,string kind);
        /// <summary>
        /// 获取指定用户的待收款明细
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="untransfer">未转账</param>
        /// <returns></returns>
        JsonReturn GetReceipts(int uid, int PageIndex = 1, int PageSize = 15, bool untransfer = true);
        /// <summary>
        /// 获取指定期限的未转账(分享人)列表
        /// </summary>
        /// <param name="days"></param>
        /// <returns></returns>
        List<Receipt> GetReceipts(int days = 0);
        /// <summary>
        /// 待收款标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> MarkReceipt(string id);
        /// <summary>
        /// 获取活动列表（不分页）
        /// </summary>
        /// <param name="activityid"></param>
        /// <returns></returns>
        List<PurchaseActivity> GetPurchaseList(string activityid);
    }
    /// <summary>
    /// 活动服务操作
    /// </summary>
    public class ActivityService: IActivityService
    {
        private readonly IRepository<Activity> activitys;
        private readonly IRepository<PurchaseActivity> purchases;
        private readonly IRepository<ActivityTake> takes;
        private readonly IRepository<Receipt>  receipts;
 

        public ActivityService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            activitys = new  MongoRespository<Activity>(new MongoDBContext<Activity>(dbName,dbconn));
            purchases = new MongoRespository<PurchaseActivity>(new MongoDBContext<PurchaseActivity>(dbName, dbconn));
            takes = new MongoRespository<ActivityTake>(new MongoDBContext<ActivityTake>(dbName, dbconn));
            receipts = new MongoRespository<Receipt>(new MongoDBContext<Receipt>(dbName, dbconn));
        }
        /// <summary>
        /// 活动申请
        /// </summary>
        /// <param name="input"></param>
        /// <param name="uid"></param>
        /// <param name="businessid"></param>
        /// <returns>成功返回活动内容，失败空记录</returns>
        public async Task<Activity> ActivityApply(ActivityInput input,int uid,int businessid)    
        {
            //数据提交
            try
            {
                var temp = new Activity(input,uid,businessid);
                await activitys.AddAsync(temp);
                var result = GetDetailed(temp.Id);
                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 修改活动内容
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<bool> ActivityUpdate(Activity activity,ActivityInput input)
        {
          
           //数据提交
            try
            {
                //获取修改列表
                var properts = activity.UpdateList(input);
                await activitys.UpdateAsync(activity, properts);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 购买活动
        /// </summary>
        /// <param name="order"></param>
        /// <param name="shareid"></param>
        /// <param name="purchaseid"></param>
        /// <returns></returns>
        public async Task<PurchaseActivity> Purchase(Activity order, int shareid,int purchaseid)
        {
                try
                {
                    //保存购买记录
                    var result = new PurchaseActivity(order, shareid, purchaseid);
                    await purchases.AddAsync(result);
                    return result;
                }
                catch
                {
                    return null;
                }
        }
        /// <summary>
        /// 活动领取
        /// </summary>
        /// <param name="id">活动id</param>
        /// <param name="takeid">领取人id</param>
        /// <returns></returns>
        public async Task<ActivityTake> Take(string id, int takeid)
        {
            //获取活动
            var orders = GetDetailed(id);
            //判断活动有效性
            if (orders != null&& orders.IsValid && orders.EndTime > DateTime.Now && orders.ParticipateList.Count() < orders.Amount && !orders.ParticipateList.Contains(takeid))
            {
                try
                {
                    //保存领取记录
                    var result = new ActivityTake(orders, takeid);
                    await takes.AddAsync(result);
                    return result;
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 在活动中标记购买人
        /// </summary>
        /// <param name="id"></param>
        /// <param name="takeid"></param>
        /// <returns></returns>
        public async Task<bool> ActivityMark(string id, int takeid)
        {
            //获取活动
            var orders = GetDetailed(id);
            if (orders != null)
            {
                //更新购买人列表
                var filter = Builders<Activity>.Filter.Eq("Id", id);
                var update = Builders<Activity>.Update.Set("ParticipateList", orders.ParticipateList.Append(takeid));
                try
                {
                    await activitys.UpdateAsync(filter, update);

                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 顾客领取购买活动后标记
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        public async Task<bool> UsePurchase(string id)
        {
               //更新数据
                var filter = Builders<PurchaseActivity>.Filter.Eq("Id", id);
                var update = Builders<PurchaseActivity>.Update.Set("IsUsed", true);
                try
                {
                    await purchases.UpdateAsync(filter, update);
                    return true;
                }
                catch
                {
                    return false;
                }
              
        }
        /// <summary>
        /// 顾客领取使用活动后标记
        /// </summary>
        /// <param name="id">活动id</param>
        /// <returns></returns>
        public async Task<bool> UseTake(string id)
        {
                //更新数据
                var filter = Builders<ActivityTake>.Filter.Eq("Id", id);
                var update = Builders<ActivityTake>.Update.Set("IsUsed", true);
                try
                {
                    await takes.UpdateAsync(filter, update);
                    return true;
                }
                catch
                {
                    return false;
                }
     
        }
        /// <summary>
        /// 活动终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> Cancel(string id)
        {
            //更新数据
            var filter = Builders<Activity>.Filter.Eq("Id", id);
            var update = Builders<Activity>.Update.Set("IsValid", false);
            try
            {
                await activitys.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 删除活动
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> DeleteActivity(string id)
        {
            var entity= activitys.GetQueryable(o=>o.Id==id).FirstOrDefault();
            if(entity==null)
            {
                return false;
            }
            try
            {
                await activitys.RemoveAsync(entity);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取活动明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Activity GetDetailed(string id)
        {
            Expression<Func<Activity, bool>> findstr=f => f.Id == id;
            try
            {
                var result = activitys.GetQueryable(findstr).FirstOrDefault();

                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取购买明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public PurchaseActivity GetPurchaseDetailed(string id)
        {
            Expression<Func<PurchaseActivity, bool>> findstr=f => f.Id == id;
            try
            {
                var result = purchases.GetQueryable(findstr).FirstOrDefault();
                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 获取领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActivityTake GetTakeDetailed(string id)
        {
            Expression<Func<ActivityTake, bool>> findstr = f => f.Id == id;
            try
            {
                var result = takes.GetQueryable(findstr).FirstOrDefault();
                return result;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 更新浏览人
        /// </summary>
        /// <param name="id"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        public async Task<int> UpdateBrowse(string id,int uid)
        {
            //获取活动
            var orders = GetDetailed(id);
            if(orders==null)
            {
                return 0;
            }
            var filter = Builders<Activity>.Filter.Eq("Id", id);
            var update = Builders<Activity>.Update.Set("BrowseList", orders.BrowseList.Append(uid));
            try
            {
                await activitys.UpdateAsync(filter, update);
                return orders.BrowseList.Count();
            }
            catch
            {
                return 0;
            }
        }
        /// <summary>
        /// 获取领取列表
        /// </summary>
        /// <param name="activityid"></param>
        /// <param name="uid"></param>
        /// <param name="takeid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsCanUse"></param>
        /// <param name="IsPay"></param>
        /// <returns></returns>
        public JsonReturn GetTakeList(string activityid = "", int uid = 0, int takeid = 0, int PageIndex = 1, int PageSize = 15, bool IsCanUse = true, bool IsPay = true)
        {
            //排序条件
            Expression<Func<ActivityTake, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<ActivityTake, bool>> condstr = s => s.IsUsed ==false && s.IsPay == IsPay;
            //活动id
            if (activityid != null && activityid.Length > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.ActivityId == activityid ;
                    }
                    else
                    {
                        condstr = s => s.ActivityId == activityid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.ActivityId == activityid&&!s.IsUsed&&s.EndTime>=DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.ActivityId == activityid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }
            //发起人id
            if (uid > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.UId == uid;
                    }
                    else
                    {
                        condstr = s => s.UId == uid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.UId == uid && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.UId == uid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }
            //领取人id
            if (takeid > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.TakeId == takeid;
                    }
                    else
                    {
                        condstr = s => s.TakeId == takeid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.TakeId == takeid && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.TakeId == takeid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }

            var listtemp = takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            var totaltemp = takes.GetTotalPage(condstr, PageSize);
            if (listtemp!=null&&listtemp.Count() > 0)
            {
                return new JsonReturn<List<ActivityTake>>(listtemp, totaltemp, "返回活动的领取记录");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无领取记录");
            }
        }

        /// <summary>
        /// 获取购买列表
        /// </summary>
        /// <param name="activityid">活动id,</param>
        /// <param name="uid">发起人id</param>
        /// <param name="purchaseid">购买人id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="IsCanUse ">是否未使用</param>
        /// <param name="IsPay">是否支付</param>
        /// <returns></returns>
        public JsonReturn GetPurchaseList(string activityid = "", int uid = 0, int purchaseid = 0, int PageIndex = 1, int PageSize = 15, bool IsCanUse = true, bool IsPay = true)
        {
            //排序条件
            Expression<Func<PurchaseActivity, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<PurchaseActivity, bool>> condstr =s=> s.IsUsed == false && s.IsPay == IsPay;
            if (activityid != null && activityid.Length > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.ActivityId == activityid;
                    }
                    else
                    {
                        condstr = s => s.ActivityId == activityid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.ActivityId == activityid && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.ActivityId == activityid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }
            //发起人id
            if (uid > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.UId == uid;
                    }
                    else
                    {
                        condstr = s => s.UId == uid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.UId == uid && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.UId == uid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }
            //领取人id
            if (purchaseid > 0)
            {
                if (!IsCanUse)
                {
                    if (!IsPay)
                    {
                        condstr = s => s.PurchaseId == purchaseid;
                    }
                    else
                    {
                        condstr = s => s.PurchaseId == purchaseid && s.IsPay == IsPay;
                    }
                }
                else
                {
                    if (!IsPay)
                    {
                        condstr = s => s.PurchaseId == purchaseid && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                    else
                    {
                        condstr = s => s.PurchaseId == purchaseid && s.IsPay == IsPay && !s.IsUsed && s.EndTime >= DateTime.Now;
                    }
                }
            }

            var listtemp = purchases.GetListPage(condstr, orderstr, PageIndex, PageSize);
            var retlist = new List<PurchaseActivityModel>();
            foreach(var n in listtemp)
            {
                var activity = activitys.Get(o => o.Id == n.ActivityId);
                var m = new PurchaseActivityModel()
                {
                    Id = n.Id,
                    ActivityId = n.ActivityId,
                    CreateTime = n.CreateTime,
                    EndTime = n.EndTime,
                    Instructions = activity.Instructions,
                    IsPay = n.IsPay,
                    IsUsed = n.IsUsed,
                    Picture = activity.Picture,
                    Price = n.Price,
                    PurchaseId = n.PurchaseId,
                    ShareID = n.ShareID,
                    ShareMoney = n.ShareMoney,
                    UId = n.UId,
                    Title = activity.Title
                };
                retlist = retlist.Append(m).ToList();
            };
            var totaltemp = purchases.GetTotalPage(condstr, PageSize);
            if (listtemp != null && listtemp.Count() > 0)
            {
                return new JsonReturn<List<PurchaseActivityModel>>(retlist, totaltemp, "返回购买列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无购买记录");
            }
            
        }
        /// <summary>
        /// 获取活动列表（不分页）
        /// </summary>
        /// <param name="activityid"></param>
        /// <returns></returns>
        public List<PurchaseActivity> GetPurchaseList(string activityid)
        {
            //排序条件
            Expression<Func<PurchaseActivity, DateTime>> orderstr = item => item.CreateTime;
            Expression<Func<PurchaseActivity, bool>> condstr = s =>s.ActivityId==activityid&& s.IsPay;
            var result = purchases.GetList(condstr, orderstr).ToList();
            return result;
        }
        /// <summary>
        /// 获取活动列表
        /// </summary>
        /// <param name="id">发起人编号</param>
        /// <param name="kind"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsValid"></param>
        /// <returns></returns>
        public JsonReturn GetActivityList(int id, ActivityType kind, int PageIndex, int PageSize, bool IsValid)
        {
            //排序条件
            Expression<Func<Activity, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<Activity, bool>> condstr = s => s.UId == id;
            if (IsValid)
            {
                if (id == 0)
                {
                    condstr = s => s.Kind == kind&&s.IsValid;
                }
                else
                {
                    //仅查看有效记录
                    condstr = s => s.UId == id &&s.Kind==kind&& s.IsValid;
                }
            }
            else
            {
                if (id == 0)
                {
                    condstr = s => s.Kind == kind ;
                }
                else
                {
                    //仅查看有效记录
                    condstr = s => s.Kind == kind && s.IsValid;
                }
            }
            var listtemp = activitys.GetListPage(condstr, orderstr, PageIndex, PageSize);
            var totaltemp = activitys.GetTotalPage(condstr, PageSize);

            
            if (listtemp != null && listtemp.Count() > 0)
            {
                return new JsonReturn<List<Activity>>(listtemp, totaltemp, "返回活动的列表");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无活动记录");
            }
        }
        /// <summary>
        /// 活动支付标记,活动申请向平台支付
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> PayMark(string id)
        {
            //更新数据
            var filter = Builders<Activity>.Filter.Eq("Id", id);
            var update = Builders<Activity>.Update.Set("IsPay", true);

            try
            {
                await activitys.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 向申请人支付标记，活动购买支付
        /// </summary>
        /// <param name="id">购买id</param>
        /// <returns></returns>
        public async Task<bool> PayerPayMark(string id)
        {
            //更新数据
            var filter = Builders<PurchaseActivity>.Filter.Eq("Id", id);
            var update = Builders<PurchaseActivity>.Update.Set("IsPay", true);

            try
            {
                await purchases.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 提交待收款
        /// </summary>
        /// <param name="code"></param>
        /// <param name="body"></param>
        /// <param name="uid"></param>
        /// <param name="money"></param>
        /// <param name="kind"></param>
        /// <returns></returns>
        public async Task<bool> AddReceipt(string code,string body, int uid, int money,string kind)
        {
            try
            {
                await receipts.AddAsync(new Receipt(code,body, uid, money,kind));
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取账务明细
        /// </summary>
        /// <param name="code"></param>
        /// <param name="kind"></param>
        /// <returns></returns>
        public Receipt GetReceipt(string code,string kind)
        {
            var result = receipts.Get(o => o.Id == code&&o.Kind==kind);
            return result;
        }
        /// <summary>
        /// 获取待收款列表
        /// </summary>
        /// <param name="uid">用户id</param>
        /// <param name="PageIndex">页数</param>
        /// <param name="PageSize">每页记录</param>
        /// <param name="untransfer">是否未转账</param>
        /// <returns>返回指定用户的账务明细</returns>
        public JsonReturn GetReceipts(int uid, int PageIndex = 1, int PageSize = 15, bool untransfer = true)
        {
            Expression<Func<Receipt, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<Receipt, bool>> condstr = null;
            if (uid < 1)
            {
                if (untransfer)
                {
                    condstr = o => !o.IsTransfer;
                }
                else
                {
                    condstr = o => true;
                }
            }
            else
            {
                if (untransfer)
                {
                    condstr = o => o.Uid == uid && !o.IsTransfer;
                }
                else
                {
                    condstr = o => o.Uid == uid;
                }
            }
            var listtemp = receipts.GetListPage(condstr, orderstr, PageIndex, PageSize);
            var totaltemp = receipts.GetTotalPage(condstr, PageSize);
            var result = new List<ReceiptModel>();
            foreach (var n in listtemp)
            {
                int days = 0;
                if (n.CreateTime.AddDays(10) > DateTime.Now)
                {
                    var day = n.CreateTime.AddDays(10).Date - DateTime.Now.Date;
                    days =(int)day.TotalDays;
                }
                var mm = new ReceiptModel()
                {
                    Body = n.Body,
                    Code = n.Code,
                    Money = n.Money,
                    CreateTime = n.CreateTime,
                    IsTransfer = n.IsTransfer,
                    Days = 0
                };
                if (days>0)
                {
                    mm.Days = days;
                }
                result.Add(mm);
            }
            if (listtemp != null && listtemp.Count() > 0)
            {
                return new JsonReturn<List<ReceiptModel>>(result, totaltemp, "返回待收款明细");
            }
            else
            {
                return new JsonReturn(EnumJsonReturnStatus.NoFound, "无待收款记录");
            }
            
        }
        /// <summary>
        /// 达到规定天数，未转账（分享人）
        /// </summary>
        /// <param name="days">小于1全部</param>
        /// <returns></returns>
        public List<Receipt> GetReceipts(int days = 0)
        {
            try
            {
                if (days<1)
                {
                    var result = receipts.GetQueryable(o => o.Kind=="分享人" ).ToList();
                    return result;
                }
                else
                {

                    var result = receipts.GetQueryable(o => o.Kind == "分享人"&&!o.IsTransfer && o.CreateTime.AddDays(days) < DateTime.Now).ToList();
                    return result;
                }
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 待收款标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> MarkReceipt(string id)
        {
            var filter = Builders<Receipt>.Filter.Eq("Id", id);
            var update = Builders<Receipt>.Update.Set("IsTransfer", true);
            try
            {
                await receipts.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 活动领取支付标记
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> PayTakeMark(string id)
        {
            //更新数据
            var filter = Builders<ActivityTake>.Filter.Eq("Id", id);
            var update = Builders<ActivityTake>.Update.Set("IsPay", true);

            try
            {
                await takes.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
