﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CatTools.Services
{
    #region  ///礼品服务接口  IGoodsService
    /// <summary>
    /// 礼品服务接口
    /// </summary>
    public interface IGoodsService
    {
        /// <summary>
        /// 礼品发放
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<GoodsOrders> Distribute(GoodsOrdersInput input);
        /// <summary>
        /// 礼品发放终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> Cancel(int id);
        /// <summary>
        /// 礼品领取
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<GoodsTakeOrders> TakeGoods(GoodsTakeOrdersInput input);
        /// <summary>
        /// 礼品发货
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> SendGoods(string id);
        /// <summary>
        /// 获取礼品单明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        GoodsOrders GetOrderDetailed(int id);
        /// <summary>
        /// 获取领取单明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        GoodsTakeOrders GetTakeDetailed(string id);
        /// <summary>
        /// 获取指定客户的已发礼品单列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid">发放人，空值显示全部</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvalid">是否有效，否则全部</param>
        /// <returns></returns>
        List<GoodsOrders> GetList(out int total,int uid,int PageIndex, int PageSize,bool isvalid);
        /// <summary>
        /// 获取指定礼品单的领取列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">礼品单号</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsSend"></param>
        /// <returns></returns>
        List<GoodsTakeOrders> GetTakeList(out int total, int id, int PageIndex, int PageSize, bool IsSend);
        /// <summary>
        /// 获取指定客户的领取列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid">领取人</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        List<GoodsTakeOrders> GetTakeListByUid(out int total, int uid, int PageIndex, int PageSize);
    }
    #endregion
    #region //礼品服务 GoodsService
    /// <summary>
    /// 礼品服务
    /// </summary>
    public class GoodsService : IGoodsService
    {
        private readonly Repository<GoodsOrders>  Orders;
        private readonly Repository<GoodsTakeOrders> Takes;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="config"></param>
        public GoodsService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            Orders = new Repository<GoodsOrders>(new MongoDBContext<GoodsOrders>(dbName, dbconn));
            Takes = new Repository<GoodsTakeOrders>(new MongoDBContext<GoodsTakeOrders>(dbName, dbconn));
        }
        /// <summary>
        /// 礼品发放
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<GoodsOrders> Distribute(GoodsOrdersInput input)
        {
            //数据提交
            try
            {
                var temp = new GoodsOrders(input);
                await Orders.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 礼品发放终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> Cancel(int id)
        {
            //更新数据
            var filter = Builders<GoodsOrders>.Filter.Eq("OrdersId", id);
            var update = Builders<GoodsOrders>.Update.Set("IsValid", false);

            try
            {
                await Orders.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 礼品领取
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<GoodsTakeOrders> TakeGoods(GoodsTakeOrdersInput input)
        {
            var orders = GetOrderDetailed(input.OrdersId);
            //判断有效性
            if (orders!=null&&orders.IsCanTake())
            {
                try
                {
                    var temp = new GoodsTakeOrders(orders,input);
                    await Takes.AddAsync(temp);
                    return temp;
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 通过id获得礼品包明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public GoodsOrders GetOrderDetailed(int id)
        {
            Expression<Func<GoodsOrders, bool>> findstr() { return f => f.OrderId == id; };

            var result = Orders.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 通过id获得领取礼包的领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public GoodsTakeOrders GetTakeDetailed(string id)
        {
            Expression<Func<GoodsTakeOrders, bool>> findstr() { return f => f.Id == id; };

            var result = Takes.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取指定发放用户的发放礼品单列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="isvalid"></param>
        /// <returns></returns>
        public List<GoodsOrders> GetList(out int total,int uid, int PageIndex, int PageSize, bool isvalid)
        {
            //排序条件
            Expression<Func<GoodsOrders, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<GoodsOrders, bool>> condstr = null;
            if (isvalid)
            {
                condstr = s => s.UserId == uid && s.IsValid;
            }
            else
            {
                condstr = s => s.UserId == uid;
            }
            var listtemp = Orders.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Orders.GetTotalPage(condstr, PageSize);
            return listtemp;
        }
        /// <summary>
        /// 获取指定订单的领取单列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">礼品单号</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsSend">true,仅查看未发送的</param>
        /// <returns></returns>
        public List<GoodsTakeOrders> GetTakeList(out int total, int id, int PageIndex, int PageSize,bool IsSend)
        {
            //排序条件
            Expression<Func<GoodsTakeOrders, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<GoodsTakeOrders, bool>> condstr = null;

            if (IsSend)
            {
                condstr = s => s.OrdersId == id && !s.IsDelivered;
            }
            else
            {
                condstr = s => s.OrdersId == id;
            }
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
        /// <summary>
        /// 获取指定领取人的领取列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="uid">领取人</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<GoodsTakeOrders> GetTakeListByUid(out int total, int uid, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<GoodsTakeOrders, DateTime>> orderstr = item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<GoodsTakeOrders, bool>> condstr = null;
        
            condstr = s => s.TakeUserId == uid;
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
        /// <summary>
        /// 标记发货
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> SendGoods(string id)
        {
            //更新数据
            var filter = Builders<GoodsTakeOrders>.Filter.Eq("Id", id);
            var update = Builders<GoodsTakeOrders>.Update.Set("IsIsDelivered", true);

            try
            {
                await Takes.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
    #endregion
}
