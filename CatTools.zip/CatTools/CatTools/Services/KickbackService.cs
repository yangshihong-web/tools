﻿using CarTools.Services;
using CarTools.Shares;
using CatTools.Models;
using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CatTools.Services
{
    /// <summary>
    /// 红包接口
    /// </summary>
    public interface IKickbackService
    {
        /// <summary>
        /// 生成红包
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        Task<Kickback> NewKickback(KickbackDistribute input);
        /// <summary>
        /// 红包终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> EndKickback(string id);
        /// <summary>
        /// 红包有效性检查
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        bool CheckKickback(string id);
        /// <summary>
        /// 获取红包明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Kickback GetDetailed(string id);
        /// <summary>
        /// 获取红包列表(分页),指定发放人
        /// </summary>
        /// <param name="total"></param>
        /// <param name="SenManId"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsValid">true选定有效红包，false选定全部红包</param>
        /// <returns></returns>
        List<Kickback> GetList(out int total,int SenManId,int PageIndex, int PageSize,bool IsValid);
        /// <summary>
        /// 红包领取
        /// </summary>
        /// <param name="input"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        Task<TakeKickback> NewKickbackTake(TakeKickbackInput input, UserOutputDto user);
        /// <summary>
        /// 获取红包领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        TakeKickback GetTakeDetailed(string id);
        /// <summary>
        /// 获取指定红包的领取列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">红包id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        List<TakeKickback> GetTakeList(out int total, string id, int PageIndex, int PageSize);
        /// <summary>
        /// 获取指定领取人的领取列表(分页)
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">领取人id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        List<TakeKickback> GetTakeListByTakeMan(out int total, int id, int PageIndex, int PageSize);
    }
    /// <summary>
    /// 红包服务
    /// </summary>
    public class KickbackService : IKickbackService
    {
        private readonly Repository<Kickback> Kicks;
        private readonly Repository<TakeKickback> Takes;
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="config"></param>
        public KickbackService(IConfiguration config)
        {
            var dbconn = config.GetConnectionString("ToolsClient");
            var dbName = "ToolsDb";
            Kicks = new Repository<Kickback>(new MongoDBContext<Kickback>(dbName, dbconn));
            Takes = new Repository<TakeKickback>(new MongoDBContext<TakeKickback>(dbName, dbconn));
        }
        /// <summary>
        /// 红包有效性检查
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool CheckKickback(string id)
        {
            var result = false;
            var temp = GetDetailed(id);
            if (temp!=null&&temp.EndTime >= DateTime.Now&&temp.IsValid&&temp.Money>temp.TakeMoney&&temp.People>temp.TakePeople)
            {
                result = true;
            }
            return result;
        }
        /// <summary>
        /// 红包终止
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<bool> EndKickback(string id)
        {
            //更新红包信息
            var filter = Builders<Kickback>.Filter.Eq("Id", id);
            var update = Builders<Kickback>.Update.Set("IsValid", false);
            try
            {
                await Kicks.UpdateAsync(filter, update);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取红包明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Kickback GetDetailed(string id)
        {
            Expression<Func<Kickback, bool>> findstr() { return f => f.Id == id; };

            var result = Kicks.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取指定发送人的红包列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="SenManId"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <param name="IsValid"></param>
        /// <returns></returns>
        public List<Kickback> GetList(out int total, int SenManId, int PageIndex, int PageSize, bool IsValid=false)
        {
            //排序条件
            Expression<Func<Kickback, DateTime>> orderstr=item => item.CreateTime;
            //传入条件为空，则返回全部
            Expression<Func<Kickback, bool>> condstr = null;
            if (IsValid)
            {
                condstr= s => s.SendManId == SenManId&&s.IsValid;
          }
            else
            {
                condstr= s => s.SendManId == SenManId;
            }
            var listtemp = Kicks.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Kicks.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
    

        /// <summary>
        /// 获取领取明细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public TakeKickback GetTakeDetailed(string id)
        {
            Expression<Func<TakeKickback, bool>> findstr() { return f => f.Id == id; };

            var result = Takes.GetQueryable(findstr()).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取指定红包的领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id">红包id</param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<TakeKickback> GetTakeList(out int total, string id, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<TakeKickback, DateTime>> orderstr=item => item.TakeTime; 
            //
            Expression<Func<TakeKickback, bool>> condstr=s => s.KickbackId==id;
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
        /// <summary>
        /// 获取指定领取人领取列表
        /// </summary>
        /// <param name="total"></param>
        /// <param name="id"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<TakeKickback> GetTakeListByTakeMan(out int total, int id, int PageIndex, int PageSize)
        {
            //排序条件
            Expression<Func<TakeKickback, DateTime>> orderstr=item => item.TakeTime;
            //
            Expression<Func<TakeKickback, bool>> condstr=s => s.TakeManId == id; 
            var listtemp = Takes.GetListPage(condstr, orderstr, PageIndex, PageSize);
            total = Takes.GetTotalPage(condstr, PageSize);

            return listtemp;
        }
        /// <summary>
        /// 红包发放
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<Kickback> NewKickback(KickbackDistribute input)
        {
            //数据提交
            try
            {
                var temp = new Kickback(input);
                await Kicks.AddAsync(temp);
                return temp;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 红包领取
        /// </summary>
        /// <param name="input"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<TakeKickback> NewKickbackTake(TakeKickbackInput input,UserOutputDto user)
        {
            //获取红包信息
            var temp = GetDetailed(input.KickbackId);
            //数据提交,更新发放表,余额，余人数，有效,未过期
            if (temp!=null&&temp.Money >= temp.TakeMoney + temp.SingleMoney && temp.People >= temp.TakePeople + 1&&temp.IsValid&&temp.EndTime>=DateTime.Now)
            {
                temp.TakeMoney = temp.TakeMoney + temp.SingleMoney;
                temp.TakePeople = temp.TakePeople + 1;
                //获取领取人信息
                          await Kicks.UpdateAsync(temp);
                var filter = Builders<Kickback>.Filter.Eq("Id", temp.Id);
                var update = Builders<Kickback>.Update.Set("TakePeople", temp.TakePeople);
                //保存领取记录
                var create = new TakeKickback(input, user, temp.SingleMoney);

                try
                {
                    var result = new TakeKickback(input, user, temp.SingleMoney);
                    await Takes.AddAsync(result);
                    await Kicks.UpdateAsync(filter, update);
                    return result;
                }
                catch
                {
                    return null;
                }
            }
            else
            {
                //红包已经过期或者无效
                return null;
            }
        }
    }
}
