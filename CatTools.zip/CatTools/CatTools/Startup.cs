﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Reflection;
using CarTools.Shares;
using CatTools.Services;
using CatTools.Shares;
using log4net;
using log4net.Config;
using log4net.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Polly;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace CatTools
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            //log4net
            Repository = LogManager.CreateRepository("NETCoreRepository");
            //指定配置文件
            XmlConfigurator.Configure(Repository, new FileInfo("nolg.config"));
        }

        public IConfiguration Configuration { get; }
        /// <summary>
        /// 日志
        /// </summary>
        public static ILoggerRepository Repository { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //
            services.AddScoped<IGoodsService, GoodsService>();
            services.AddScoped<IKickbackService, KickbackService>();
            services.AddScoped<IElectronicVouchersService, ElectronicVouchersService>();
            services.AddScoped<IMarketingService, MarketingService>();
            services.AddScoped<IActivityService, ActivityService>();
            services.AddScoped<IClientService, ClientService>();
            services.AddScoped<IRiderService, RiderService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IRecnoService, ReconService>();
            services.AddScoped<IHPMGoodsService, HPMGoodsService>();
            services.AddSingleton<IMarketingCouponsService, MarketingCouponsService>();
            services.AddSingleton<IDiscountService,DiscountService>();
            services.AddSingleton<IAppointmentService, AppointmentService>();
            services.AddSingleton<IPayRecnoService, PayRecnoService>();
            //services.AddSession();
            services.AddMemoryCache();
            services.AddHttpClient();
            //
            var timeout = Polly.Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(20));
            services.AddHttpClient("UserClient", client =>
            {
                // 配置用户 API 的主域名
                client.BaseAddress = new Uri("http://zjzlsq.cn");

            })
            .AddPolicyHandler(request => timeout)
            .AddTransientHttpErrorPolicy(p => p.RetryAsync(3));

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "嗨派猫工具端 API", Version = "v1" });
                //var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                //c.IncludeXmlComments(xmlPath);
                c.CustomSchemaIds(type => type.FullName); // 解决相同类名会报错的问题
                //c.IncludeXmlComments(Path.Combine(Directory.GetCurrentDirectory(), "CatTools.xml")); // 标注要使用的 XML 文档
                c.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, $"{typeof(Startup).Assembly.GetName().Name}.xml"), true);

                //添加自定义参数，可通过一些特性标记去判断是否添加
                c.OperationFilter<AssignOperationVendorExtensions>();                  //提交session令牌
                //添加对控制器的标签(描述)
                c.DocumentFilter<ApplyTagDescriptions>();
            });
            //设置跨域
            services.AddCors(options =>
            {
                options.AddPolicy("any", builder =>
                {
                    builder.AllowAnyOrigin() //允许任何来源的主机访问
                                             //builder.WithOrigins("http://zjzlsq.cn")                    ////允许http://zjzlsq.cn的主机访问
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials();//指定处理cookie
                });
            });
          
            //设置时间格式
            services.AddMvc(options =>
            {
           
                options.Filters.Add<GlobalExceptionFilter>();                //全局异常处理
              
                options.Filters.Add<ApiResultFilterAttribute>();             //输入模型验证
            })
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
            .AddJsonOptions(options =>
            {
                //混合大小写
                //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
                options.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm:ss";
            });
            //设置验证模型的返回
            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;

            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                //app.UseExceptionHandler("/error"); 
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            //app.UseDirectoryBrowser();
            app.UseSwagger();
            //app.UseSession();
            app.UseSwaggerUI(c =>
            {
                c.ShowExtensions();
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "嗨派猫工具端 API V1");
                c.RoutePrefix = string.Empty;
            });
            app.UseCors("any");
            app.UseMvc();
        }
    }
    //添加标签
    public class ApplyTagDescriptions : IDocumentFilter
    {
        public void Apply(SwaggerDocument swaggerDoc, DocumentFilterContext context)
        {
            swaggerDoc.Tags = new List<Tag>
            {
            //添加对应的控制器描述 这个是好不容易在issues里面翻到的
              new Tag { Name = "Kickback", Description = "红包服务接口" },
              new Tag { Name = "ElectronicVouchers", Description = "电子券服务接口"},
              new Tag { Name = "Goods", Description = "礼品采购接口"},
              new Tag { Name = "Marketing", Description = "申请加盟服务接口"},
              new Tag { Name = "Activity", Description = "活动工具服务接口"},
              new Tag { Name = "Rider", Description = "外卖派送服务接口（含用户管理）"},
              new Tag { Name = "Document", Description = "核销通用接口，由后台使用"},
              new Tag { Name = "Discount", Description = "折扣券接口"},
              new Tag { Name = "Appointment", Description = "预约服务接口"},
              new Tag { Name = "MarketingCoupons", Description = "新人营销券服务接口"}
            };
        }
    }
  
}
