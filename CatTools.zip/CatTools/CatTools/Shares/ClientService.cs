﻿using CarTools.Shares;
using CatTools.Models;
using log4net;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CatTools.Shares
{
    /// <summary>
    /// 后台调用接口
    /// </summary>
    public interface IClientService
    {
        /// <summary>
        /// 更新代金券
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool UpdateUserCoupon(IncreaseCouponInputDto data);
        /// <summary>
        /// 获取用户信息，通过电话
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        UserOutputDto GetUserByPhone(string phone);
        /// <summary>
        /// 用户验证
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        ReturnAuthenReturnData UserAuthen(string session);
        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        OutData UserLogin(string phone, string password);
        /// <summary>
        /// 修改用户资产
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool UpdateBalance(BalnaceUpdateData data);
        /// <summary>
        /// 修改冻结资产
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool UpdateFreezeBalance(BalnaceUpdateData data);
        /// <summary>
        /// 派单通知
        /// </summary>
        /// <param name="data">通知数据</param>
        /// <returns></returns>
        bool DeliveryNotice(DeliveryNoticeDto data);
        /// <summary>
        /// short mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool SmsPush(SmsInputDto data);
        /// <summary>
        /// aurora mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool MessagePush(MessagePushInputDto data);
        /// <summary>
        /// wechat template push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool WeChatTemplate(PushTemplateMessageInputDto data);
        /// <summary>
        /// wechat small mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        bool WeChatSmall(PushTemplateMsgOutputDto data);
        /// <summary>
        /// 微信支付提交
        /// </summary>
        /// <param name="userid">用户id</param>
        /// <param name="data">支付数据</param>
        /// <returns></returns>
        JsonReturn WeChatPayment(int userid,WeChatPaymentInputDto data);
        /// <summary>
        /// 微信公众号支付提交
        /// </summary>
        /// <param name="userid">用户id</param>
        /// <param name="data">支付数据</param>
        /// <returns></returns>
        JsonReturn WeChatGZHPayment(int userid, AllinWeChatOfficialAccountsPaymentInputDto data);
        /// <summary>
        /// 通联支付提交
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        JsonReturn AllinPayment(int userid, AllinpaymentOtherPaymentApplyInputDto data);
        /// <summary>
        /// 订单获取
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        HaiPaiMaoOrderDetailOutputDto GetOrderData(int id);
        /// <summary>
        /// 发送减免通知
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        bool ReturnFree(string id);
        /// <summary>
        /// 获取商品所属商户id
        /// </summary>
        /// <param name="id">商品id</param>
        /// <returns>返回商户id</returns>
        Return_GetBusinessId GetBusinessId(int id);
        /// <summary>
        /// 获取商户信息
        /// </summary>
        /// <param name="id">商户id</param>
        /// <returns></returns>
        BusinessDetailOutputDto GetBusiness(int id);
    }
    /// <summary>
    /// 后台接口调用服务
    /// </summary>
    public class ClientService : IClientService
    {
        private HttpClient client;
  
        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="httpClientFactory"></param>
        public ClientService(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory.CreateClient("UserClient");
            string appid = "insurance";
            string timeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");     //时间戳
            string ciphertext = CommonClass.GreateGeneratEciphertext(appid, timeStamp);

            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Host = "zjzlsq.cn";

            client.DefaultRequestHeaders.Add("appid", appid);
            client.DefaultRequestHeaders.Add("timeStamp", timeStamp);
            client.DefaultRequestHeaders.Add("ciphertext", ciphertext);
            //
        }
        /// <summary>
        /// 更新代金券
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool UpdateUserCoupon(IncreaseCouponInputDto data)
        {
            string url = "/API/User/Coupon/InCrease";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "更新代金券>>");
            log.Info("提交数据：" + "用户id：" + data.UserId + "金额：" + data.Coupon.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 通过电话获取用户信息
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public UserOutputDto GetUserByPhone(string phone)
        {
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "通过电话获取用户信息>>");
            log.Info("提交数据：" + "用户电话：" + phone);
            try
            {
                var taskresponse = client.GetAsync($"/API/User/Coupon/GetUserInfo/{phone}");
                taskresponse.Wait();
                if (taskresponse.IsCompletedSuccessfully)
                {
                    var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                    if(result==null)
                    {
                        log.Debug("返回测试监视：调用失败" );
                        return null;
                    }
                    log.Debug("返回测试监视：" + result);
                    var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                    var json = JsonConvert.DeserializeObject<ReturnUserOutputDto>(result, jsonSetting);
                    log.Info("返回结果：" + json.Status);
                    if (json.Status == "OK")
                    {
                        return json.Data;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 用户验证（返回用户信息）
        /// </summary>
        /// <param name="session"></param>
        /// <returns></returns>
        public ReturnAuthenReturnData UserAuthen(string session)
        {
            string url ="/API/User/Authen";
            client.DefaultRequestHeaders.Add("Cookie", "s=" + session);
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "用户验证>>");
            log.Info("提交数据：" + "用户session：" + session);
            try
            {
                var taskresponse = client.GetAsync(url);
                taskresponse.Wait();
                if (taskresponse.IsCompletedSuccessfully)
                {
                    var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                    if (result == null)
                    {
                        log.Debug("返回测试监视：调用失败");
                        return null;
                    }
                    log.Debug("返回测试监视：" + result);
                    var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                    var json = JsonConvert.DeserializeObject<ReturnAuthenReturnData>(result, jsonSetting);
                    log.Info("返回结果：" + json.Status);
                    return json;
                }
                else
                {
                    log.Info("返回网络错误");
                    return default(ReturnAuthenReturnData);
                }
            }
            catch
            {
                log.Info("返回网络错误");
                return default(ReturnAuthenReturnData);
            }
        }
        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="phone"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public OutData UserLogin(string phone, string password)
        {
            string url =$"/API/User/Login?phone={phone}&password={password}";
            // HttpContent content = new StringContent(JsonConvert.SerializeObject(phone), Encoding.UTF8, "application/json"); ;
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "用户登录>>");
            log.Info("提交数据：" + "用户电话：" + phone);
            var taskresponse = client.GetAsync(url);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                var json = JsonConvert.DeserializeObject<ReturnOutData>(result, jsonSetting);
                log.Info("返回结果：" + json.Status);
                if (json.Status == "OK")
                {
                     return json.Data;
                }
                else
                {
                     return null;
                }
            }
            else
            {
                log.Info("返回失败：");
                return null;
            }
        }
        /// <summary>
        /// 更新用户资产
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool UpdateBalance(BalnaceUpdateData data)
        {

            string url = "/API/User/Balance/InCrease";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "资产更新>>");
            log.Info("提交数据：" + "用户id：" + data.UserId + "金额：" + data.Balance.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 派单通知
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool DeliveryNotice(DeliveryNoticeDto data)
        {
            string url = "/API/HaiPaiMao/OrderDelivery/DeliveryNotify";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "派单通知>>");
            log.Info("提交数据：" + "订单号：" + data.OrderCode + "状态：" + data.State.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        ///  短信推送phone mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool SmsPush(SmsInputDto data)
        {
            string url ="/API/MessagePush/Sms";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "短信推送>>");
            log.Info("提交数据：" + "接收用户电话：" + data.Phone + "内容：" + data.Content);
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        ///极光推送 aurora mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool MessagePush(MessagePushInputDto data)
        {
            string url ="/API/MessagePush/Push";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "极光推送>>");
            log.Info("提交数据：" + "接收用户id：" + data.ReceiveUserID + "内容：" + data.Content);
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 微信模板推送  wechat template mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool WeChatTemplate(PushTemplateMessageInputDto data)
        {
            string url = "/API/MessagePush/WeChatTemplateMessage";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "微信模板推送>>");
            log.Info("提交数据：" + "用户id：" + data.UserId + "模板：" + data.TemplateId.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 微信小程序推送  wechat small mess push
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool WeChatSmall(PushTemplateMsgOutputDto data)
        {
            string url = "/API/MessagePush/WeChatSmallProjectTemplateMessage";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "微信小程序推送>>");
            log.Info("提交数据：" + "接受人openid：" + data.OpenId + "模板：" + data.TemplateId.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 微信支付提交
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public JsonReturn WeChatPayment(int userid, WeChatPaymentInputDto data)
        {
            string url =$"/API/MessagePush/WeChatPayment/{userid}";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "微信支付提交>>");
            log.Info("提交数据：" + "用户id：" + userid.ToString()+"订单号"+data.Code + "金额：" + data.Price.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn_WeChatPaymentOutputDto>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return new JsonReturn<WeChatPaymentOutputDto>(json.data, Mess: "返回微信支付结果");
                }
                else
                {
                    return new JsonReturn(json.status);
                }
            }
            else
            {
                log.Info("返回失败：");
                return new JsonReturn(EnumJsonReturnStatus.Fail);
            }
        }
        /// <summary>
        /// 获取订单
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public HaiPaiMaoOrderDetailOutputDto GetOrderData(int id)
        {
            string url = $"/API/HaiPaiMao/Order/ThirdPartyPlatform/GetDetail/{id}";
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "获取订单详情>>");
            log.Info("提交数据：" + "订单id：" + id.ToString());
            var taskresponse = client.GetAsync(url);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                var json = JsonConvert.DeserializeObject<JsonReturn_HaiPaiMaoOrderDetailOutputDto>(result, jsonSetting);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return json.data;
                }
                else
                {
                    return default(HaiPaiMaoOrderDetailOutputDto);
                }
            }
            else
            {
                log.Info("返回失败：");
                return default(HaiPaiMaoOrderDetailOutputDto);
            }
        }
        /// <summary>
        /// 微信公众号支付提交
        /// </summary>
        /// <param name="userid">用户id</param>
        /// <param name="data">提交数据</param>
        /// <returns></returns>
        public JsonReturn WeChatGZHPayment(int userid, AllinWeChatOfficialAccountsPaymentInputDto data)
        {
            string url = $"/API/MessagePush/WeChatOfficialAccountPayment/{userid}";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "微信公众号支付提交>>");
            log.Info("提交数据：" + "订单号：" + data.Code + "金额：" + data.Amount.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn_AllinWeChatOfficialAccountPaymentPayinfoOutputDto>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {

                    return new JsonReturn<AllinWeChatOfficialAccountPaymentPayinfoOutputDto>(json.data, Mess: "返回公众号支付结果");
                }
                else
                {
                    return new JsonReturn(json.status);
                }
            }
            else
            {
                log.Info("返回失败：");
                return new JsonReturn(EnumJsonReturnStatus.Fail);
            }
        }
        /// <summary>
        /// 通联支付提交
        /// </summary>
        /// <param name="userid">用户id</param>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public JsonReturn AllinPayment(int userid, AllinpaymentOtherPaymentApplyInputDto data)
        {
            string url =$"/API/MessagePush/AllinPaymentApply/{userid}";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "通联支付提交>>");
            log.Info("提交数据：" + "订单号：" + data.OrderCode + "金额：" + data.Amount.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn_AllinPaymentOtherPaymentOutputDto>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return new JsonReturn<AllinPaymentOtherPaymentOutputDto>(json.data, Mess: "返回通联支付结果");
                }
                else
                {
                    return new JsonReturn(json.status);
                }
            }
            else
            {
                log.Info("返回失败：");
                return new JsonReturn(EnumJsonReturnStatus.Fail);
            }
        }
        /// <summary>
        /// 更新冻结资产
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool UpdateFreezeBalance(BalnaceUpdateData data)
        {
            string url = "/API/User/Balance/InCreaseFreezeMoney";
            string data_json = JsonConvert.SerializeObject(data);
            var content = new StringContent(data_json, Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "冻结资产更新>>");
            log.Info("提交数据：" + "用户id：" + data.UserId + "金额：" + data.Balance.ToString());
            log.Debug("提交数据明细：" + data_json);
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<JsonReturn>(result);
                log.Info("返回结果：" + json.status);
                if (json.status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 佣金返还
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool ReturnFree(string id)
        {
            string url = $"/API/HaiPaiMao/Order/ThirdPartyPlatform/ReturnFree{id}";
            var content = new StringContent(JsonConvert.SerializeObject(""), Encoding.UTF8, "application/json");
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "佣金返还>>");
            log.Info("提交数据：" + "订单id：" +id );
            var taskresponse = client.PostAsync(url, content);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return false;
                }
                log.Debug("返回测试监视：" + result);
                var json = JsonConvert.DeserializeObject<ReturnState>(result);
                log.Info("返回结果：" + json.Status);
                if (json.Status == "OK")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                log.Info("返回失败：");
                return false;
            }
        }
        /// <summary>
        /// 获取商品信息
        /// </summary>
        /// <param name="id">商品id</param>
        /// <returns></returns>
        public Return_GetBusinessId GetBusinessId(int id)
        {
            string url = $"/API/HaiPaiMao/Goods/ThirdPartyPlatform/GetGoods/{id}";
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "获取商品信息>>");
            log.Info("提交数据：" + "商品id：" + id.ToString());
            var taskresponse = client.GetAsync(url);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                var json = JsonConvert.DeserializeObject<JsonReturn_GetBusinessId>(result, jsonSetting);
                log.Info("返回结果：" + json.Status);
                if (json.Status == "OK")
                {
                    return json.Data;
                }
                else
                {
                    return default(Return_GetBusinessId);
                }
            }
            else
            {
                log.Info("返回失败：");
                return default(Return_GetBusinessId);
            }
        }
        /// <summary>
        /// 获取商户信息
        /// </summary>
        /// <param name="id">商户id</param>
        /// <returns></returns>
        public BusinessDetailOutputDto GetBusiness(int id)
        {
            string url = $"/API/HaiPaiMao/Business/GetDetail/{id}";
            //
            ILog log = LogManager.GetLogger(Startup.Repository.Name, "获取商户信息>>");
            log.Info("提交数据：" + "商户id：" + id.ToString());
            var taskresponse = client.GetAsync(url);
            taskresponse.Wait();
            if (taskresponse.IsCompletedSuccessfully)
            {
                var result = taskresponse.Result.Content.ReadAsStringAsync().Result;
                if (result == null)
                {
                    log.Debug("返回测试监视：调用失败");
                    return null;
                }
                log.Debug("返回测试监视：" + result);
                var jsonSetting = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };
                var json = JsonConvert.DeserializeObject<JsonReturn_BusinessDetailOutputDto>(result, jsonSetting);
                log.Info("返回结果：" + json.Status);
                if (json.Status == "OK")
                {
                    return json.Data;
                }
                else
                {
                    return default(BusinessDetailOutputDto);
                }
            }
            else
            {
                log.Info("返回失败：");
                return default(BusinessDetailOutputDto);
            }
        }
    }
   
}
