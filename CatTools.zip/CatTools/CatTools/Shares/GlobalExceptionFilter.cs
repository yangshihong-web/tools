﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using CatTools;
using CatTools.Shares;
using CatTools.Services;
using CatTools.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Mvc.Controllers;
using Swashbuckle.AspNetCore.Swagger;
using System.Reflection;

namespace CarTools.Shares
{
    #region  全部异常的处理
    /// <summary>
    /// 全部异常的处理
    /// </summary>
    public class GlobalExceptionFilter : IExceptionFilter
    {
        /// <summary>
        /// 同步
        /// </summary>
        /// <param name="context"></param>
        public void OnException(ExceptionContext context)
        {

            if (context.ExceptionHandled == false)
            {
               
                var exceptpe = context.Exception.GetType().ToString();
                if (exceptpe == "System.NullReferenceException")
                {
                    context.Result = new JsonResult(new JsonReturn(EnumJsonReturnStatus.Fail, "输入数据出现不允许的空值！"));
                }
                else if (exceptpe == "System.AggregateException")
                {
                    context.Result = new JsonResult(new JsonReturn(EnumJsonReturnStatus.Fail, "调用的网址暂时错误！"));
                }
                else
                {
                    JsonReturn json = new JsonReturn(EnumJsonReturnStatus.ServiceError, context.Exception.Message);
                    context.Result = new JsonResult(json);
                    //保存记录到日志
                    ILog log = LogManager.GetLogger(Startup.Repository.Name, "错误日志：");
                    //记录到日志
                    log.Error("错误信息： " + context.Exception.Message);
                    int index = context.Exception.StackTrace.LastIndexOf(":line ");
                    log.Error("错误定位： " + context.Exception.StackTrace.Substring(0, index + 12));
                }
                context.ExceptionHandled = true;
            }
        }
        /// <summary>
        /// 异步
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public Task OnExceptionAsync(ExceptionContext context)
        {
            OnException(context);
            return Task.CompletedTask;
        }

    }
    #endregion
    #region  令牌提交
    /// <summary>
    /// 令牌提交
    /// </summary>
    public class TokenInputActionFilter : Attribute, IActionFilter
    {
        private readonly string role;
        public TokenInputActionFilter()
        {
            this.role = "User";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_role"></param>
        public TokenInputActionFilter(string _role)
        {
            this.role = _role;
        }
        /// <summary>
        /// Action 执行后拦截
        /// </summary>
        /// <param name="context"></param>
        public void OnActionExecuted(ActionExecutedContext context)
        {

        }
        /// <summary>
        /// Action 执行前拦截[模型验证应该在此处先处理]
        /// </summary>
        /// <param name="context"></param>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            //获取前台accesstoken
            //string session = context.HttpContext.Request.Headers["accesstoken"];
            //前端未传递accesstoken
            //if (session == "")
            //{
            //    context.Result = new JsonResult(new JsonReturn(EnumJsonReturnStatus.TokenFail, "该接口需要传递accesstoken"));
            //}
            //else
            //{
            //保存传递的数据
            //   CommonClass.Role = role;
            //   CommonClass.session = session;
            // }
        }
    }
    #endregion
    #region  模型验证
    /// <summary>
    /// 模型验证
    /// </summary>
    public class ApiResultFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
        }
        //模型验证
        public override void OnResultExecuting(ResultExecutingContext context)
        {
            var errors = context.ModelState
                .Where(e => e.Value.Errors.Count > 0)
               .Select(e => e.Value.Errors.First().ErrorMessage)
               .ToList();
            if (errors.Count > 0)
            {
                var str = string.Join("|", errors);
                var result = new JsonReturn(EnumJsonReturnStatus.ValidationFail, str);
                context.Result = new ObjectResult(result);
            }
        }
    }
    #endregion
    #region  用户验证
    /// <summary>
    /// 用户验证
    /// </summary>
    public class UserAuthenActionFilter : IActionFilter
    {
        private readonly IUserService users;
        private readonly IClientService client;

        public UserAuthenActionFilter(IUserService _users, IClientService _client)
        {
            this.users = _users;
            this.client = _client;
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
          
           
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
            //前端未传递accesstoken
            if (string.IsNullOrEmpty(context.HttpContext.Request.Headers["accesstoken"]))
            { 
                context.Result = new JsonResult(new JsonReturn(EnumJsonReturnStatus.TokenFail, "该接口需要传递accesstoken"));
            }
            else
            {
                //获取传递的数据
                var session = context.HttpContext.Request.Headers["accesstoken"];
                //缓存验证
                Login login = null;
                //移除过期记录
                if (CommonClass.Logins != null)
                {
                    CommonClass.Logins.RemoveAll(o => o.EndTime <= DateTime.Now);
                    login = CommonClass.Logins.Find(o => o.Session == session);
                }
                else
                {
                    CommonClass.Logins = new List<Login>();
                }
                //
                if (login == null)
                {

                    //首次登录
                    //通过网络获取用户信息
                    var userweb = client.UserAuthen(context.HttpContext.Request.Headers["accesstoken"]);
                    //获取成功
                    if (userweb.Status == "OK")
                    {
                        //网络获取成功
                        //传递验证的uid
                        context.HttpContext.Items.Add("Uid", userweb.Data.Userid);
                        
                        //获取用户ip
                        var ip = context.HttpContext.Connection.RemoteIpAddress;
                        //保存session
                        CommonClass.Logins.Add(new Login()
                        {
                            Ipa = ip,
                            EndTime = DateTime.Now.AddHours(8),
                            UserId = userweb.Data.Userid,
                            Session = session,
                            LoginTime = DateTime.Now
                        });
                        //检查本地数据
                        var user = users.GetDetailed(userweb.Data.Userid);
                        if (user == null)
                        {
                            //不存在，添加本地数据
                            Task.Run(() =>
                            {
                                try
                                {
                                    var input = new UserRegister()
                                    {
                                        ID = userweb.Data.Userid,
                                        Name = userweb.Data.Name,
                                        Phone = userweb.Data.Phone,
                                        Portrait = userweb.Data.Portrait
                                    };
                                    users.AddUser(input);
                                }
                                catch
                                {

                                }
                            });
                        }
                       
                    }
                    else
                    {
                        context.Result = new JsonResult(new JsonReturn(EnumJsonReturnStatus.TokenFail, $"用户令牌验证失败：{userweb.Status}"));
                    }
                }
                else
                {
                    if(login.LoginTime>=DateTime.Now.AddSeconds(-3))
                    {
                        //登录过快，等待
                        Task.Delay(3000);
                        //var task_1 = Task.Run(async delegate
                        //{
                        //    await Task.Delay(3000);
                            //     Console.WriteLine("3秒后执行，方式一 输出语句...");
                         //   return "异步执行result"; //可以得到一个返回值(int,bool,string都试了)
                        //});
                    }
                    //本地验证通过，传递数据
                    context.HttpContext.Items.Add("Uid", login.UserId);
                }
            }
          
        }
    }
    #endregion

    # region  添加通用参数
    //添加通用参数，若in='header'则添加到header中,默认query参数
    public class AssignOperationVendorExtensions : IOperationFilter
    {
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null) operation.Parameters = new List<IParameter>();
            var attrs = context.ApiDescription.ActionDescriptor.AttributeRouteInfo;

            //先判断是否是匿名访问,
            var descriptor = context.ApiDescription.ActionDescriptor as ControllerActionDescriptor;
            if (descriptor != null)
            {
                var actionAttributes = descriptor.MethodInfo.GetCustomAttributes(inherit: true);
                bool noAnonymous = actionAttributes.Any(a => a is TokenInputActionFilter);
                //非匿名的方法,链接中添加accesstoken值
                if (noAnonymous)
                {

                    operation.Parameters.Add(new NonBodyParameter()
                    {
                        Name = "accesstoken",
                        In = "header",               //query header body path formData
                        Type = "string",
                        Required = true //是否必选
                    });
                }
            }
        }
    }
    #endregion

}
