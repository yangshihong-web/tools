﻿using CatTools.Shares;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;


namespace CarTools.Services
{
    public class DbOperation<T>
    {
        public IMongoCollection<T> _oper;
       
        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public async Task<T> Create(T input)
        {
            try
            {
                await _oper.InsertOneAsync(input);
                return input;
            }
            catch
            {
                return default(T);
            }
           
        }
        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="finddefinition"></param>
        /// <returns></returns>
        public T GetDetailed(Expression<Func<T,bool>> finddefinition)
        {
            var result = _oper.Find<T>(finddefinition).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 获取条件页数
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="pagesize"></param>
        /// <returns></returns>
        public int GetCountByCondition(Expression<Func<T, bool>> seachdefinition,int pagesize)
        {
            var query = _oper.AsQueryable<T>().Where(seachdefinition).Count();
            return CommonClass.GetPages(query, pagesize);
        }
        /// <summary>
        /// 获取条件列表(分页)
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="oederdefinition"></param>
        /// <param name="PageIndex"></param>
        /// <param name="PageSize"></param>
        /// <returns></returns>
        public List<T> GetListByCondition(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, DateTime>> oederdefinition, int PageIndex, int PageSize)
        {
            var result = _oper.AsQueryable<T>().OrderByDescending(oederdefinition).Skip(PageIndex * PageSize - PageSize).Take(PageSize)
         .Where(seachdefinition);
            return result.ToList();
        }
        /// <summary>
        /// 获取条件列表
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <returns></returns>
        public List<T> GetList(Expression<Func<T, bool>> seachdefinition)
        {
            var result = _oper.AsQueryable<T>().Where(seachdefinition);
            return result.ToList();
        }
        /// <summary>
        /// 获取条件列表(指定记录数)
        /// </summary>
        /// <param name="seachdefinition"></param>
        /// <param name="oederdefinition"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public List<T> GetListCount(Expression<Func<T, bool>> seachdefinition, Expression<Func<T, object>> oederdefinition, int count)
        {
            var result = _oper.Find<T>(seachdefinition).SortByDescending(oederdefinition).Limit(count);
            return result.ToList();
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="finddefinition"></param>
        /// <param name="modi"></param>
        /// <returns></returns>
        public async Task<bool> Update(Expression<Func<T, bool>> finddefinition,T modi)
        {
            try
            {
                await _oper.ReplaceOneAsync(finddefinition, modi);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="finddefinition"></param>
        /// <param name="modi"></param>
        /// <returns></returns>
        public async Task<bool> UpdateMany(FilterDefinition<T> finddefinition, UpdateDefinition<T> modi)
        {
            try
            {
                await _oper.UpdateManyAsync(finddefinition, modi);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="finddefinition"></param>
        /// <returns></returns>
        public bool Remove(Expression<Func<T, bool>> finddefinition)
        {
            try
            {
                _oper.DeleteOne(finddefinition);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
