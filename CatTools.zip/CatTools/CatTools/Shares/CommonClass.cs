﻿using CarTools.Shares;
using CatTools.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace CatTools.Shares
{
    /// <summary>
    /// 登录对象
    /// </summary>
    public class Login
    {
        public IPAddress Ipa { get; set; }
        public string Session { get; set; }
        public int UserId { get; set; }
        public DateTime EndTime { get; set; }
        public DateTime LoginTime { get; set; }
    }
    /// <summary>
    /// 通用类
    /// </summary>
    public static class CommonClass
    {
        public static List<Login> Logins { get; set; }
        /// <summary>
        /// 用户角色
        /// </summary>
        public static string Role { get; set; }
        /// <summary>
        /// 通知数据
        /// </summary>
        public static DeliveryNoticeDto notice { get; set; }
        /// <summary>
        /// 计算总页数
        /// </summary>
        /// <param name="totalcount">总记录数</param>
        /// <param name="pagesize">每页记录数</param>
        /// <returns>总分页数</returns>
        public static int GetPages(int totalcount, int pagesize)
        {
            return totalcount % pagesize == 0 ? totalcount / pagesize : totalcount / pagesize + 1;
        }
        /// <summary>
        /// 检查内容中的关键字是否存在
        /// </summary>
        /// <param name="Content"></param>
        public static bool IsExit(string Content)
        {
            string[] types = new string[] { "头条", "专题", "热点", "保险", "保险", "增员", "影音", "速递", "签单", "培训", "夜听", "营销" };
            if (types.Contains(Content))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 生成密文
        /// </summary>
        /// <param name="appid"></param>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public static string GreateGeneratEciphertext(string appid, string timeStamp)
        {

            string secret = "#fks$c#ss";
            string text = string.Format("{0}{1}{2}", appid, secret, timeStamp);
            string ciphertext = MD5Encrypt(text);
            return ciphertext;
        }
        /// <summary>
        /// MD5加密
        /// </summary>
        /// <param name="strText"></param>
        /// <returns></returns>
        public static string MD5Encrypt(string strText)
        {
            using (MD5CryptoServiceProvider provider = new MD5CryptoServiceProvider())
            {
                byte[] bytes = Encoding.Default.GetBytes(strText);
                return BitConverter.ToString(provider.ComputeHash(bytes)).ToLower().Replace("-", "");
            };
        }
     
        /// <summary>
        /// 计算地球上两点的距离，单位米
        /// </summary>
        /// <param name="point1">坐标1</param>
        /// <param name="point2">坐标2</param>
        /// <returns></returns>
        public static double Distance(double[] point1, double[] point2)
        {
            if (point1 == null || point2 == null || point1[0] == 0 || point1[1] == 0 || point2[0] == 0 || point2[1] == 0)
            {
                //输入数据不满足
                return 0;
            }
            var long1 = point1[0];
            var lat1 = point1[1];
            var long2 = point2[0];
            var lat2 = point2[1];
            double a, b, R;
            R = 6378137; //地球半径
            lat1 = lat1 * Math.PI / 180.0;
            lat2 = lat2 * Math.PI / 180.0;
            a = lat1 - lat2;
            b = (long1 - long2) * Math.PI / 180.0;
            double d;
            double sa2, sb2;
            sa2 = Math.Sin(a / 2.0);
            sb2 = Math.Sin(b / 2.0);
            d = 2 * R * Math.Asin(Math.Sqrt(sa2 * sa2 + Math.Cos(lat1) * Math.Cos(lat2) * sb2 * sb2));
            return d;
        }
     }
    /// <summary>
    /// 位置范围
    /// </summary>
    public class PositionModel
    {
        /// <summary>
        /// 最小纬度
        /// </summary>
        public double MinLat { get; set; }
        /// <summary>
        /// 最大纬度
        /// </summary>
        public double MaxLat { get; set; }
        /// <summary>
        /// 最小经度
        /// </summary>
        public double MinLng { get; set; }
        /// <summary>
        /// 最大经度
        /// </summary>
        public double MaxLng { get; set; }
    }
    /// <summary>
    /// 距离帮助
    /// </summary>
    public static class DistanceHelper
    {
        /// <summary>
        /// 根据一个给定经纬度的点和距离，进行附近地点查询
        /// </summary>
        /// <param name="longitude">经度</param>
        /// <param name="latitude">纬度</param>
        /// <param name="distance">距离（单位：公里或千米）</param>
        /// <returns>返回一个范围的4个点，最小纬度和纬度，最大经度和纬度</returns>
        public static PositionModel FindNeighPosition(double longitude, double latitude, double distance)
        {
            //先计算查询点的经纬度范围  
            double r = 6378.137;//地球半径千米  
            double dis = distance;//千米距离    
            double dlng = 2 * Math.Asin(Math.Sin(dis / (2 * r)) / Math.Cos(latitude * Math.PI / 180));
            dlng = dlng * 180 / Math.PI;//角度转为弧度  
            double dlat = dis / r;
            dlat = dlat * 180 / Math.PI;
            double minlat = latitude - dlat;
            double maxlat = latitude + dlat;
            double minlng = longitude - dlng;
            double maxlng = longitude + dlng;
            return new PositionModel
            {
                MinLat = minlat,
                MaxLat = maxlat,
                MinLng = minlng,
                MaxLng = maxlng
            };
        }

        /// <summary>
        /// 计算两点位置的距离，返回两点的距离，单位：公里或千米
        /// 该公式为GOOGLE提供，误差小于0.2米
        /// </summary>
        /// <param name="lng1">第一点经度</param>
        /// <param name="lat1">第一点纬度</param>
        /// <param name="lng2">第二点经度</param>
        /// <param name="lat2">第二点纬度</param>
        /// <returns>返回两点的距离，单位：公里或千米</returns>
        public static double GetDistance(double lng1, double lat1, double lng2, double lat2)
        {
            //地球半径，单位米
            double EARTH_RADIUS = 6378137;
            double radLat1 = Rad(lat1);
            double radLng1 = Rad(lng1);
            double radLat2 = Rad(lat2);
            double radLng2 = Rad(lng2);
            double a = radLat1 - radLat2;
            double b = radLng1 - radLng2;
            double result = 2 * Math.Asin(Math.Sqrt(Math.Pow(Math.Sin(a / 2), 2) + Math.Cos(radLat1) * Math.Cos(radLat2) * Math.Pow(Math.Sin(b / 2), 2))) * EARTH_RADIUS;
            return result;                 //转换为千米/ 1000
        }
        /// <summary>
        /// 经纬度转化成弧度
        /// </summary>
        /// <param name="d"></param>
        /// <returns></returns>
        private static double Rad(double d)
        {
            return (double)d * Math.PI / 180d;
        }
    }
    #region 雪花算法
    /// <summary>
    /// 雪花算法
    /// </summary>
    public class SnowflakeNet
    {
        //基准时间
        private static long StartStmp = 1288834974657L;
        //private const long START_STMP = 1480166465631L;
        /*每一部分占用的位数*/
        //机器标识位数
        const int MachineIdBits = 5;
        //数据标志位数
        const int DatacenterIdBits = 5;
        //序列号识位数
        const int SequenceBits = 12;

        /* 每一部分的最大值*/
        //机器ID最大值
        const long MaxMachineNum = -1L ^ (-1L << MachineIdBits);
        //数据标志ID最大值
        const long MaxDatacenterNum = -1L ^ (-1L << DatacenterIdBits);
        //序列号ID最大值
        private const long MaxSequenceNum = -1L ^ (-1L << SequenceBits);

        /*每一部分向左的位移*/
        //机器ID偏左移12位
        private const int MachineShift = SequenceBits;
        //数据ID偏左移17位
        private const int DatacenterIdShift = SequenceBits + MachineIdBits;
        //时间毫秒左移22位
        public const int TimestampLeftShift = SequenceBits + MachineIdBits + DatacenterIdBits;


        private long _sequence = 0L;//序列号
        private long _lastTimestamp = -1L;//上一次时间戳
        public long MachineId { get; protected set; }//机器标识
        public long DatacenterId { get; protected set; }//数据中心
        //public long Sequence = 0L;//序列号
        //{
        //    get { return _sequence; }
        //    internal set { _sequence = value; }
        //}

        private readonly DateTime Jan1st1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        private readonly object _lock = new Object();
        public SnowflakeNet(long machineId, long datacenterId)
        {
            // 如果超出范围就抛出异常
            if (machineId > MaxMachineNum || machineId < 0)
            {
                throw new ArgumentException(string.Format("machineId 必须大于0，MaxMachineNum： {0}", MaxMachineNum));
            }

            if (datacenterId > MaxDatacenterNum || datacenterId < 0)
            {
                throw new ArgumentException(string.Format("datacenterId必须大于0，且不能大于MaxDatacenterNum： {0}", MaxDatacenterNum));
            }

            //先检验再赋值
            MachineId = machineId;
            DatacenterId = datacenterId;
            //_sequence = sequence;
        }

        //public static Init(long machineId, long datacenterId)
        //{

        //}
        public long NextId()
        {
            lock (_lock)
            {
                var timestamp = TimeGen();
                if (timestamp < _lastTimestamp)
                {
                    throw new Exception(string.Format("时间戳必须大于上一次生成ID的时间戳.  拒绝为{0}毫秒生成id", _lastTimestamp - timestamp));
                }

                //如果上次生成时间和当前时间相同,在同一毫秒内
                if (_lastTimestamp == timestamp)
                {
                    //sequence自增，和sequenceMask相与一下，去掉高位
                    _sequence = (_sequence + 1) & MaxSequenceNum;
                    //判断是否溢出,也就是每毫秒内超过1024，当为1024时，与sequenceMask相与，sequence就等于0
                    if (_sequence == 0L)
                    {
                        //等待到下一毫秒
                        timestamp = TilNextMillis(_lastTimestamp);
                    }
                }
                else
                {
                    //如果和上次生成时间不同,重置sequence，就是下一毫秒开始，sequence计数重新从0开始累加,
                    //为了保证尾数随机性更大一些,最后一位可以设置一个随机数
                    _sequence = 0L;//new Random().Next(10);
                }

                _lastTimestamp = timestamp;
                return ((timestamp - StartStmp) << TimestampLeftShift) | (DatacenterId << DatacenterIdShift) | (MachineId << MachineShift) | _sequence;
            }
        }

        // 防止产生的时间比之前的时间还要小（由于NTP回拨等问题）,保持增量的趋势.
        protected virtual long TilNextMillis(long lastTimestamp)
        {
            var timestamp = TimeGen();
            while (timestamp <= lastTimestamp)
            {
                timestamp = TimeGen();
            }
            return timestamp;
        }

        // 获取当前的时间戳
        protected virtual long TimeGen()
        {
            //return TimeExtensions.CurrentTimeMillis();
            return (long)(DateTime.UtcNow - Jan1st1970).TotalMilliseconds;
        }
    }
    /// <summary>
    /// 通过雪花获取Id
    /// </summary>
    public class IdWorkerHelper
    {
        private static SnowflakeNet _idWorker = null;
        private IdWorkerHelper()
        {

        }

        static IdWorkerHelper()
        {
            _idWorker = new SnowflakeNet(1, 1);
        }
        public static long GenId64()
        {
            return _idWorker.NextId();

        }
    }
    #endregion
    
}
