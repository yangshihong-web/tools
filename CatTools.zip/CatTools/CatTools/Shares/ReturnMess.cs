﻿using CarTools.Shares;
using CatTools.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace CatTools.Shares
{
    /// <summary>
    /// 返回状态
    /// </summary>
    public class ReturnState
    {
        /// <summary>
        /// 返回状态
        /// </summary>
        public string Status { get; set; }
    }
    /// <summary>
    /// 通过电话获取用户信息--返回
    /// </summary>
    public class ReturnUserOutputDto
    {
        /// <summary>
        /// 返回状态
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 返回数据
        /// </summary>
        public UserOutputDto Data { get; set; }
    }
    /// <summary>
    /// 用户信息
    /// </summary>
    public class UserOutputDto
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public int Coupon { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        public string Portrait { get; set; }
    }
    /// <summary>
    /// 返回整数
    /// </summary>
    public class ReturnInt
    {
        public JsonReturn Data { get; set; }
        public EnumJsonReturnStatus Status { get; set; }
        public string Message { get; set; }
    }
    /// <summary>
    /// 登录--返回
    /// </summary>
    public class ReturnOutData
    {
        public OutData Data { get; set; }
        public int Total { get; set; }
        public string Status { get; set; }
    }
    /// <summary>
    /// 登录信息
    /// </summary>
    public class OutData
    {
        public int UID { get; set; }
        public string S { get; set; }
        public string Accid { get; set; }
        public string Token { get; set; }
    }
    /// <summary>
    /// 验证--返回
    /// </summary>
    public class ReturnAuthenReturnData
    {
        public string Status { get; set; }
        public AuthenReturnData Data { get; set; }
    }
    /// <summary>
    /// 验证返回数据
    /// </summary>
    public class AuthenReturnData
    {
        public string Phone { get; set; }
        public int Userid { get; set; }
        public string Name { get; set; }
        public string Portrait { get; set; }
    }
    /// <summary>
    /// 默认地址结果
    /// </summary>
    public class DefaultAddressResult
    {
        public string Status { get; set; }
        public long Total { get; set; }
        public DefaultData Data { get; set; }
    }
    /// <summary>
    /// 默认地址数据
    /// </summary>
    public class DefaultData
    {
        public int ID { get; set; }
        public string Province { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
    }
    /// <summary>
    /// 用户资产修改
    /// </summary>
    public class BalnaceUpdateData
    {
        public int UserId { get; set; }
        public int Balance { get; set; }
    }
    /// <summary>
    /// 海派猫派单状态提交数据
    /// </summary>
    public class DeliveryNoticeDto
    {
        /// <summary>
        /// 订单号
        /// </summary>
        public string OrderCode { get; set; }
        /// <summary>
        /// 派单状态
        /// </summary>
        public int State { get; set; }
        /// <summary>
        /// 骑手姓名
        /// </summary>
        public string ExpressName { get; set; }
        /// <summary>
        /// 骑手电话
        /// </summary>
        public string ExpressPhone { get; set; }
        /// <summary>
        /// 骑手id
        /// </summary>
        public int ExpressId { get; set; }
    }
    /// <summary>
    /// 短信推送数据包
    /// </summary>
    public class SmsInputDto
    {
        /// <summary>
        /// 推送人
        /// </summary>
        public int PushUserId { get; set; }
        /// <summary>
        /// 手机号
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        ///  短信内容
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        /// 短信签名
        /// </summary>
        public string SmsSign { get; set; }
    }
    /// <summary>
    /// 极光推送数据包
    /// </summary>
    public class MessagePushInputDto
    {
        /// <summary>
        ///消息内容
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        ///消息类型—订单通知/系统通知
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        ///发送时间 
        /// </summary>
        public string SendTime { get; set; }
        /// <summary>
        ///发送用户ID
        /// </summary>
        public int SendUserID { get; set; }
        /// <summary>
        ///接收用户ID
        /// </summary>
        public int ReceiveUserID { get; set; }
        /// <summary>
        ///推送对象
        /// </summary>
        public string Target { get; set; }
        /// <summary>
        /// 订单Id
        /// </summary>
        public int OrderId { get; set; }
        /// <summary>
        ///订单类
        /// </summary>
        public int OrderType { get; set; } 
    }
    /// <summary>
    /// 微信模板推送提交数据对象包
    /// </summary>
    public class PushTemplateMessageInputDto
    {
        /// <summary>
        /// 用户Id 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 模板ID 
        /// </summary>
        public string TemplateId { get; set; }
        /// <summary>
        ///  模板跳转链接 
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 模板数据
        /// </summary>
        public inline_model_0 TemplateDatas { get; set; }
      
    }
    /// <summary>
    /// 提交的模板数据
    /// </summary>
    public class inline_model_0
    {

    }
    /// <summary>
    /// 微信推送数据，交易提醒,EM-nMbEAQQT8-DvvAGEmMtDWtWLtZyb_yKdsGTGJzbo
    /// </summary>
    public class TradeAlert:inline_model_0
    {
        /// <summary>
        /// 头部
        /// </summary>
        public TempItem first { get; set; }
        //交易编号：
        public TempItem keyword1 { get; set; }
        //交易日期：
        public TempItem keyword2 { get; set; }
        //交易号码：
        public TempItem keyword3 { get; set; }
        //交易类型：
        public TempItem keyword4 { get; set; }
        //发生金额：
        public TempItem keyword5 { get; set; }
        /// <summary>
        /// 尾部
        /// </summary>
        public TempItem remark { get; set; }
    
    }
    /// <summary>
    /// 微信推送数据，订单状态更新Rjkm3FQg-tu35MjtF2em2K2WpR38Rj7PMMTBTaN9iZA
    /// </summary>
    public class StatusUpdate : inline_model_0
    {
        /// <summary>
        /// 消息对象名
        /// </summary>
        public TempItem First { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public TempItem OrderSn { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public TempItem OrderStatus { get; set; }
        /// <summary>
        /// 其他信息
        /// </summary>
        public TempItem Remark { get; set; }
    }
    /// <summary>
    /// 数据字典类
    /// </summary>
    public class TempItem
    {
        public TempItem(string v, string c = "#ffff")
        {
            value = v;
            color = c;
        }
        public string value { get; set; }
        public string color { get; set; }
    }
    /// <summary>
    /// 微信小程序推送数据包
    /// </summary>
    public class PushTemplateMsgOutputDto
    {
        /// <summary>
        /// Id 
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 模板Id 
        /// </summary>
        public string TemplateId { get; set; }
        /// <summary>
        /// 接收人OpenId 
        /// </summary>
        public string OpenId { get; set; }
        /// <summary>
        ///  表单Id 
        /// </summary>
        public string FormId { get; set; }
        /// <summary>
        ///  参数 
        /// </summary>
        public List<WeChatSmallProgramTemplateMsgData> Params { get; set; }
        /// <summary>
        /// AppId 
        /// </summary>
        public string AppId { get; set; }
        /// <summary>
        /// 小程序 
        /// </summary>
        public string SmallProgram { get; set; }
        /// <summary>
        ///  推送状态
        /// </summary>
        public bool PushStatus { get; set; }
        /// <summary>
        /// 跳转地址 
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 推送的异常信息
        /// </summary>
        public string PushError { get; set; }

    }
    /// <summary>
    /// 微信小程序推送数据
    /// </summary>
    public class WeChatSmallProgramTemplateMsgData
    {
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Color { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Key { get; set; }
    }
    /// <summary>
    /// 微信支付提交数据包
    /// </summary>
    public class WeChatPaymentInputDto
    {
        /// <summary>
        /// 订单内容
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        ///  支付订单号 
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        ///  支付金额 
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        ///  : 订单附加信息 和订单通知一起返回
        /// </summary>
        public string Attach { get; set; }
        /// <summary>
        /// 支付通知地址
        /// </summary>
        public string NotifyUrl { get; set; }
    }
    /// <summary>
    /// 微信支付返回结果
    /// </summary>
    public class JsonReturn_WeChatPaymentOutputDto
    {
        /// <summary>
        /// 数据 
        /// </summary>
        public WeChatPaymentOutputDto data { get; set; }
        /// <summary>
        /// 总数 
        /// </summary>
        public int total { get; set; }
        /// <summary>
        ///  状态
        /// </summary>
        public string status { get; set; }
    }
    /// <summary>
    /// 微信支付返回数据
    /// </summary>
    public class WeChatPaymentOutputDto
    {
        /// <summary>
        /// 订单Id 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// : 公众号id 
        /// </summary>
        public string appid { get; set; }
        /// <summary>
        /// : 订单详情扩展字符串 
        /// </summary>
        public string package { get; set; }
        /// <summary>
        /// 随机字符串 ,
        /// </summary>
        public string noncestr { get; set; }
        /// <summary>
        /// 时间戳 
        /// </summary>
        public string timestamp { get; set; }
        /// <summary>
        /// 签名 
        /// </summary>
        public string sign { get; set; }
        /// <summary>
        /// 预支付Id 
        /// </summary>
        public string prepayid { get; set; }
        /// <summary>
        /// 商户Id 
        /// </summary>
        public string partnerid { get; set; }
        /// <summary>
        ///  订单附加信息
        /// </summary>
        public string attach { get; set; }
    }
    /// <summary>
    /// 微信公众号支付提交数据包
    /// </summary>
    public class AllinWeChatOfficialAccountsPaymentInputDto
    {
        /// <summary>
        /// 订单内容
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        ///  支付订单号 
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        ///  支付金额 
        /// </summary>
        public int Amount { get; set; }
        /// <summary>
        ///  : 订单附加信息 和订单通知一起返回
        /// </summary>
        public string Params { get; set; }
        /// <summary>
        /// 支付通知地址
        /// </summary>
        public string NotifyUrl { get; set; }
    }
    /// <summary>
    /// 微信公众号支付返回结果
    /// </summary>
    public class JsonReturn_AllinWeChatOfficialAccountPaymentPayinfoOutputDto
    {
        /// <summary>
        /// 数据 
        /// </summary>
        public AllinWeChatOfficialAccountPaymentPayinfoOutputDto data { get; set; }
        /// <summary>
        /// 总数 
        /// </summary>
        public int total { get; set; }
        /// <summary>
        ///  状态
        /// </summary>
        public string status { get; set; }
    }
    /// <summary>
    /// 微信公公号支付返回数据
    /// </summary>
    public class AllinWeChatOfficialAccountPaymentPayinfoOutputDto
    {
        /// <summary>
        /// 订单Id 
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// : 公众号id 
        /// </summary>
        public string appid { get; set; }
        /// <summary>
        /// : 订单详情扩展字符串 
        /// </summary>
        public string package { get; set; }
        /// <summary>
        /// 随机字符串 ,
        /// </summary>
        public string noncestr { get; set; }
        /// <summary>
        /// 时间戳 
        /// </summary>
        public string timestamp { get; set; }
        /// <summary>
        /// 签名 
        /// </summary>
        public string Paysign { get; set; }
        /// <summary>
        ///  订单附加信息
        /// </summary>
        public string Params { get; set; }
    }
    /// <summary>
    /// 通联支付提交数据
    /// </summary>
    public class AllinpaymentOtherPaymentApplyInputDto
    {
        /// <summary>
        /// 订单号 ,
        /// </summary>
        public string OrderCode { get; set; }
        /// <summary>
        /// 订单内容 ,
        /// </summary>
        public string Body { get; set; }
        /// <summary>
        ///  自定义参数 ,
        /// </summary>
        public string Params { get; set; }
        /// <summary>
        ///  协议Id ,
        /// </summary>
        public string AgreeId { get; set; }
        /// <summary>
        /// 支付金额 ,
        /// </summary>
        public int Amount { get; set; }
        /// <summary>
        ///  通知地址
        /// </summary>
        public string NotifyUrl { get; set; }
       
    }
    /// <summary>
    /// 通联支付返回结果
    /// </summary>
    public class JsonReturn_AllinPaymentOtherPaymentOutputDto
    {
        /// <summary>
        /// 数据 
        /// </summary>
        public AllinPaymentOtherPaymentOutputDto data { get; set; }
        /// <summary>
        /// 总数 
        /// </summary>
        public int total { get; set; }
        /// <summary>
        ///  状态
        /// </summary>
        public string status { get; set; }
    }
    /// <summary>
    /// 通联支付返回数据
    /// </summary>
    public class AllinPaymentOtherPaymentOutputDto
    {
        /// <summary>
        /// 交易Id ,
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 自定义参数
        /// </summary>
        public string Params { get; set; }
        
    }
    /// <summary>
    /// 支付返回结果
    /// </summary>
    public class OtherPaymentResult
    {
        /// <summary>
        /// 支付类型
        /// </summary>
        public string PaymentType { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public string Code { get; set; }
        /// <summary>
        /// 支付单号
        /// </summary>
        public string PaymentCode { get; set; }
        /// <summary>
        /// 结果
        /// </summary>
        public bool Result { get; set; }
        /// <summary>
        /// 支付id
        /// </summary>
        public long Id { get; set; }
        /// <summary>
        /// 自定义参数
        /// </summary>
        public string Params { get; set; }
    }
    /// <summary>
    /// 嗨派猫订单返回
    /// </summary>
    public class JsonReturn_HaiPaiMaoOrderDetailOutputDto
    {
        /// <summary>
        ///  数据 
        /// </summary>
        public HaiPaiMaoOrderDetailOutputDto data { get; set; }
        /// <summary>
        ///  总数 
        /// </summary>
        public int total { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public string status { get; set; }
    }
    /// <summary>
    /// 嗨派猫订单数据
    /// </summary>
    public class HaiPaiMaoOrderDetailOutputDto
    {
        /// <summary>
        /// 订单Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 订单号 
        /// </summary>
        public string Code{ get; set; }
        /// <summary>
        /// 商品信息 
        /// </summary>
        public HaiPaiMaoOrderGoodsOutputDto[] Goods { get; set; }
        /// <summary>
        ///  店铺信息 
        /// </summary>
        public HaiPaiMaoOrderBusinessOutputDto Business { get; set; }
        /// <summary>
        /// 购买者信息 ,
        /// </summary>
        public HaiPaiMaoOrderBuyerOutputDto Buyer { get; set; }
        /// <summary>
        ///  订单下单坐标
        /// </summary>
        public double[] Coordinate { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        public HaiPaiMaoOrderAddressOutputDto Address { get; set; }
        /// <summary>
        /// 客户端类型
        /// </summary>
        public int Client { get; set; }
        /// <summary>
        /// 运费
        /// </summary>
        public double Freight { get; set; }
    }
    /// <summary>
    /// 商品
    /// </summary>
    public class HaiPaiMaoOrderGoodsOutputDto
    {
        /// <summary>
        /// Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 订单Id ,
        /// </summary>
        public int OrderId { get; set; }
        /// <summary>
        /// 商品名称 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        ///  价格 
        /// </summary>
        public int Price { get; set; }
        /// <summary>
        /// 图片 
        /// </summary>
        public string Picture { get; set; }
        /// <summary>
        ///  数量 
        /// </summary>
        public int Count { get; set; }
    }
    /// <summary>
    /// 商家
    /// </summary>
    public class HaiPaiMaoOrderBusinessOutputDto
    {
        /// <summary>
        /// Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        ///  名称 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string[] Images { get; set; }
        /// <summary>
        /// 坐标 
        /// </summary>
        public double[] Point { get; set; }
        /// <summary>
        ///  地址 
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        ///  电话
        /// </summary>
        public string Phone { get; set; }
    }
    /// <summary>
    /// 顾客
    /// </summary>
    public class HaiPaiMaoOrderBuyerOutputDto
    {
        /// <summary>
        /// Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 姓名 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        ///  头像
        /// </summary>
        public string Portrait { get; set; }
    }
    /// <summary>
    /// 地址
    /// </summary>
    public class HaiPaiMaoOrderAddressOutputDto
    {
        /// <summary>
        /// Id 
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 县 
        /// </summary>
        public string Area { get; set; }
        ///  省 ,
        public string Province { get; set; }
        /// <summary>
        ///  市 ,
        /// </summary>
        public string City { get; set; }
        /// <summary>
        ///  地址 ,
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 姓名 ,
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        ///  电话
        /// </summary>
        public string Phone { get; set; }
       
    }
    /// <summary>
    /// 返回商品所属商户id，对象
    /// </summary>
    public class JsonReturn_GetBusinessId
    {
        public Return_GetBusinessId Data { get; set; }
        public int Total { get; set; }
        public string Status { get; set; }
    }
    /// <summary>
    /// 返回商品所属商户id，数据
    /// </summary>
    public class Return_GetBusinessId
    {
        public int BusinessId { get; set; }
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int ClassId { get; set; }
        public string ClassName { get; set; }
        public int Price { get; set; }
    }
    /// <summary>
    /// 核销数据输入
    /// </summary>
    public class WriteOffDataInto
    {
        /// <summary>
        /// 核销id
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 类型，
        /// </summary>
        public WriteOffType Type { get; set; }
        /// <summary>
        /// 商户的用户id
        /// </summary>
        public int Uid { get; set; }
        /// <summary>
        /// 需要核销商品id
        /// </summary>
        public int Goodsid { get; set; }
        /// <summary>
        /// 需要核销金额
        /// </summary>
        public int Money { get; set; }
    }
  
    /// <summary>
    /// 核销类别
    /// </summary>
    public enum WriteOffType
    {
        /// <summary>
        /// 活动购买核销
        /// </summary>
        [Description("活动购买核销")]
        ToolsPurchase = 0,
        /// <summary>
        /// 活动领取核销
        /// </summary>
        [Description("活动领取核销")]
        ToolsTake = 1,
        /// <summary>
        /// 折扣卡核销
        /// </summary>
        [Description("折扣卡核销")]
        Discount = 2,
        /// <summary>
        /// 电子券核销
        /// </summary>
        [Description("电子券核销")]
        Elect = 3,
        /// <summary>
        /// 礼品券核销
        /// </summary>
        [Description("礼品券核销")]
        Goods = 4,
        /// <summary>
        /// 客户券核销
        /// </summary>
        [Description("客户券核销")]
        Coupons = 5

    }
    /// <summary>
    /// 返回商户信息
    /// </summary>
    public class JsonReturn_BusinessDetailOutputDto
    {
        /// <summary>
        /// 数据 
        /// </summary>
        public BusinessDetailOutputDto Data { get; set; }
        /// <summary>
        ///  总数 
        /// </summary>
        public int Total { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public string Status { get; set; }
    }
    /// <summary>
    /// 商户信息
    /// </summary>
    public class BusinessDetailOutputDto
    {
        /// <summary>
        /// 商户id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        ///商户名称  
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 店铺联系电话 
        /// </summary>
        public string Phone { get; set; }
        /// <summary>
        /// 分类Id 
        /// </summary>
        public int ClassId { get; set; }
        /// <summary>
        /// 分类名称 
        /// </summary>
        public string ClassName { get; set; }
        /// <summary>
        ///营业执照 
        /// </summary>
        public string BusinessLicense { get; set; }
        ///<summary>
        ///卫生许可证 
        ///</summary>
        public string HygieneLicense { get; set; }
        ///<summary>
        ///省份Id 
        /// </summary>
        public int ProvinceId { get; set; }
        /// <summary>
        ///省份名
        /// </summary>
        public string ProvinceName { get; set; }
        /// <summary>
        ///城市Id 
        /// </summary>
        public int CityId { get; set; }
        /// <summary>
        /// 城市名称 
        /// </summary>
        public string CityName { get; set; }
        /// <summary>
        ///县市Id 
        /// </summary>
        public int CountyId { get; set; }
        /// <summary>
        ///县市名称 
        /// </summary>
        public string CountyName { get; set; }
        /// <summary>
        ///  地址 
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 坐标 
        /// </summary>
        public double[] Point { get; set; }
        /// <summary>
        /// 法人 
        /// </summary>
        public string LegalPerson { get; set; }
        /// <summary>
        /// 法人联系电话 
        /// </summary>
        public string LegalPersonPhone { get; set; }
        /// <summary>
        /// 法人身份证正面照 
        /// </summary>
        public string IDCardNumber1 { get; set; }
        /// <summary>
        /// 法人身份证反面照 
        /// </summary>
        public string IDCardNumber2 { get; set; }
        /// <summary>
        /// 用户Id 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 商户店招 
        /// </summary>
        public string[] Images { get; set; }
        /// <summary>
        /// 营业开始时间 
        /// </summary>
        public string BusinessHoursStart { get; set; }
        /// <summary>
        /// 营业结束时间 
        /// </summary>
        public string BusinessHoursEnd { get; set; }
        /// <summary>
        /// 商户评价信息 
        /// </summary>
        public BusinessCommentDto Comment { get; set; }
        /// <summary>
        /// 客单价 
        /// </summary>
        public int PerCustomerTransaction { get; set; }
        /// <summary>
        /// 公告 
        /// </summary>
        public string Notice { get; set; }
        /// <summary>
        /// 运费起送价 
        /// </summary>
        public int FreightStart { get; set; }
        /// <summary>
        ///  运费 
        /// </summary>
        public int Freight { get; set; }
        /// <summary>
        ///配送开始时间  
        /// </summary>
        public string DeliveryStartTime { get; set; }
        /// <summary>
        /// 配送结束时间 
        /// </summary>
        public string DeliveryEndTime { get; set; }
        /// <summary>
        /// 是否支持外卖 
        /// </summary>
        public bool IsOpenTakeOut { get; set; }
        /// <summary>
        /// 浏览量
        /// </summary>
        public int Browse { get; set; }
    }
    /// <summary>
    /// 商户评价信息 
    /// </summary>
    public class BusinessCommentDto
    {
        /// <summary>
        /// 评分 
        /// </summary>
        public int Score { get; set; }

        /// <summary>
        /// 人数
        /// </summary>
        public int Peoples { get; set; }
    }
}
