﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace CarTools.Shares
{
    /// <summary>
    /// 数据返回（基础）
    /// </summary>
    public class JsonReturn
    {
        /// <summary>
        /// 数据返回构造
        /// </summary>
        public JsonReturn() { }
        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="_status">状态</param>
        public JsonReturn(string _status)
        {
            this.status = _status;
        }

        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="_status">状态码</param>
        public JsonReturn(EnumJsonReturnStatus _status)
        {
            this.status = _status.ToString();
        }
        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="_status">状态码</param>
        /// <param name="_message">提醒信息</param>
        public JsonReturn(EnumJsonReturnStatus _status, string _message)
        {
            this.status = _status.ToString();
            this.message = _message;
        }
        /// <summary>
        /// 状态
        /// </summary>
        public string status { get; set; }
        /// <summary>
        /// 提醒信息
        /// </summary>
        public string message { get; set; }
    }
   
    /// <summary>
    /// 数据返回泛型数据
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class JsonReturn<T> : JsonReturn
    {
        /// <summary>
        /// 数据返回构造
        /// </summary>
        public JsonReturn() : base() { }
        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="data"></param>
        public JsonReturn(string data) : base(data) { }
        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="data"></param>
        public JsonReturn(EnumJsonReturnStatus data) : base(data) { }
        /// <summary>
        /// 返回数据构造
        /// </summary>
        /// <param name="_data">数据体</param>
        /// <param name="_total">总数</param>
        /// <param name="Mess"></param>
        public JsonReturn(T _data, long _total=1,string Mess= "成功返回数据")
        {
            this.status = EnumJsonReturnStatus.OK.ToString();
            this.message = Mess;
            this.data = _data;
            this.total = _total;
        }
        /// <summary>
        /// 数据
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public T data { get;}
        /// <summary>
        /// 总数
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public long? total { get; }

    }
  
    /// <summary>
    /// JsonReturn返回状态枚举
    /// </summary>
    public enum EnumJsonReturnStatus
    {
        /// <summary>
        /// 失败
        /// </summary>
        Fail,
        /// <summary>
        /// 成功
        /// </summary>
        OK,
        /// <summary>
        /// 未发现
        /// </summary>
        NoFound,
        /// <summary>
        /// 
        /// </summary>
        ValidationFail,
        /// <summary>
        /// 
        /// </summary>
        TokenFail,
        /// <summary>
        /// 
        /// </summary>
        ServiceError

    }
    /// <summary>
    /// 微信错误返回
    /// </summary>
    public class ReturnError
    {
        public int errcode { get; set; }
        public string errmsg { get; set; }
        public string msgid { get; set; }
    }
    /// <summary>
    /// 消息模板
    /// </summary>
    public class TemplateModel
    {
        public TemplateModel(string late, string _url)
        {
            url = _url;
            template_id = late;
        }
        //用户openid
        public string touser { get; set; }
        //模板消息ID
        public string template_id { get; set; }
        //详情跳转页面
        public string url { get; set; }
        //颜色
        public string topcolor { get; set; }

        //模板数据封装实体
        public TemplateData data { get; set; }

        /// <summary>
        /// 设置参数
        /// </summary>
        public void Setparameter(SendMessToWeixin send)
        {
            data = new TemplateData()
            {
                SendMan = new TempItem(send.Supplier),
                SendContent = new TempItem(send.Content),
                SendTime = new TempItem(DateTime.Now.ToString())

            };
            touser = send.Openid;
            topcolor = "#FF0000";
        }
    }
    /// <summary>
    /// 封装数据
    /// </summary>
    public class TemplateData
    {
        public TempItem SendMan { get; set; }
        public TempItem SendContent { get; set; }
        public TempItem SendTime { get; set; }
    }
    /// <summary>
    /// 数据类
    /// </summary>
    public class TempItem
    {
        public TempItem(string v, string c = "#173177")
        {
            value = v;
            color = c;
        }
        public string value { get; set; }
        public string color { get; set; }
    }
    //通过模板发送消息对象
    public class SendMessToWeixin
    {
        /// <summary>
        /// 消息提供人
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// 接收消息人openid
        /// </summary>
        public string Openid { get; set; }
        /// <summary>
        /// 发送的消息内容
        /// </summary>
        public string Content { get; set; }
    }
    /// <summary>
    /// 令牌返回对象
    /// </summary>
    public class TokenResult
    {
        public string Access_token { get; set; }
        public int Expires_in { get; set; }
    }
  
}
